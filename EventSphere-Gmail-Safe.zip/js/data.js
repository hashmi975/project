// EventSphere Management - Realistic Mock Data Store (Pakistani / Muslim Profiles)
window.EVENTSPHERE_DATA = {
  currentExpoId: "expo-1",
  
  expos: [
    {
      id: "expo-1",
      title: "Pakistan Tech & AI Innovators Expo 2026",
      tagline: "Connecting frontier artificial intelligence, industrial robotics, and sovereign cloud systems.",
      category: "Technology & AI",
      location: "Expo Centre Karachi, Sindh",
      venueDetails: "Halls 1, 2 & Grand Auditorium (Capacity: 15,000)",
      startDate: "Nov 12, 2026",
      endDate: "Nov 15, 2026",
      status: "Active",
      totalBooths: 48,
      occupiedBooths: 38,
      attendeeCount: 8420,
      bannerColor: "from-[#1C0B24] via-[#281133] to-[#F59E0B]",
      description: "The nation's largest gathering of technology pioneers, software leaders, robotics engineers, and enterprise executives showcasing cutting-edge solutions across 4 days."
    },
    {
      id: "expo-2",
      title: "Pak-Green Energy & Decarb Summit 2026",
      tagline: "Accelerating solar energy adoption, microgrids, and industrial green transition.",
      category: "Renewable Energy",
      location: "Pak-China Friendship Centre, Islamabad",
      venueDetails: "Main Convention Hall & Exhibition Suites (Capacity: 12,000)",
      startDate: "Dec 04, 2026",
      endDate: "Dec 07, 2026",
      status: "Upcoming",
      totalBooths: 40,
      occupiedBooths: 29,
      attendeeCount: 6150,
      bannerColor: "from-[#1C0B24] via-[#281133] to-[#F59E0B]",
      description: "Dedicated to trade and investments in rooftop solar grids, battery energy storage, and industrial energy efficiency solutions across Pakistan."
    },
    {
      id: "expo-3",
      title: "AutoMobility & EV Pakistan Expo 2026",
      tagline: "The frontier of electric vehicle manufacturing, battery tech, and urban transport.",
      category: "Automotive & Mobility",
      location: "Lahore International Expo Centre, Punjab",
      venueDetails: "Halls 2 & 3 (Capacity: 18,000)",
      startDate: "Jan 18, 2027",
      endDate: "Jan 21, 2027",
      status: "Registration Open",
      totalBooths: 56,
      occupiedBooths: 41,
      attendeeCount: 11200,
      bannerColor: "from-[#1C0B24] via-[#281133] to-[#F59E0B]",
      description: "Showcasing commercial electric vehicles, solar-assisted transit fleets, smart battery swappable stations, and localized automotive engineering."
    },
    {
      id: "expo-4",
      title: "Shifa HealthTech & MedAsia Summit 2027",
      tagline: "Digital health innovations, robotic surgery diagnostics, and clinical biomedical equipment.",
      category: "Healthcare & Life Sciences",
      location: "Jinnah Convention Centre, Islamabad",
      venueDetails: "Main Arena & Medical Concourse (Capacity: 10,000)",
      startDate: "Feb 22, 2027",
      endDate: "Feb 25, 2027",
      status: "Planning",
      totalBooths: 36,
      occupiedBooths: 18,
      attendeeCount: 4800,
      bannerColor: "from-[#1C0B24] via-[#281133] to-[#F59E0B]",
      description: "Bringing together healthcare executives, pharmaceutical researchers, hospital directors, and biomedical engineers from across the region."
    }
  ],

  booths: [
    // Hall A - Premium and Standard Booths
    {
      id: "A-101",
      hall: "Hall A",
      row: 1,
      col: 1,
      name: "Booth A-101",
      tier: "Corner Premium",
      dimensions: "15ft x 15ft (225 sq ft)",
      price: 2400,
      status: "occupied", // occupied, available, reserved, vip
      exhibitorId: "ex-1",
      exhibitorName: "PakRobotics Technologies",
      power: "2x 220V / 20A Dedicated",
      amenities: ["Corner Visibility", "High-speed Fiber LAN", "Carpeted Floor", "2 Conference Passes"]
    },
    {
      id: "A-102",
      hall: "Hall A",
      row: 1,
      col: 2,
      name: "Booth A-102",
      tier: "Standard",
      dimensions: "10ft x 10ft (100 sq ft)",
      price: 1200,
      status: "occupied",
      exhibitorId: "ex-2",
      exhibitorName: "Shams Clean Energy",
      power: "1x 220V / 15A Standard",
      amenities: ["Standard Wall Drapes", "High-speed WiFi", "1 Conference Pass"]
    },
    {
      id: "A-103",
      hall: "Hall A",
      row: 1,
      col: 3,
      name: "Booth A-103",
      tier: "Standard",
      dimensions: "10ft x 10ft (100 sq ft)",
      price: 1200,
      status: "available",
      exhibitorId: null,
      exhibitorName: null,
      power: "1x 220V / 15A Standard",
      amenities: ["Standard Wall Drapes", "High-speed WiFi", "1 Conference Pass"]
    },
    {
      id: "A-104",
      hall: "Hall A",
      row: 1,
      col: 4,
      name: "Booth A-104",
      tier: "Corner Premium",
      dimensions: "15ft x 15ft (225 sq ft)",
      price: 2400,
      status: "reserved",
      exhibitorId: "ex-3",
      exhibitorName: "CyberDifa 360",
      power: "2x 220V / 20A Dedicated",
      amenities: ["Corner Visibility", "High-speed Fiber LAN", "Carpeted Floor", "2 Conference Passes"]
    },
    {
      id: "A-105",
      hall: "Hall A",
      row: 2,
      col: 1,
      name: "Booth A-105 (Center Pavilion)",
      tier: "Island Pavilion",
      dimensions: "20ft x 20ft (400 sq ft)",
      price: 4800,
      status: "vip",
      exhibitorId: "ex-4",
      exhibitorName: "Al-Khwarizmi Quantum Tech",
      power: "4x 220V / 30A Heavy Duty",
      amenities: ["360° Open Aisle Access", "Overhead Rigging Rights", "Dedicated 1Gbps Fiber", "4 VIP Passes"]
    },
    {
      id: "A-106",
      hall: "Hall A",
      row: 2,
      col: 2,
      name: "Booth A-106",
      tier: "Standard",
      dimensions: "10ft x 10ft (100 sq ft)",
      price: 1200,
      status: "available",
      exhibitorId: null,
      exhibitorName: null,
      power: "1x 220V / 15A Standard",
      amenities: ["Standard Wall Drapes", "High-speed WiFi", "1 Conference Pass"]
    },
    {
      id: "A-107",
      hall: "Hall A",
      row: 2,
      col: 3,
      name: "Booth A-107",
      tier: "Standard",
      dimensions: "10ft x 10ft (100 sq ft)",
      price: 1200,
      status: "occupied",
      exhibitorId: "ex-5",
      exhibitorName: "Shifa BioTech Dynamics",
      power: "1x 220V / 15A Standard",
      amenities: ["Standard Wall Drapes", "High-speed WiFi", "1 Conference Pass"]
    },
    {
      id: "A-108",
      hall: "Hall A",
      row: 2,
      col: 4,
      name: "Booth A-108",
      tier: "Corner Premium",
      dimensions: "15ft x 15ft (225 sq ft)",
      price: 2400,
      status: "available",
      exhibitorId: null,
      exhibitorName: null,
      power: "2x 220V / 20A Dedicated",
      amenities: ["Corner Visibility", "High-speed Fiber LAN", "Carpeted Floor", "2 Conference Passes"]
    },

    // Hall B - Tech Hub & Innovations
    {
      id: "B-201",
      hall: "Hall B",
      row: 1,
      col: 1,
      name: "Booth B-201",
      tier: "Corner Premium",
      dimensions: "15ft x 15ft (225 sq ft)",
      price: 2400,
      status: "occupied",
      exhibitorId: "ex-6",
      exhibitorName: "Karakoram AutoMobility",
      power: "2x 220V / 20A Dedicated",
      amenities: ["Corner Visibility", "High-speed Fiber LAN", "Carpeted Floor", "2 Conference Passes"]
    },
    {
      id: "B-202",
      hall: "Hall B",
      row: 1,
      col: 2,
      name: "Booth B-202",
      tier: "Standard",
      dimensions: "10ft x 10ft (100 sq ft)",
      price: 1200,
      status: "available",
      exhibitorId: null,
      exhibitorName: null,
      power: "1x 220V / 15A Standard",
      amenities: ["Standard Wall Drapes", "High-speed WiFi", "1 Conference Pass"]
    },
    {
      id: "B-203",
      hall: "Hall B",
      row: 1,
      col: 3,
      name: "Booth B-203",
      tier: "Standard",
      dimensions: "10ft x 10ft (100 sq ft)",
      price: 1200,
      status: "available",
      exhibitorId: null,
      exhibitorName: null,
      power: "1x 220V / 15A Standard",
      amenities: ["Standard Wall Drapes", "High-speed WiFi", "1 Conference Pass"]
    },
    {
      id: "B-204",
      hall: "Hall B",
      row: 1,
      col: 4,
      name: "Booth B-204",
      tier: "Corner Premium",
      dimensions: "15ft x 15ft (225 sq ft)",
      price: 2400,
      status: "reserved",
      exhibitorId: "ex-7",
      exhibitorName: "Asr NeuroTech Systems",
      power: "2x 220V / 20A Dedicated",
      amenities: ["Corner Visibility", "High-speed Fiber LAN", "Carpeted Floor", "2 Conference Passes"]
    },
    {
      id: "B-205",
      hall: "Hall B",
      row: 2,
      col: 1,
      name: "Booth B-205 (Pavilion B)",
      tier: "Island Pavilion",
      dimensions: "20ft x 20ft (400 sq ft)",
      price: 4800,
      status: "available",
      exhibitorId: null,
      exhibitorName: null,
      power: "4x 220V / 30A Heavy Duty",
      amenities: ["360° Open Aisle Access", "Overhead Rigging Rights", "Dedicated 1Gbps Fiber", "4 VIP Passes"]
    },
    {
      id: "B-206",
      hall: "Hall B",
      row: 2,
      col: 2,
      name: "Booth B-206",
      tier: "Standard",
      dimensions: "10ft x 10ft (100 sq ft)",
      price: 1200,
      status: "available",
      exhibitorId: null,
      exhibitorName: null,
      power: "1x 220V / 15A Standard",
      amenities: ["Standard Wall Drapes", "High-speed WiFi", "1 Conference Pass"]
    },
    {
      id: "B-207",
      hall: "Hall B",
      row: 2,
      col: 3,
      name: "Booth B-207",
      tier: "Standard",
      dimensions: "10ft x 10ft (100 sq ft)",
      price: 1200,
      status: "occupied",
      exhibitorId: "ex-8",
      exhibitorName: "Indus Cloud Networks",
      power: "1x 220V / 15A Standard",
      amenities: ["Standard Wall Drapes", "High-speed WiFi", "1 Conference Pass"]
    },
    {
      id: "B-208",
      hall: "Hall B",
      row: 2,
      col: 4,
      name: "Booth B-208",
      tier: "Corner Premium",
      dimensions: "15ft x 15ft (225 sq ft)",
      price: 2400,
      status: "available",
      exhibitorId: null,
      exhibitorName: null,
      power: "2x 220V / 20A Dedicated",
      amenities: ["Corner Visibility", "High-speed Fiber LAN", "Carpeted Floor", "2 Conference Passes"]
    }
  ],

  exhibitors: [
    {
      id: "ex-1",
      name: "PakRobotics Technologies",
      category: "Robotics & Automation",
      tagline: "Autonomous industrial cobots and warehouse automated guided vehicles.",
      boothId: "A-101",
      boothTier: "Corner Premium",
      location: "Hall A, Booth A-101",
      website: "https://pakrobotics.example.pk",
      email: "info@pakrobotics.example.pk",
      phone: "+92 (21) 3456-7890",
      representative: "Dr. Tariq Mehmood",
      badgeColor: "bg-[#1C0B24] text-[#F59E0B] border border-[#F59E0B]",
      description: "PakRobotics designs high-precision manufacturing cobots with real-time sensory control for textile mills, pharmaceuticals, and automotive assembly lines.",
      products: [
        { name: "Shaheen-7 Industrial Palletizer", spec: "7-axis payload 250kg, millimeter LiDAR navigation" },
        { name: "Basar Vision AI Suite", spec: "Real-time 120 FPS textile fabric defect classification" },
        { name: "Cobot Arm PR-500", spec: "Ergonomic human-safe assembly unit with torque sensors" }
      ],
      social: { linkedin: "pakrobotics", twitter: "@pakrobotics" }
    },
    {
      id: "ex-2",
      name: "Shams Clean Energy",
      category: "Renewable Energy",
      tagline: "High-efficiency bi-facial solar arrays and industrial microgrid controllers.",
      boothId: "A-102",
      boothTier: "Standard",
      location: "Hall A, Booth A-102",
      website: "https://shamsenergy.example.pk",
      email: "contact@shamsenergy.example.pk",
      phone: "+92 (51) 2234-567",
      representative: "Muhammad Bilal Khan",
      badgeColor: "bg-[#F59E0B] text-[#1C0B24]",
      description: "Shams Clean Energy engineers commercial rooftop solar installations with 31% verified cell efficiency and predictive inverter load balancing.",
      products: [
        { name: "Shams Tandem Solar Panels", spec: "550W per module with 30-year linear performance warranty" },
        { name: "Hifazat AI Smart Inverter 50kW", spec: "Rapid zero-export grid switching and surge damping" }
      ],
      social: { linkedin: "shams-energy", twitter: "@shamsenergy" }
    },
    {
      id: "ex-3",
      name: "CyberDifa 360",
      category: "Cybersecurity & Defense",
      tagline: "National-grade cybersecurity, endpoint isolation, and zero-trust mesh.",
      boothId: "A-104",
      boothTier: "Corner Premium",
      location: "Hall A, Booth A-104",
      website: "https://cyberdifa.example.pk",
      email: "secops@cyberdifa.example.pk",
      phone: "+92 (42) 3589-1122",
      representative: "Fatima Zahra",
      badgeColor: "bg-[#281133] text-[#FBBF24]",
      description: "CyberDifa 360 delivers sovereign zero-trust defense architectures guarding financial institutions and critical national infrastructure against advanced cyber threats.",
      products: [
        { name: "Muhafiz Zero-Trust Agent", spec: "Kernel-level intrusion quarantine under 35 milliseconds" },
        { name: "Qalam Cryptographic Mesh", spec: "Post-quantum encrypted site-to-site communication" }
      ],
      social: { linkedin: "cyberdifa", twitter: "@cyberdifa" }
    },
    {
      id: "ex-4",
      name: "Al-Khwarizmi Quantum Tech",
      category: "Computing & AI Hardware",
      tagline: "Photonic quantum computing chips and molecular modeling simulators.",
      boothId: "A-105",
      boothTier: "Island Pavilion (VIP)",
      location: "Hall A, Booth A-105",
      website: "https://alkhwarizmi-quantum.example.pk",
      email: "research@alkhwarizmi.example.pk",
      phone: "+92 (51) 9044-332",
      representative: "Prof. Dr. Salman Farooqi",
      badgeColor: "bg-[#3A194A] text-[#FEF3C7]",
      description: "Pioneering optical room-temperature quantum co-processors integrated into standard data center racks for pharmaceutical drug discovery and financial optimization.",
      products: [
        { name: "Al-Razi Photonic Q1 Accelerator", spec: "128 coherent optical qubits at ambient room temperature" },
        { name: "Hisaab Molecular Modeling Cloud", spec: "Fast molecular docking simulation for pharmacology" }
      ],
      social: { linkedin: "alkhwarizmi-quantum", twitter: "@ak_quantum" }
    },
    {
      id: "ex-5",
      name: "Shifa BioTech Dynamics",
      category: "Healthcare & Life Sciences",
      tagline: "Non-invasive biomarker sensors and AI-assisted surgical navigation.",
      boothId: "A-107",
      boothTier: "Standard",
      location: "Hall A, Booth A-107",
      website: "https://shifabiotech.example.pk",
      email: "support@shifabiotech.example.pk",
      phone: "+92 (21) 3871-9000",
      representative: "Dr. Zainab Qureshi, MD",
      badgeColor: "bg-[#1C0B24] text-[#F59E0B]",
      description: "Shifa BioTech bridges clinical diagnostic care with wearable sensors monitoring multiple vital metabolic indicators continuously in real time.",
      products: [
        { name: "Hayat Continuous Dermal Sensor", spec: "Real-time telemetry for glucose, lactate, and electrolytes" },
        { name: "Nazar AR Surgical Headset", spec: "Sub-millimeter tumor margin guidance in surgery" }
      ],
      social: { linkedin: "shifa-biotech", twitter: "@shifabiotech" }
    },
    {
      id: "ex-6",
      name: "Karakoram AutoMobility",
      category: "Automotive & Mobility",
      tagline: "Commercial EV logistics platforms and smart battery swapping infrastructure.",
      boothId: "B-201",
      boothTier: "Corner Premium",
      location: "Hall B, Booth B-201",
      website: "https://karakoram-mobility.example.pk",
      email: "fleets@karakoram.example.pk",
      phone: "+92 (42) 3712-4455",
      representative: "Hamza Usman",
      badgeColor: "bg-[#F59E0B] text-[#1C0B24]",
      description: "Developing electric delivery vans, autonomous campus shuttles, and solar-coupled charging station networks for urban commercial fleets.",
      products: [
        { name: "Karakoram Volt Van 300", spec: "320km range, 1.8 ton payload, 40-minute DC fast charging" },
        { name: "Rastah Fleet Telematics OS", spec: "Real-time route energy optimization and battery health monitoring" }
      ],
      social: { linkedin: "karakoram-mobility", twitter: "@karakoram_ev" }
    },
    {
      id: "ex-7",
      name: "Asr NeuroTech Systems",
      category: "Neurotechnology",
      tagline: "Non-invasive brain-computer interfaces for assistive robotics and control.",
      boothId: "B-204",
      boothTier: "Corner Premium",
      location: "Hall B, Booth B-204",
      website: "https://asrneuro.example.pk",
      email: "info@asrneuro.example.pk",
      phone: "+92 (51) 8431-290",
      representative: "Maryam Naveed",
      badgeColor: "bg-[#281133] text-[#FBBF24]",
      description: "High-density neural EEG headbands enabling hands-free control of robotic prosthetics and industrial automated equipment.",
      products: [
        { name: "Asr NeuroBand Pro 64", spec: "Low-latency intent decoding with dry conductive sensors" }
      ],
      social: { linkedin: "asr-neurotech", twitter: "@asrneuro" }
    },
    {
      id: "ex-8",
      name: "Indus Cloud Networks",
      category: "Cloud Infrastructure",
      tagline: "Sovereign low-latency cloud infrastructure and localized GPU clusters.",
      boothId: "B-207",
      boothTier: "Standard",
      location: "Hall B, Booth B-207",
      website: "https://induscloud.example.pk",
      email: "operations@induscloud.example.pk",
      phone: "+92 (21) 3519-8200",
      representative: "Zubair Ahmed",
      badgeColor: "bg-[#3A194A] text-[#FEF3C7]",
      description: "Decentralized serverless computing infrastructure and high-performance GPU clusters stationed inside Tier-3 local Pakistani datacenters.",
      products: [
        { name: "Indus Accelerated GPU Node", spec: "Enterprise cluster access with guaranteed sub-10ms ping in Pakistan" }
      ],
      social: { linkedin: "indus-cloud", twitter: "@induscloud" }
    }
  ],

  applications: [
    {
      id: "app-101",
      companyName: "Shaheen AeroDrone Labs",
      category: "Aerospace & Robotics",
      contactName: "Daniyal Malik",
      email: "daniyal@shaheen-drones.example.pk",
      phone: "+92 (300) 412-8899",
      boothRequested: "Corner Premium (Hall A)",
      productsSummary: "Heavy-lift agricultural and logistics drones with autonomous obstacle bypass LiDAR.",
      documents: ["SEC_Registration_Certificate.pdf", "Civil_Aviation_Clearance.pdf"],
      dateApplied: "Oct 14, 2026",
      status: "pending"
    },
    {
      id: "app-102",
      companyName: "Sabz BioMaterials",
      category: "Sustainability",
      contactName: "Huma Rashid",
      email: "huma@sabzbiomaterials.example.pk",
      phone: "+92 (321) 890-4422",
      boothRequested: "Standard (Hall B)",
      productsSummary: "100% biodegradable agricultural waste packaging films for textile export logistics.",
      documents: ["PSQCA_Certification.pdf", "Company_NTN_Document.pdf"],
      dateApplied: "Oct 15, 2026",
      status: "pending"
    },
    {
      id: "app-103",
      companyName: "PakPower Energy Solutions",
      category: "Renewable Energy",
      contactName: "Haris Jahangir",
      email: "haris@pakpower.example.pk",
      phone: "+92 (333) 551-7890",
      boothRequested: "Corner Premium (Hall B)",
      productsSummary: "Solid-state lithium ferro-phosphate battery racks for industrial load shedding backup.",
      documents: ["ISO9001_Audit_Report.pdf", "Safety_Compliance_Letter.pdf"],
      dateApplied: "Oct 12, 2026",
      status: "approved"
    },
    {
      id: "app-104",
      companyName: "Sawt AI Technologies",
      category: "Technology & AI",
      contactName: "Khadija Abbasi",
      email: "khadija@sawt-ai.example.pk",
      phone: "+92 (312) 670-1123",
      boothRequested: "Standard (Hall A)",
      productsSummary: "Real-time Urdu and regional Pakistani language speech-to-text neural accelerator.",
      documents: ["Sawt_AI_Technical_Whitepaper.pdf"],
      dateApplied: "Oct 10, 2026",
      status: "rejected"
    }
  ],

  sessions: [
    {
      id: "sess-1",
      title: "Opening Keynote: Industrial AI and Automation in Pakistan's Manufacturing Sector",
      day: "Day 1 (Nov 12)",
      time: "09:30 AM - 10:45 AM",
      stage: "Main Auditorium (Grand Hall)",
      track: "Keynote",
      speakerName: "Dr. Tariq Mehmood",
      speakerRole: "Chief Scientist, PakRobotics Technologies",
      speakerAvatar: "TM",
      category: "Robotics & AI",
      capacity: 1200,
      registeredCount: 1140,
      isBookmarked: true,
      description: "An opening exploration of how autonomous multi-agent robotics and computer vision models are transforming industrial production lines across the nation."
    },
    {
      id: "sess-2",
      title: "Next-Gen Energy: Commercial Solar Microgrids and Grid Stabilization",
      day: "Day 1 (Nov 12)",
      time: "11:15 AM - 12:30 PM",
      stage: "Hall A Technical Stage",
      track: "Clean Tech",
      speakerName: "Muhammad Bilal Khan",
      speakerRole: "VP Engineering, Shams Clean Energy",
      speakerAvatar: "BK",
      category: "Renewable Energy",
      capacity: 450,
      registeredCount: 380,
      isBookmarked: false,
      description: "Real-world telemetry data and durability findings from 18 months of operating high-efficiency solar arrays in peak summer climates."
    },
    {
      id: "sess-3",
      title: "Hands-on Workshop: Sovereign Zero-Trust Cybersecurity for Enterprise IT",
      day: "Day 1 (Nov 12)",
      time: "02:00 PM - 03:30 PM",
      stage: "Hall B Hands-on Lab",
      track: "Cybersecurity",
      speakerName: "Fatima Zahra",
      speakerRole: "Head of Threat Intelligence, CyberDifa 360",
      speakerAvatar: "FZ",
      category: "Cybersecurity",
      capacity: 200,
      registeredCount: 195,
      isBookmarked: true,
      description: "Live terminal simulation of quantum-resistant key exchanges and kernel-level endpoint threat containment in enterprise banking environments."
    },
    {
      id: "sess-4",
      title: "Fireside Chat: Commercial Photonic Quantum Computing for Drug Discovery",
      day: "Day 2 (Nov 13)",
      time: "10:00 AM - 11:15 AM",
      stage: "Main Auditorium (Grand Hall)",
      track: "Quantum",
      speakerName: "Prof. Dr. Salman Farooqi",
      speakerRole: "Founder & CTO, Al-Khwarizmi Quantum Tech",
      speakerAvatar: "SF",
      category: "Hardware & Quantum",
      capacity: 900,
      registeredCount: 780,
      isBookmarked: false,
      description: "How room-temperature silicon photonics eliminates millions of dollars in cryogenic cooling overhead for pharmaceutical molecular simulation."
    },
    {
      id: "sess-5",
      title: "Medical Diagnostics Revolution: Continuous Biomarker Telemetry in Clinical Care",
      day: "Day 2 (Nov 13)",
      time: "01:30 PM - 02:45 PM",
      stage: "Hall A Technical Stage",
      track: "Healthcare",
      speakerName: "Dr. Zainab Qureshi, MD",
      speakerRole: "Chief Medical Officer, Shifa BioTech Dynamics",
      speakerAvatar: "ZQ",
      category: "Healthcare",
      capacity: 350,
      registeredCount: 290,
      isBookmarked: false,
      description: "Clinical trials and patient outcomes of non-invasive dermal patches monitoring vital metabolic indicators continuously."
    },
    {
      id: "sess-6",
      title: "Commercial EV Fleets: Localizing Battery Technology and Smart Dispatch",
      day: "Day 3 (Nov 14)",
      time: "11:00 AM - 12:30 PM",
      stage: "Main Auditorium",
      track: "Mobility",
      speakerName: "Hamza Usman",
      speakerRole: "Chief Architect, Karakoram AutoMobility",
      speakerAvatar: "HU",
      category: "Automotive",
      capacity: 850,
      registeredCount: 710,
      isBookmarked: true,
      description: "Coordinating localized commercial electric delivery fleets through AI battery lifecycle analysis and automated fleet dispatch."
    }
  ],

  analytics: {
    totalRegistrations: 8420,
    badgePickups: 6940,
    boothTrafficScans: 34812,
    avgSessionRating: 4.88,
    boothOccupancyRate: 79.2,
    topBoothsByTraffic: [
      { name: "PakRobotics Technologies (A-101)", visits: 4120, tier: "Corner Premium" },
      { name: "Al-Khwarizmi Quantum Tech (A-105)", visits: 3890, tier: "Island Pavilion" },
      { name: "Karakoram AutoMobility (B-201)", visits: 3340, tier: "Corner Premium" },
      { name: "Shams Clean Energy (A-102)", visits: 2980, tier: "Standard" },
      { name: "CyberDifa 360 (A-104)", visits: 2750, tier: "Corner Premium" }
    ],
    popularSessions: [
      { title: "Opening Keynote: Industrial AI in Pakistan", registrations: 1140, capacity: 1200 },
      { title: "Commercial Photonic Quantum Tech", registrations: 780, capacity: 900 },
      { title: "Commercial EV Fleets & Battery Tech", registrations: 710, capacity: 850 },
      { title: "Next-Gen Energy: Commercial Microgrids", registrations: 380, capacity: 450 },
      { title: "Sovereign Zero-Trust Lab", registrations: 195, capacity: 200 }
    ]
  },

  messages: [
    {
      id: "msg-1",
      sender: "Muhammad Bilal Khan (Shams Clean Energy)",
      senderRole: "Neighboring Exhibitor (Booth A-102)",
      preview: "Assalam-o-Alaikum team! Would love to explore solar power integration for your rovers on Day 2.",
      timestamp: "Today, 10:14 AM",
      unread: true,
      history: [
        { from: "them", text: "Assalam-o-Alaikum PakRobotics team! We're right next door at Booth A-102. Would love to explore solar-assisted charging integration for your warehouse cobots on Day 2 morning.", time: "10:14 AM" },
        { from: "me", text: "Wa Alaikum Assalam Bilal Bhai! That sounds like an excellent synergy. Let's meet at Booth A-101 tomorrow around 11:30 AM right after your session.", time: "10:28 AM" },
        { from: "them", text: "Insha'Allah, looking forward to meeting you!", time: "10:30 AM" }
      ]
    },
    {
      id: "msg-2",
      sender: "EventSphere Operations Desk",
      senderRole: "Expo Logistics Admin",
      preview: "Reminder: Booth electrical inspection scheduled for 8:00 AM on Day 1.",
      timestamp: "Yesterday, 4:45 PM",
      unread: false,
      history: [
        { from: "them", text: "Attention Exhibitors: Hall A safety and 220V electrical inspections will take place between 8:00 AM and 9:15 AM tomorrow morning before hall doors open. Please ensure all display wiring is grounded.", time: "4:45 PM" }
      ]
    },
    {
      id: "msg-3",
      sender: "Daniyal Malik (Shaheen AeroDrone)",
      senderRole: "Prospective Exhibitor",
      preview: "Can you confirm if ceiling crane rigging is available in Hall A for drone displays?",
      timestamp: "Oct 15, 2:10 PM",
      unread: false,
      history: [
        { from: "them", text: "Can you confirm if ceiling crane rigging is available in Hall A for agricultural drone displays?", time: "2:10 PM" },
        { from: "me", text: "Assalam-o-Alaikum Daniyal! Yes, ceiling rigging is permitted for Island Pavilion and Corner Premium booths upon submission of engineering structural load approval.", time: "3:00 PM" }
      ]
    }
  ],

  users: [
    { id: "usr-1", name: "Farhan Akhtar", email: "ops@eventsphere.example.pk", role: "Organizer Admin", organization: "EventSphere Operations", status: "Active", lastLogin: "Just now", avatar: "FA", phone: "+92 (21) 3456-7890" },
    { id: "usr-2", name: "Ayesha Siddiqui", email: "registration@eventsphere.example.pk", role: "Ops Coordinator", organization: "EventSphere Operations", status: "Active", lastLogin: "2 hours ago", avatar: "AS", phone: "+92 (42) 3589-1100" },
    { id: "usr-3", name: "Dr. Tariq Mehmood", email: "info@pakrobotics.example.pk", role: "Exhibitor Lead", organization: "PakRobotics Technologies", status: "Active", lastLogin: "10 mins ago", avatar: "TM", phone: "+92 (21) 3456-7890" },
    { id: "usr-4", name: "Muhammad Bilal Khan", email: "contact@shamsenergy.example.pk", role: "Exhibitor Lead", organization: "Shams Clean Energy", status: "Active", lastLogin: "Yesterday", avatar: "BK", phone: "+92 (51) 2234-567" },
    { id: "usr-5", name: "Fatima Zahra", email: "secops@cyberdifa.example.pk", role: "Exhibitor Lead", organization: "CyberDifa 360", status: "Active", lastLogin: "3 hours ago", avatar: "FZ", phone: "+92 (42) 3589-1122" },
    { id: "usr-6", name: "Muhammad Usman", email: "usman.khan@techpak.example.pk", role: "VIP Delegate", organization: "TechPak Systems", status: "Active", lastLogin: "Just now", avatar: "MU", phone: "+92 (300) 123-4567" },
    { id: "usr-7", name: "Zoya Ali", email: "zoya.ali@fintech.example.pk", role: "Industry Delegate", organization: "FinTech Frontier", status: "Active", lastLogin: "Yesterday", avatar: "ZA", phone: "+92 (321) 987-6543" },
    { id: "usr-8", name: "Bilal Tariq", email: "bilal@cloudworks.example.pk", role: "Student Researcher", organization: "FAST-NUCES", status: "Pending", lastLogin: "3 days ago", avatar: "BT", phone: "+92 (333) 445-5667" }
  ],

  feedbackItems: [
    { id: "fb-1", name: "Muhammad Usman", email: "usman.khan@techpak.example.pk", rating: 5, category: "Floor Plan Usability", comment: "The interactive 2D blueprint and pulsating map beacon made locating Booth A-101 effortless! Super smooth on mobile.", date: "Today, 11:30 AM", status: "Resolved", reply: "Thank you Usman! Glad the beacon helped your visit." },
    { id: "fb-2", name: "Dr. Zainab Qureshi", email: "support@shifabiotech.example.pk", rating: 5, category: "Booth Booking", comment: "Reserving Booth A-107 and checking 220V power specs was crystal clear. Exceptional interface.", date: "Yesterday, 3:15 PM", status: "Resolved", reply: "Thank you Dr. Zainab! We look forward to your keynote." },
    { id: "fb-3", name: "Engr. Haris Jahangir", email: "haris@pakpower.example.pk", rating: 4, category: "WiFi & Amenities", comment: "Could we have additional signage near Hall B freight elevator for heavy battery transit?", date: "Oct 19, 2026", status: "In Progress", reply: "Our logistics team is dispatching on-ground directional markers." },
    { id: "fb-4", name: "Prof. Salman Farooqi", email: "research@alkhwarizmi.example.pk", rating: 5, category: "Schedule Clarity", comment: "The day filter and 1-click personal agenda sync kept our lab team perfectly synchronized.", date: "Oct 18, 2026", status: "Resolved", reply: "Honored to support your quantum computing presentation!" }
  ],

  notifications: {
    admin: [
      { id: "notif-a1", title: "New Exhibitor Application", detail: "Shaheen AeroDrone Labs submitted SECP docs for Hall A Corner Booth.", time: "15 mins ago", unread: true, type: "application" },
      { id: "notif-a2", title: "RFID Telemetry Milestone", detail: "Booths in Hall A have exceeded 20,000 attendee interaction scans.", time: "1 hour ago", unread: false, type: "analytics" },
      { id: "notif-a3", title: "Electrical Inspection Scheduled", detail: "Hall A safety and 220V inspection scheduled for 8:00 AM tomorrow.", time: "Yesterday", unread: false, type: "logistics" }
    ],
    exhibitor: [
      { id: "notif-e1", title: "Booth Inspection Passed", detail: "Booth A-101 passed 220V grounding and safety checks with zero remarks.", time: "25 mins ago", unread: true, type: "success" },
      { id: "notif-e2", title: "B2B Appointment Request", detail: "Muhammad Usman requested a 15-min meeting at 11:30 AM on Day 2.", time: "1 hour ago", unread: true, type: "appointment" },
      { id: "notif-e3", title: "Marketing Brochure Downloaded", detail: "38 attendees scanned and downloaded your Shaheen-7 Cobot PDF brochure.", time: "3 hours ago", unread: false, type: "lead" }
    ],
    attendee: [
      { id: "notif-u1", title: "Session Starting in 15 Minutes", detail: "Opening Keynote: Industrial AI in Grand Auditorium begins at 09:30 AM.", time: "Just now", unread: true, type: "schedule" },
      { id: "notif-u2", title: "Meeting Confirmed", detail: "PakRobotics confirmed your meeting for 11:30 AM at Booth A-101.", time: "45 mins ago", unread: true, type: "appointment" },
      { id: "notif-u3", title: "Digital Badge Ready", detail: "Your contactless RFID NFC badge QR code is active for express entry.", time: "Yesterday", unread: false, type: "badge" }
    ]
  },

  appointments: [
    { id: "apt-1", exhibitorId: "ex-1", exhibitorName: "PakRobotics Technologies", boothId: "A-101", attendeeName: "Muhammad Usman", attendeeEmail: "usman.khan@techpak.example.pk", date: "Nov 13, 2026", time: "11:30 AM - 11:45 AM", topic: "Warehouse Palletizer Cobot integration for supply chain", status: "Confirmed" },
    { id: "apt-2", exhibitorId: "ex-2", exhibitorName: "Shams Clean Energy", boothId: "A-102", attendeeName: "Muhammad Usman", attendeeEmail: "usman.khan@techpak.example.pk", date: "Nov 14, 2026", time: "02:15 PM - 02:30 PM", topic: "Commercial rooftop solar microgrid installation inquiry", status: "Pending" }
  ]
};
