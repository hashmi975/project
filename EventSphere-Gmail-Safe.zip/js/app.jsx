
    const { useState, useEffect, useMemo } = React;

    // --- Clean Inline SVG Icon Library ---
    const Icon = ({ name, className = "w-5 h-5", ...props }) => {
      const icons = {
        document: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/>
          </svg>
        ),
        zap: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
          </svg>
        ),

        menu: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>
          </svg>
        ),

        sphere: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>
          </svg>
        ),
        search: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>
          </svg>
        ),
        calendar: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/>
          </svg>
        ),
        mapPin: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>
          </svg>
        ),
        users: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
          </svg>
        ),
        grid: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>
          </svg>
        ),
        bookmark: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
          </svg>
        ),
        bookmarkFilled: (
          <svg className={className} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>
          </svg>
        ),
        check: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        ),
        x: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M18 6 6 18"/><path d="m6 6 12 12"/>
          </svg>
        ),
        plus: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M5 12h14"/><path d="M12 5v14"/>
          </svg>
        ),
        message: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>
          </svg>
        ),
        shield: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>
          </svg>
        ),
        bell: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>
          </svg>
        ),
        arrowRight: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>
          </svg>
        ),
        building: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <rect width="16" height="20" x="4" y="2" rx="2" ry="2"/><path d="M9 22v-4h6v4"/><path d="M8 6h.01"/><path d="M16 6h.01"/><path d="M8 10h.01"/><path d="M16 10h.01"/><path d="M8 14h.01"/><path d="M16 14h.01"/>
          </svg>
        ),
        clock: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
          </svg>
        ),
        sparkles: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/>
          </svg>
        ),
        star: (
          <svg className={className} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="1" {...props}>
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
        ),
        fileText: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" x2="8" y1="13" y2="13"/><line x1="16" x2="8" y1="17" y2="17"/><line x1="10" x2="8" y1="9" y2="9"/>
          </svg>
        ),
        send: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/>
          </svg>
        ),
        user: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
          </svg>
        ),
        logIn: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" x2="3" y1="12" y2="12"/>
          </svg>
        ),
        barChart: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <line x1="12" x2="12" y1="20" y2="10"/><line x1="18" x2="18" y1="20" y2="4"/><line x1="6" x2="6" y1="20" y2="16"/>
          </svg>
        ),
        layers: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>
          </svg>
        ),
        helpCircle: (
          <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
            <circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" x2="12.01" y1="17" y2="17"/>
          </svg>
        )
      };
      return icons[name] || icons.sphere;
    };

    // --- Toast Notification Component ---
    const Toast = ({ message, type = "info", onClose }) => {
      useEffect(() => {
        const timer = setTimeout(onClose, 4000);
        return () => clearTimeout(timer);
      }, [onClose]);

      const colors = {
        success: "bg-emerald-800 text-white border-emerald-600",
        error: "bg-rose-800 text-white border-rose-600",
        info: "bg-slate-900 text-white border-slate-700"
      };

      return (
        <div className={`fixed bottom-6 right-6 z-50 flex items-center space-x-3 px-4 py-3 rounded-xl shadow-2xl border ${colors[type]} transition-all animate-bounce`}>
          <Icon name={type === "success" ? "check" : "bell"} className="w-5 h-5 text-emerald-400" />
          <span className="text-sm font-medium">{message}</span>
          <button onClick={onClose} className="text-slate-300 hover:text-white p-1">
            <Icon name="x" className="w-4 h-4" />
          </button>
        </div>
      );
    };

    // --- Main Application Component ---
    function App() {
      // Core State
      const [data, setData] = useState(() => window.EVENTSPHERE_DATA || {});
      const [currentRole, setCurrentRole] = useState("public"); // "public", "admin", "exhibitor", "attendee"
      const [activeTab, setActiveTab] = useState("home"); // contextual view tab
      const [toast, setToast] = useState(null);
      const [selectedExpoId, setSelectedExpoId] = useState("expo-1");
      const [highlightedBoothId, setHighlightedBoothId] = useState(null);
      const [selectedBoothModal, setSelectedBoothModal] = useState(null);
      const [selectedExpoDetail, setSelectedExpoDetail] = useState(null);
      const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
      const [expoDropdownOpen, setExpoDropdownOpen] = useState(false);
      const [portalDropdownOpen, setPortalDropdownOpen] = useState(false);
      const [mobileExpoOpen, setMobileExpoOpen] = useState(true);
      
      // Modals
      const [showAuthModal, setShowAuthModal] = useState(false);
      const [authModalMode, setAuthModalMode] = useState("login"); // login, register, forgot
      const [showCreateExpoModal, setShowCreateExpoModal] = useState(false);
      const [showAddSessionModal, setShowAddSessionModal] = useState(false);
      const [showFeedbackModal, setShowFeedbackModal] = useState(false);
      const [showContactModal, setShowContactModal] = useState(null); // exhibitor object

      // Active Authenticated User Profile (Pakistani Enterprise Profiles)
      const [isAuthenticated, setIsAuthenticated] = useState(false);
      const [currentUser, setCurrentUser] = useState({
        name: "Muhammad Usman",
        email: "usman.khan@techpak.example.pk",
        role: "attendee",
        organization: "TechPak Systems",
        phone: "+92 (300) 123-4567",
        avatar: "MU"
      });

      // Current Expo Object
      const activeExpo = useMemo(() => {
        return (data.expos || []).find(e => e.id === selectedExpoId) || (data.expos && data.expos[0]);
      }, [data.expos, selectedExpoId]);

      // Hash-based URL Routing Support
      useEffect(() => {
        const handleHashChange = () => {
          const rawHash = (window.location.hash || "").replace(/^#\/?/, "").toLowerCase();
          if (!rawHash || rawHash === "home") {
            setCurrentRole("public");
            setActiveTab("home");
          } else if (rawHash === "expos") {
            setCurrentRole("public");
            setActiveTab("expos");
          } else if (rawHash === "expo-details") {
            setCurrentRole("public");
            setActiveTab("expo-details");
          } else if (rawHash === "exhibitor-directory") {
            setCurrentRole("public");
            setActiveTab("exhibitor-directory");
          } else if (rawHash === "event-schedule") {
            setCurrentRole("public");
            setActiveTab("event-schedule");
          } else if (rawHash === "floorplan") {
            setCurrentRole("public");
            setActiveTab("floorplan");
          } else if (rawHash === "expo-feedback") {
            setCurrentRole("public");
            setActiveTab("expo-feedback");
          } else if (rawHash === "portal-admin" || rawHash === "admin") {
            setCurrentRole("admin");
            setActiveTab("overview");
          } else if (rawHash === "portal-exhibitor" || rawHash === "exhibitor") {
            setCurrentRole("exhibitor");
            setActiveTab("booth-selection");
          } else if (rawHash === "portal-attendee" || rawHash === "attendee") {
            setCurrentRole("attendee");
            setActiveTab("directory");
          } else if (rawHash === "about") {
            setCurrentRole("public");
            setActiveTab("about");
          } else if (rawHash === "contact") {
            setCurrentRole("public");
            setActiveTab("contact");
          }
        };

        handleHashChange();
        window.addEventListener("hashchange", handleHashChange);
        return () => window.removeEventListener("hashchange", handleHashChange);
      }, []);

      // Keep URL hash updated when user navigates
      useEffect(() => {
        let hash = activeTab;
        if (currentRole === "admin") hash = "portal-admin";
        else if (currentRole === "exhibitor") hash = "portal-exhibitor";
        else if (currentRole === "attendee") hash = "portal-attendee";

        if (hash && window.location.hash !== "#" + hash) {
          window.history.replaceState(null, null, "#" + hash);
        }
      }, [activeTab, currentRole]);

      // Show toast helper
      const triggerToast = (message, type = "success") => {
        setToast({ message, type });
      };

      // Role switcher handler (Interactive Persona Controller Sync)
      const handleRoleSwitch = (role) => {
        setCurrentRole(role);
        if (role === "public") {
          setActiveTab("home");
          setIsAuthenticated(false);
        } else if (role === "admin") {
          setActiveTab("overview");
          setIsAuthenticated(true);
          setCurrentUser({
            name: "Farhan Akhtar",
            email: "ops@eventsphere.example.pk",
            role: "admin",
            organization: "EventSphere Operations",
            phone: "+92 (21) 3456-7890",
            avatar: "FA"
          });
        } else if (role === "exhibitor") {
          setActiveTab("booth-selection");
          setIsAuthenticated(true);
          setCurrentUser({
            name: "Dr. Tariq Mehmood",
            email: "info@pakrobotics.example.pk",
            role: "exhibitor",
            organization: "PakRobotics Technologies",
            phone: "+92 (21) 3456-7890",
            avatar: "TM"
          });
        } else if (role === "attendee") {
          setActiveTab("directory");
          setIsAuthenticated(true);
          setCurrentUser({
            name: "Muhammad Usman",
            email: "usman.khan@techpak.example.pk",
            role: "attendee",
            organization: "TechPak Systems",
            phone: "+92 (300) 123-4567",
            avatar: "MU"
          });
        }
        triggerToast(`Switched view to: ${role === "public" ? "Public Guest" : role.toUpperCase()}`, "info");
      };

      // Handler: Successful Authentication (Login / Registration)
      const handleAuthSuccess = (userObj, mode) => {
        setIsAuthenticated(true);
        setCurrentUser(userObj);
        setCurrentRole(userObj.role);
        if (userObj.role === "admin") setActiveTab("overview");
        else if (userObj.role === "exhibitor") setActiveTab("booth-selection");
        else setActiveTab("directory");
        
        setShowAuthModal(false);
        if (mode === "register") {
          setData(prev => ({
            ...prev,
            users: [
              {
                id: `usr-${Date.now()}`,
                name: userObj.name,
                email: userObj.email,
                role: userObj.role === "admin" ? "Organizer Admin" : userObj.role === "exhibitor" ? "Exhibitor Lead" : "Trade Delegate",
                organization: userObj.organization || "Independent",
                status: "Active",
                lastLogin: "Just now",
                avatar: userObj.avatar,
                phone: userObj.phone || "+92 (300) 000-0000"
              },
              ...(prev.users || [])
            ]
          }));
          triggerToast(`Welcome, ${userObj.name}! Account registered successfully as ${userObj.role.toUpperCase()}.`, "success");
        } else {
          triggerToast(`Welcome back, ${userObj.name}! Signed in successfully.`, "success");
        }
      };

      // Handler: Attendee requests "Locate on Map"
      const handleLocateBooth = (boothId) => {
        setHighlightedBoothId(boothId);
        if (currentRole === "attendee") {
          setActiveTab("floorplan");
        } else {
          setActiveTab("floorplan");
        }
        triggerToast(`Highlighted Booth ${boothId} on interactive floor plan!`, "info");
      };

      // Handler: Toggle Bookmark Session
      const handleToggleBookmark = (sessionId) => {
        setData(prev => {
          const updatedSessions = prev.sessions.map(s => {
            if (s.id === sessionId) {
              const newState = !s.isBookmarked;
              triggerToast(newState ? "Added session to your personal agenda!" : "Removed session from agenda.", "info");
              return { ...s, isBookmarked: newState };
            }
            return s;
          });
          return { ...prev, sessions: updatedSessions };
        });
      };

      // Handler: Reserve Booth (Exhibitor)
      const handleReserveBooth = (boothId) => {
        setData(prev => {
          const updatedBooths = prev.booths.map(b => {
            if (b.id === boothId) {
              return {
                ...b,
                status: "reserved",
                exhibitorId: "my-company",
                exhibitorName: "AeroDrone Technologies (Your Firm)"
              };
            }
            return b;
          });
          return { ...prev, booths: updatedBooths };
        });
        setSelectedBoothModal(null);
        triggerToast(`Successfully reserved ${boothId}! Confirmation sent to operations.`, "success");
      };

      // Handler: Admin Approve/Reject Exhibitor Application
      const handleApplicationAction = (appId, newStatus) => {
        setData(prev => {
          const updatedApps = prev.applications.map(app => {
            if (app.id === appId) {
              return { ...app, status: newStatus };
            }
            return app;
          });
          return { ...prev, applications: updatedApps };
        });
        triggerToast(`Application marked as ${newStatus.toUpperCase()}`, newStatus === "approved" ? "success" : "info");
      };

      // Handler: Add New Expo
      const handleCreateExpoSubmit = (newExpo) => {
        setData(prev => ({
          ...prev,
          expos: [newExpo, ...prev.expos]
        }));
        setSelectedExpoId(newExpo.id);
        setShowCreateExpoModal(false);
        triggerToast(`New expo "${newExpo.title}" launched successfully!`, "success");
      };

      // Handler: Add New Session
      const handleCreateSessionSubmit = (newSession) => {
        setData(prev => ({
          ...prev,
          sessions: [newSession, ...prev.sessions]
        }));
        setShowAddSessionModal(false);
        triggerToast(`New session "${newSession.title}" added to agenda!`, "success");
      };

      return (
        <div className="flex-1 flex flex-col min-h-screen">
          
          {/* ======================================================== */}
          {/* 1. TOP INTERACTIVE PERSONA / DEMO SWITCHER BAR */}
          {/* ======================================================== */}
          <div className="bg-slate-900 text-slate-200 border-b border-slate-800 text-xs py-2 px-4 sticky top-0 z-40 shadow-sm">
            <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <span className="flex h-2 w-2 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="font-semibold text-slate-300 uppercase tracking-wider text-[11px]">Prototype Controller</span>
                <span className="text-slate-500 hidden sm:inline">|</span>
                <span className="text-slate-400 hidden sm:inline">Test the full frontend across all required user personas:</span>
              </div>

              <div className="flex items-center space-x-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
                <button
                  onClick={() => handleRoleSwitch("public")}
                  className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                    currentRole === "public"
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-400 hover:text-white hover:bg-slate-800"
                  }`}
                >
                  Public Visitor
                </button>
                <button
                  onClick={() => handleRoleSwitch("admin")}
                  className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center space-x-1 ${
                    currentRole === "admin"
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-400 hover:text-white hover:bg-slate-800"
                  }`}
                >
                  <Icon name="shield" className="w-3.5 h-3.5 text-indigo-300" />
                  <span>Admin / Organizer</span>
                </button>
                <button
                  onClick={() => handleRoleSwitch("exhibitor")}
                  className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center space-x-1 ${
                    currentRole === "exhibitor"
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-400 hover:text-white hover:bg-slate-800"
                  }`}
                >
                  <Icon name="building" className="w-3.5 h-3.5 text-indigo-300" />
                  <span>Exhibitor Portal</span>
                </button>
                <button
                  onClick={() => handleRoleSwitch("attendee")}
                  className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center space-x-1 ${
                    currentRole === "attendee"
                      ? "bg-indigo-600 text-white shadow-sm"
                      : "text-slate-400 hover:text-white hover:bg-slate-800"
                  }`}
                >
                  <Icon name="users" className="w-3.5 h-3.5 text-indigo-300" />
                  <span>Attendee Interface</span>
                </button>
              </div>

              {/* Expo Selector */}
              <div className="flex items-center space-x-2">
                <span className="text-slate-400 hidden md:inline">Active Expo:</span>
                <select
                  value={selectedExpoId}
                  onChange={(e) => {
                    setSelectedExpoId(e.target.value);
                    triggerToast(`Active expo changed!`, "info");
                  }}
                  className="bg-slate-800 text-slate-200 border border-slate-700 rounded-md px-2 py-1 text-xs focus:ring-1 focus:ring-indigo-500 outline-none"
                >
                  {(data.expos || []).map(exp => (
                    <option key={exp.id} value={exp.id}>{exp.title}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* ======================================================== */}
          {/* 2. MAIN HEADER NAVIGATION */}
          {/* ======================================================== */}
          <header className="bg-white border-b border-slate-200/80 sticky top-[41px] z-30 shadow-xs backdrop-blur-md bg-white/95">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
              
              {/* Brand Logo */}
              <div 
                className="flex items-center space-x-3 cursor-pointer group"
                onClick={() => {
                  if (currentRole === "public") setActiveTab("home");
                  else if (currentRole === "admin") setActiveTab("overview");
                  else if (currentRole === "exhibitor") setActiveTab("booth-selection");
                  else setActiveTab("directory");
                }}
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-700 to-blue-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
                  <Icon name="sphere" className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center space-x-1.5">
                    <span className="font-heading font-extrabold text-xl tracking-tight text-slate-900">EventSphere</span>
                    <span className="text-[10px] font-bold tracking-wider uppercase px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200/60">Expo OS</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight">Trade Show & Expo Suite</p>
                </div>
              </div>

                            {/* Contextual Navigation Tabs with Sleek Dropdowns */}
              <nav className="hidden lg:flex items-center space-x-1.5 text-xs font-bold">
                {/* 1. Home */}
                <button 
                  onClick={() => { handleRoleSwitch("public"); setActiveTab("home"); }}
                  className={`px-3 py-2 rounded-xl transition-all ${
                    currentRole === "public" && activeTab === "home" 
                      ? "text-[#0F172A] bg-[#F59E0B] shadow-xs font-extrabold" 
                      : "text-[#334155] hover:text-[#0F172A] hover:bg-slate-100"
                  }`}
                >
                  Home
                </button>

                {/* 2. Upcoming Expos DROPDOWN (5 Sub-Pages + Catalog) */}
                <div 
                  className="relative group"
                  onMouseEnter={() => setExpoDropdownOpen(true)}
                  onMouseLeave={() => setExpoDropdownOpen(false)}
                >
                  <button 
                    onClick={() => { setCurrentRole("public"); setActiveTab("expos"); }}
                    className={`px-3 py-2 rounded-xl transition-all flex items-center space-x-1.5 ${
                      currentRole === "public" && ["expos", "expo-details", "exhibitor-directory", "event-schedule", "floorplan", "expo-feedback"].includes(activeTab)
                        ? "text-[#0F172A] bg-[#F59E0B] shadow-xs font-extrabold"
                        : "text-[#334155] hover:text-[#0F172A] hover:bg-slate-100"
                    }`}
                  >
                    <span>Upcoming Expos</span>
                    <svg className={`w-3.5 h-3.5 transition-transform ${expoDropdownOpen ? "rotate-180" : ""}`} viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </button>

                  {/* Dropdown Menu Card */}
                  {expoDropdownOpen && (
                    <div className="absolute left-0 top-full pt-1.5 w-72 z-50">
                      <div className="rounded-2xl bg-white border border-[#CBD5E1] shadow-2xl p-2 space-y-1">
                        <div className="px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-[#64748B] border-b border-[#F1F5F9] flex justify-between items-center">
                          <span>Upcoming Expos Suite</span>
                          <span className="text-[#D97706] font-bold">5 Pages</span>
                        </div>
                        <button
                          onClick={() => { setCurrentRole("public"); setActiveTab("expos"); setExpoDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${activeTab === "expos" ? "text-[#D97706] font-bold bg-[#FEF3C7]" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">🎪</span>
                          <div>
                            <div className="font-bold">All Expos Catalog</div>
                            <div className="text-[10px] text-[#64748B]">National expo discovery & filter</div>
                          </div>
                        </button>
                        <button
                          onClick={() => { setCurrentRole("public"); setActiveTab("expo-details"); setExpoDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${activeTab === "expo-details" ? "text-[#D97706] font-bold bg-[#FEF3C7]" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">📄</span>
                          <div>
                            <div className="font-bold">1. Expo Details</div>
                            <div className="text-[10px] text-[#64748B]">Venue specs, capacity & description</div>
                          </div>
                        </button>
                        <button
                          onClick={() => { setCurrentRole("public"); setActiveTab("exhibitor-directory"); setExpoDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${activeTab === "exhibitor-directory" ? "text-[#D97706] font-bold bg-[#FEF3C7]" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">🏢</span>
                          <div>
                            <div className="font-bold">2. Exhibitor Directory</div>
                            <div className="text-[10px] text-[#64748B]">40+ verified vendors & booth tags</div>
                          </div>
                        </button>
                        <button
                          onClick={() => { setCurrentRole("public"); setActiveTab("event-schedule"); setExpoDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${activeTab === "event-schedule" ? "text-[#D97706] font-bold bg-[#FEF3C7]" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">📅</span>
                          <div>
                            <div className="font-bold">3. Event Schedule</div>
                            <div className="text-[10px] text-[#64748B]">4-day keynote tracks & agenda</div>
                          </div>
                        </button>
                        <button
                          onClick={() => { setCurrentRole("public"); setActiveTab("floorplan"); setExpoDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${activeTab === "floorplan" ? "text-[#D97706] font-bold bg-[#FEF3C7]" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">📐</span>
                          <div>
                            <div className="font-bold">4. Floorplan</div>
                            <div className="text-[10px] text-[#64748B]">Interactive 2D Hall A & B layout</div>
                          </div>
                        </button>
                        <button
                          onClick={() => { setCurrentRole("public"); setActiveTab("expo-feedback"); setExpoDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${activeTab === "expo-feedback" ? "text-[#D97706] font-bold bg-[#FEF3C7]" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">💬</span>
                          <div>
                            <div className="font-bold">5. Contact Us & Feedback</div>
                            <div className="text-[10px] text-[#64748B]">Support ticket, rating & suggestions</div>
                          </div>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* 3. Portals & Roles DROPDOWN (Aptech eProject Requirement) */}
                <div 
                  className="relative group"
                  onMouseEnter={() => setPortalDropdownOpen(true)}
                  onMouseLeave={() => setPortalDropdownOpen(false)}
                >
                  <button 
                    className={`px-3 py-2 rounded-xl transition-all flex items-center space-x-1.5 ${
                      currentRole !== "public" 
                        ? "text-[#0F172A] bg-[#F59E0B] shadow-xs font-extrabold" 
                        : "text-[#334155] hover:text-[#0F172A] hover:bg-slate-100"
                    }`}
                  >
                    <span>Portals & Dashboards</span>
                    <svg className={`w-3.5 h-3.5 transition-transform ${portalDropdownOpen ? "rotate-180" : ""}`} viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                    </svg>
                  </button>

                  {/* Portals Dropdown Card */}
                  {portalDropdownOpen && (
                    <div className="absolute left-0 top-full pt-1.5 w-64 z-50">
                      <div className="rounded-2xl bg-white border border-[#CBD5E1] shadow-2xl p-2 space-y-1">
                        <div className="px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-[#64748B] border-b border-[#F1F5F9]">
                          Select Persona
                        </div>
                        <button
                          onClick={() => { handleRoleSwitch("admin"); setActiveTab("overview"); setPortalDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${currentRole === "admin" ? "text-indigo-700 font-bold bg-indigo-50" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">⚡</span>
                          <div>
                            <div className="font-bold">Organizer Admin Hub</div>
                            <div className="text-[10px] text-[#64748B]">Floor allocator & approvals</div>
                          </div>
                        </button>
                        <button
                          onClick={() => { handleRoleSwitch("exhibitor"); setActiveTab("booth-selection"); setPortalDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${currentRole === "exhibitor" ? "text-indigo-700 font-bold bg-indigo-50" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">🏢</span>
                          <div>
                            <div className="font-bold">Exhibitor Portal</div>
                            <div className="text-[10px] text-[#64748B]">Reserve booth & B2B inquiries</div>
                          </div>
                        </button>
                        <button
                          onClick={() => { handleRoleSwitch("attendee"); setActiveTab("directory"); setPortalDropdownOpen(false); }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center space-x-2.5 transition-colors ${currentRole === "attendee" ? "text-indigo-700 font-bold bg-indigo-50" : "text-[#0F172A] hover:bg-[#F1F5F9]"}`}
                        >
                          <span className="text-base">🎟️</span>
                          <div>
                            <div className="font-bold">Attendee Experience</div>
                            <div className="text-[10px] text-[#64748B]">Beacon map & agenda bookmark</div>
                          </div>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* 4. About Us */}
                <button 
                  onClick={() => { handleRoleSwitch("public"); setActiveTab("about"); }}
                  className={`px-3 py-2 rounded-xl transition-all ${
                    currentRole === "public" && activeTab === "about" 
                      ? "text-[#0F172A] bg-[#F59E0B] shadow-xs font-extrabold" 
                      : "text-[#334155] hover:text-[#0F172A] hover:bg-slate-100"
                  }`}
                >
                  About Us
                </button>

                {/* 5. Contact Us */}
                <button 
                  onClick={() => { handleRoleSwitch("public"); setActiveTab("contact"); }}
                  className={`px-3 py-2 rounded-xl transition-all ${
                    currentRole === "public" && (activeTab === "contact" || activeTab === "expo-feedback") 
                      ? "text-[#0F172A] bg-[#F59E0B] shadow-xs font-extrabold" 
                      : "text-[#334155] hover:text-[#0F172A] hover:bg-slate-100"
                  }`}
                >
                  Contact Us
                </button>
              </nav>

              {/* Right Action Icons & Auth Controls */}
              <div className="flex items-center space-x-3">
                {/* Mobile menu toggle */}
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="md:hidden p-2 rounded-lg text-slate-700 hover:text-indigo-600 hover:bg-slate-100 transition-colors"
                  title="Toggle Mobile Navigation"
                >
                  <Icon name={mobileMenuOpen ? "x" : "menu"} className="w-5 h-5" />
                </button>

                {/* Feedback button */}
                <button
                  onClick={() => setShowFeedbackModal(true)}
                  title="Feedback & Support"
                  className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  <Icon name="helpCircle" className="w-5 h-5" />
                </button>

                {/* Notifications trigger */}
                <button 
                  onClick={() => triggerToast("All systems operational. No unread critical alerts.", "info")}
                  title="Notifications"
                  className="p-2 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors relative"
                >
                  <Icon name="bell" className="w-5 h-5" />
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-indigo-600 ring-2 ring-white"></span>
                </button>

                {/* Account / Auth Button (Pakistani Enterprise Profiles) */}
                {!isAuthenticated && currentRole === "public" ? (
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => { setAuthModalMode("login"); setShowAuthModal(true); }}
                      className="px-3.5 py-2 text-xs font-bold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
                    >
                      Sign In
                    </button>
                    <button
                      onClick={() => { setAuthModalMode("register"); setShowAuthModal(true); }}
                      className="px-4 py-2 text-xs font-bold text-[#0F172A] bg-[#F59E0B] hover:bg-[#D97706] rounded-xl shadow-xs transition-all"
                    >
                      Register
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2 pl-2 border-l border-slate-200">
                    <div className="w-8 h-8 rounded-full bg-slate-900 text-[#F59E0B] flex items-center justify-center font-extrabold text-xs border border-slate-800 shadow-xs">
                      {currentUser?.avatar || (currentRole === "admin" ? "FA" : currentRole === "exhibitor" ? "TM" : "MU")}
                    </div>
                    <div className="hidden lg:block text-left">
                      <div className="text-xs font-bold text-slate-900 leading-tight">
                        {currentUser?.name || (currentRole === "admin" ? "Farhan Akhtar" : currentRole === "exhibitor" ? "Dr. Tariq Mehmood" : "Muhammad Usman")}
                      </div>
                      <div className="text-[10px] text-slate-500 capitalize font-medium">{currentRole} Access • {currentUser?.organization || (currentRole === "admin" ? "EventSphere Ops" : currentRole === "exhibitor" ? "PakRobotics Tech" : "TechPak Systems")}</div>
                    </div>
                    <button
                      onClick={() => {
                        setIsAuthenticated(false);
                        handleRoleSwitch("public");
                        triggerToast("Signed out successfully. Switched to Public Guest view.", "info");
                      }}
                      title="Sign Out / Switch to Public"
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-100"
                    >
                      <Icon name="logIn" className="w-4 h-4 rotate-180" />
                    </button>
                  </div>
                )}
              </div>
            </div>

                        {/* Mobile Navigation Drawer with Accordion Dropdown */}
            {mobileMenuOpen && (
              <div className="lg:hidden border-t border-slate-200 bg-white/98 backdrop-blur-md px-4 py-4 space-y-3 shadow-2xl max-h-[85vh] overflow-y-auto">
                {/* Section 1: Upcoming Expos (5 Pages Dropdown) */}
                <div className="space-y-1.5 p-3 rounded-2xl bg-[#F8FAFC] border border-[#CBD5E1]">
                  <div 
                    onClick={() => setMobileExpoOpen(!mobileExpoOpen)}
                    className="flex items-center justify-between cursor-pointer text-xs font-extrabold text-[#0F172A]"
                  >
                    <span className="flex items-center space-x-1.5">
                      <span>🎪</span>
                      <span>Upcoming Expos (5 Pages)</span>
                    </span>
                    <span className="text-[#D97706] text-[11px] font-bold">
                      {mobileExpoOpen ? "▲ Hide" : "▼ Show (5)"}
                    </span>
                  </div>

                  {mobileExpoOpen && (
                    <div className="grid grid-cols-2 gap-2 pt-2 text-xs font-bold">
                      <button
                        onClick={() => { setCurrentRole("public"); setActiveTab("expo-details"); setMobileMenuOpen(false); }}
                        className={`p-2.5 rounded-xl text-left border flex items-center space-x-1.5 ${activeTab === "expo-details" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                      >
                        <span>📄</span>
                        <span className="truncate">1. Expo Details</span>
                      </button>
                      <button
                        onClick={() => { setCurrentRole("public"); setActiveTab("exhibitor-directory"); setMobileMenuOpen(false); }}
                        className={`p-2.5 rounded-xl text-left border flex items-center space-x-1.5 ${activeTab === "exhibitor-directory" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                      >
                        <span>🏢</span>
                        <span className="truncate">2. Directory</span>
                      </button>
                      <button
                        onClick={() => { setCurrentRole("public"); setActiveTab("event-schedule"); setMobileMenuOpen(false); }}
                        className={`p-2.5 rounded-xl text-left border flex items-center space-x-1.5 ${activeTab === "event-schedule" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                      >
                        <span>📅</span>
                        <span className="truncate">3. Schedule</span>
                      </button>
                      <button
                        onClick={() => { setCurrentRole("public"); setActiveTab("floorplan"); setMobileMenuOpen(false); }}
                        className={`p-2.5 rounded-xl text-left border flex items-center space-x-1.5 ${activeTab === "floorplan" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                      >
                        <span>📐</span>
                        <span className="truncate">4. Floorplan</span>
                      </button>
                      <button
                        onClick={() => { setCurrentRole("public"); setActiveTab("expo-feedback"); setMobileMenuOpen(false); }}
                        className={`p-2.5 rounded-xl text-left border flex items-center space-x-1.5 ${activeTab === "expo-feedback" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                      >
                        <span>💬</span>
                        <span className="truncate">5. Feedback</span>
                      </button>
                      <button
                        onClick={() => { setCurrentRole("public"); setActiveTab("expos"); setMobileMenuOpen(false); }}
                        className={`p-2.5 rounded-xl text-left border flex items-center space-x-1.5 ${activeTab === "expos" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                      >
                        <span>🎪</span>
                        <span className="truncate">All Expos</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Section 2: General Public Navigation */}
                <div className="grid grid-cols-3 gap-2 text-xs font-bold">
                  <button
                    onClick={() => { handleRoleSwitch("public"); setActiveTab("home"); setMobileMenuOpen(false); }}
                    className={`p-2 rounded-xl text-center border ${currentRole === "public" && activeTab === "home" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                  >
                    🏠 Home
                  </button>
                  <button
                    onClick={() => { handleRoleSwitch("public"); setActiveTab("about"); setMobileMenuOpen(false); }}
                    className={`p-2 rounded-xl text-center border ${currentRole === "public" && activeTab === "about" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                  >
                    ℹ️ About
                  </button>
                  <button
                    onClick={() => { handleRoleSwitch("public"); setActiveTab("contact"); setMobileMenuOpen(false); }}
                    className={`p-2 rounded-xl text-center border ${currentRole === "public" && activeTab === "contact" ? "bg-[#F59E0B] text-[#0F172A] border-[#F59E0B] font-extrabold" : "bg-white border-[#E2E8F0] text-[#0F172A]"}`}
                  >
                    📞 Contact
                  </button>
                </div>

                {/* Section 3: Portals (Aptech Spec) */}
                <div className="p-3 rounded-2xl bg-[#0F172A] text-white space-y-2">
                  <div className="text-[10px] uppercase font-extrabold tracking-wider text-[#94A3B8]">
                    Portals & Dashboards (Aptech eProject)
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[11px] font-bold">
                    <button
                      onClick={() => { handleRoleSwitch("admin"); setActiveTab("overview"); setMobileMenuOpen(false); }}
                      className={`p-2 rounded-xl text-center border ${currentRole === "admin" ? "bg-[#F59E0B] text-[#0F172A] font-extrabold" : "bg-[#1E293B] border-[#334155] text-white"}`}
                    >
                      ⚡ Admin
                    </button>
                    <button
                      onClick={() => { handleRoleSwitch("exhibitor"); setActiveTab("booth-selection"); setMobileMenuOpen(false); }}
                      className={`p-2 rounded-xl text-center border ${currentRole === "exhibitor" ? "bg-[#F59E0B] text-[#0F172A] font-extrabold" : "bg-[#1E293B] border-[#334155] text-white"}`}
                    >
                      🏢 Exhibitor
                    </button>
                    <button
                      onClick={() => { handleRoleSwitch("attendee"); setActiveTab("directory"); setMobileMenuOpen(false); }}
                      className={`p-2 rounded-xl text-center border ${currentRole === "attendee" ? "bg-[#F59E0B] text-[#0F172A] font-extrabold" : "bg-[#1E293B] border-[#334155] text-white"}`}
                    >
                      🎟️ Attendee
                    </button>
                  </div>
                </div>
              </div>
            )}
          </header>

          {/* ======================================================== */}
          {/* 3. DYNAMIC BODY VIEWS BASED ON ROLE & TAB */}
          {/* ======================================================== */}
          <main className="flex-1 pb-16">
            
                        {/* VIEW A: PUBLIC HOME / LANDING */}
            {currentRole === "public" && activeTab === "home" && (
              <PublicLandingView 
                expos={data.expos}
                booths={data.booths}
                sessions={data.sessions}
                onSelectExpo={(id) => {
                  const found = data.expos.find(e => e.id === id);
                  setSelectedExpoDetail(found || data.expos[0]);
                }}
                onExhibitorApply={() => {
                  handleRoleSwitch("exhibitor");
                }}
                onExploreSchedule={() => {
                  setActiveTab("event-schedule");
                }}
                onExploreFloor={() => {
                  setActiveTab("floorplan");
                }}
              />
            )}

            {/* VIEW B: ABOUT US */}
            {currentRole === "public" && activeTab === "about" && (
              <AboutUsView 
                onContact={() => setActiveTab("contact")}
                onExploreExpos={() => setActiveTab("expos")}
              />
            )}

            {/* VIEW C: ALL EXPOS CATALOG */}
            {currentRole === "public" && activeTab === "expos" && (
              <UpcomingExposView 
                expos={data.expos}
                activeExpo={activeExpo}
                onSelectExpo={(exp) => setSelectedExpoDetail(exp)}
                onViewExpoDetails={(exp) => {
                  setSelectedExpoId(exp.id);
                  setActiveTab("expo-details");
                }}
                onNavigate={(tab, expoId) => {
                  if (expoId) setSelectedExpoId(expoId);
                  setActiveTab(tab);
                }}
                onExhibitorApply={() => {
                  handleRoleSwitch("exhibitor");
                }}
              />
            )}

            {/* SUB-PAGE 1: EXPO DETAILS */}
            {currentRole === "public" && activeTab === "expo-details" && (
              <ExpoDetailsPageView 
                activeExpo={activeExpo}
                expos={data.expos}
                onSelectExpo={(exp) => {
                  setSelectedExpoId(exp.id);
                  setSelectedExpoDetail(exp);
                }}
                onSwitchExpo={(expoId) => {
                  setSelectedExpoId(expoId);
                }}
                onNavigate={(tab, expoId) => {
                  if (expoId) setSelectedExpoId(expoId);
                  setActiveTab(tab);
                }}
                onExhibitorApply={() => {
                  handleRoleSwitch("exhibitor");
                }}
                onRegisterAttendee={() => {
                  handleRoleSwitch("attendee");
                }}
              />
            )}

            {/* SUB-PAGE 2: EXHIBITOR DIRECTORY */}
            {currentRole === "public" && activeTab === "exhibitor-directory" && (
              <PublicExhibitorDirectoryView 
                activeExpo={activeExpo}
                expos={data.expos}
                exhibitors={data.exhibitors}
                onSwitchExpo={(expoId) => setSelectedExpoId(expoId)}
                onNavigate={(tab) => setActiveTab(tab)}
                onLocateBooth={handleLocateBooth}
                onContactExhibitor={(ex) => setShowContactModal(ex)}
              />
            )}

            {/* SUB-PAGE 3: EVENT SCHEDULE */}
            {currentRole === "public" && activeTab === "event-schedule" && (
              <PublicEventScheduleView 
                activeExpo={activeExpo}
                expos={data.expos}
                sessions={data.sessions}
                onSwitchExpo={(expoId) => setSelectedExpoId(expoId)}
                onNavigate={(tab) => setActiveTab(tab)}
                onToggleBookmark={handleToggleBookmark}
                triggerToast={triggerToast}
              />
            )}

            {/* SUB-PAGE 4: FLOORPLAN */}
            {currentRole === "public" && activeTab === "floorplan" && (
              <PublicFloorPlanView 
                activeExpo={activeExpo}
                expos={data.expos}
                booths={data.booths}
                highlightedBoothId={highlightedBoothId}
                onSwitchExpo={(expoId) => setSelectedExpoId(expoId)}
                onNavigate={(tab) => setActiveTab(tab)}
                onSelectBooth={(b) => setSelectedBoothModal(b)}
                onReserveBooth={handleReserveBooth}
              />
            )}

            {/* SUB-PAGE 5: CONTACT US & FEEDBACK */}
            {currentRole === "public" && (activeTab === "expo-feedback" || activeTab === "contact") && (
              <PublicFeedbackPageView 
                activeExpo={activeExpo}
                expos={data.expos}
                onSwitchExpo={(expoId) => setSelectedExpoId(expoId)}
                onNavigate={(tab) => setActiveTab(tab)}
                triggerToast={triggerToast}
              />
            )}

            {/* VIEW D: ADMIN / ORGANIZER DASHBOARD */}
            {currentRole === "admin" && (
              <AdminDashboardView 
                activeExpo={activeExpo}
                data={data}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                booths={data.booths}
                applications={data.applications}
                sessions={data.sessions}
                analytics={data.analytics}
                onSelectBooth={(b) => setSelectedBoothModal(b)}
                onApproveReject={handleApplicationAction}
                onOpenCreateExpo={() => setShowCreateExpoModal(true)}
                onOpenAddSession={() => setShowAddSessionModal(true)}
              />
            )}

            {/* VIEW E: EXHIBITOR ENTERPRISE PORTAL */}
            {currentRole === "exhibitor" && (
              <ExhibitorPortalView 
                activeExpo={activeExpo}
                booths={data.booths}
                exhibitors={data.exhibitors}
                messages={data.messages}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                onSelectBooth={(b) => setSelectedBoothModal(b)}
                onReserveBooth={handleReserveBooth}
                triggerToast={triggerToast}
              />
            )}

            {/* VIEW F: ATTENDEE SMART INTERFACE */}
            {currentRole === "attendee" && (
              <AttendeeView 
                activeExpo={activeExpo}
                exhibitors={data.exhibitors}
                booths={data.booths}
                sessions={data.sessions}
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                highlightedBoothId={highlightedBoothId}
                onLocateBooth={handleLocateBooth}
                onToggleBookmark={handleToggleBookmark}
                onContactExhibitor={(ex) => setShowContactModal(ex)}
                onSelectBooth={(b) => setSelectedBoothModal(b)}
              />
            )}

          </main>

          {/* ======================================================== */}
          {/* 4. FOOTER */}
          {/* ======================================================== */}
          <footer className="bg-slate-900 text-slate-400 text-sm border-t border-slate-800">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                <div className="space-y-4 md:col-span-1">
                  <div className="flex items-center space-x-2 text-white">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
                      <Icon name="sphere" className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-heading font-bold text-lg text-white">EventSphere</span>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    The end-to-end cloud infrastructure for organizing, exhibiting, and attending world-class expos and trade shows.
                  </p>
                  <div className="flex space-x-3 pt-2">
                    <span className="px-2 py-1 text-[11px] rounded bg-slate-800 text-emerald-400 border border-emerald-500/20 font-medium flex items-center space-x-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span>System Online 99.98%</span>
                    </span>
                  </div>
                </div>

                <div>
                  <h4 className="text-white font-semibold text-xs tracking-wider uppercase mb-3 font-heading">For Organizers</h4>
                  <ul className="space-y-2 text-xs">
                    <li><button onClick={() => { handleRoleSwitch("admin"); setActiveTab("overview"); }} className="hover:text-white transition-colors">Expo Command Center</button></li>
                    <li><button onClick={() => { handleRoleSwitch("admin"); setActiveTab("floorplan"); }} className="hover:text-white transition-colors">Interactive Booth Allocator</button></li>
                    <li><button onClick={() => { handleRoleSwitch("admin"); setActiveTab("applications"); }} className="hover:text-white transition-colors">Exhibitor Approval Queue</button></li>
                    <li><button onClick={() => { handleRoleSwitch("admin"); setActiveTab("schedule"); }} className="hover:text-white transition-colors">Multi-Track Agenda Builder</button></li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-white font-semibold text-xs tracking-wider uppercase mb-3 font-heading">For Exhibitors & Guests</h4>
                  <ul className="space-y-2 text-xs">
                    <li><button onClick={() => { handleRoleSwitch("exhibitor"); setActiveTab("booth-selection"); }} className="hover:text-white transition-colors">Booth Reservation Map</button></li>
                    <li><button onClick={() => { handleRoleSwitch("exhibitor"); setActiveTab("profile"); }} className="hover:text-white transition-colors">Company Catalog & Showcase</button></li>
                    <li><button onClick={() => { handleRoleSwitch("attendee"); setActiveTab("directory"); }} className="hover:text-white transition-colors">Exhibitor Directory & Matchmaking</button></li>
                    <li><button onClick={() => { handleRoleSwitch("attendee"); setActiveTab("agenda"); }} className="hover:text-white transition-colors">Personalized Schedule Builder</button></li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-white font-semibold text-xs tracking-wider uppercase mb-3 font-heading">Platform Architecture</h4>
                  <p className="text-xs text-slate-400 leading-relaxed mb-3">
                    Built according to enterprise specifications: React 18, Tailwind CSS, real-time interactive floor plan engine, and WCAG-compliant responsive design.
                  </p>
                  <button
                    onClick={() => setShowFeedbackModal(true)}
                    className="w-full text-center px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 border border-slate-700 font-medium transition-colors"
                  >
                    Submit System Feedback / Report
                  </button>
                </div>
              </div>

              <div className="pt-8 border-t border-slate-800 text-center text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-4">
                <p>© 2026 EventSphere Management Technologies Inc. All rights reserved.</p>
                <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-slate-400 text-xs">
                  <button onClick={() => { handleRoleSwitch("public"); setActiveTab("home"); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">Home</button>
                  <button onClick={() => { handleRoleSwitch("public"); setActiveTab("expos"); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">Upcoming Expos</button>
                  <button onClick={() => { handleRoleSwitch("attendee"); setActiveTab("floorplan"); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">Floor Plans</button>
                  <button onClick={() => { handleRoleSwitch("attendee"); setActiveTab("directory"); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">Exhibitors</button>
                  <button onClick={() => { handleRoleSwitch("attendee"); setActiveTab("agenda"); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">Schedule</button>
                  <button onClick={() => { handleRoleSwitch("public"); setActiveTab("about"); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">About Us</button>
                  <button onClick={() => { handleRoleSwitch("public"); setActiveTab("contact"); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="hover:text-amber-400 transition-colors">Contact Us</button>
                </div>
              </div>
            </div>
          </footer>

          {/* ======================================================== */}
          {/* 5. MODALS & DIALOGS */}
          {/* ======================================================== */}

          {/* Booth Details Modal */}
          {/* Expo Detail Modal */}
            {selectedExpoDetail && (
              <ExpoDetailModal 
                expo={selectedExpoDetail}
                onClose={() => setSelectedExpoDetail(null)}
                onReserveBooth={() => {
                  setSelectedExpoDetail(null);
                  handleRoleSwitch("exhibitor");
                }}
                onRegisterAttendee={() => {
                  setSelectedExpoDetail(null);
                  handleRoleSwitch("attendee");
                }}
              />
            )}

            {selectedBoothModal && (
            <BoothDetailModal 
              booth={selectedBoothModal}
              role={currentRole}
              onClose={() => setSelectedBoothModal(null)}
              onReserve={(id) => handleReserveBooth(id)}
              onLocate={(id) => handleLocateBooth(id)}
            />
          )}

          {/* Authentication Modal */}
          {showAuthModal && (
            <AuthModal 
              mode={authModalMode}
              setMode={setAuthModalMode}
              onClose={() => setShowAuthModal(false)}
              onSuccess={handleAuthSuccess}
            />
          )}

          {/* Create Expo Modal */}
          {showCreateExpoModal && (
            <CreateExpoModal 
              onClose={() => setShowCreateExpoModal(false)}
              onSubmit={handleCreateExpoSubmit}
            />
          )}

          {/* Add Session Modal */}
          {showAddSessionModal && (
            <AddSessionModal 
              onClose={() => setShowAddSessionModal(false)}
              onSubmit={handleCreateSessionSubmit}
            />
          )}

          {/* Contact Exhibitor Modal */}
          {showContactModal && (
            <ContactExhibitorModal 
              exhibitor={showContactModal}
              onClose={() => setShowContactModal(null)}
              onSubmit={(msg) => {
                setShowContactModal(null);
                triggerToast(`Inquiry transmitted to ${showContactModal.name}!`, "success");
              }}
            />
          )}

          {/* Feedback & Support Modal */}
          {showFeedbackModal && (
            <FeedbackModal 
              onClose={() => setShowFeedbackModal(false)}
              onSubmit={(fb) => {
                setShowFeedbackModal(false);
                triggerToast("Thank you! Your feedback has been forwarded to our team.", "success");
              }}
            />
          )}

          {/* Toast Notification Popup */}
          {toast && (
            <Toast 
              message={toast.message} 
              type={toast.type} 
              onClose={() => setToast(null)} 
            />
          )}

        </div>
      );
    }

    // ========================================================
    // VIEW SUB-COMPONENT: PUBLIC LANDING VIEW
    // ========================================================
    // ========================================================
    // VIEW SUB-COMPONENT: PUBLIC LANDING VIEW (EXPANDED HUMAN-CRAFTED)
    // ========================================================
    function PublicLandingView({ 
      expos, 
      booths = [], 
      sessions = [], 
      onSelectExpo, 
      onExhibitorApply, 
      onExploreSchedule,
      onExploreFloor 
    }) {
      const scrollToSection = (id) => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      };
      const [categoryFilter, setCategoryFilter] = useState("all");
      const [searchTerm, setSearchTerm] = useState("");
      const [openFaq, setOpenFaq] = useState(0); // active accordion index
      const [newsletterEmail, setNewsletterEmail] = useState("");
      const [subscribed, setSubscribed] = useState(false);

      const categories = ["all", "Technology & AI", "Renewable Energy", "Automotive & Mobility", "Healthcare & Life Sciences"];

      const filteredExpos = expos.filter(e => {
        const matchesCat = categoryFilter === "all" || e.category === categoryFilter;
        const matchesSearch = e.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                              e.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              e.tagline.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesCat && matchesSearch;
      });

      // Keynote Speakers Data
      const keynoteSpeakers = [
        {
          name: "Dr. Tariq Mehmood",
          role: "Chief Scientist & Founder",
          company: "PakRobotics Technologies",
          topic: "Industrial Embodied AI & Cobots in Manufacturing",
          sessionTime: "Nov 12 • 09:30 AM (Grand Hall)",
          avatar: "TM",
          badgeColor: "bg-[#fff7ed] text-[#c2410c] border-[#fed7aa]"
        },
        {
          name: "Fatima Zahra",
          role: "Head of Threat Intelligence",
          company: "CyberDifa 360",
          topic: "Sovereign Zero-Trust Cryptographic Mesh for Enterprise",
          sessionTime: "Nov 12 • 02:00 PM (Lab Hall B)",
          avatar: "FZ",
          badgeColor: "bg-[#fefce8] text-[#854d0e] border-[#fde68a]"
        },
        {
          name: "Prof. Dr. Salman Farooqi",
          role: "Director of Optical Quantum Labs",
          company: "Al-Khwarizmi Quantum Tech",
          topic: "Room-Temperature Photonic Chips for Drug Discovery",
          sessionTime: "Nov 13 • 10:00 AM (Main Arena)",
          avatar: "SF",
          badgeColor: "bg-[#fffbeb] text-[#92400e] border-[#fcd34d]"
        },
        {
          name: "Dr. Zainab Qureshi, MD",
          role: "Chief Medical Officer",
          company: "Shifa BioTech Dynamics",
          topic: "Continuous Dermal Biosensors & Clinical Oncology",
          sessionTime: "Nov 13 • 01:30 PM (Hall A Stage)",
          avatar: "ZQ",
          badgeColor: "bg-[#fff7ed] text-[#c2410c] border-[#fed7aa]"
        }
      ];

      // National Venues Data
      const venues = [
        {
          city: "Karachi, Sindh",
          name: "Expo Centre Karachi",
          specs: "6 Exhibition Halls • 40,000 sqm • 15,000 Capacity",
          highlight: "Pakistan's primary industrial and international commerce gateway.",
          badge: "Main Coastal Hub"
        },
        {
          city: "Lahore, Punjab",
          name: "Lahore International Expo Centre",
          specs: "Dual Plenary Halls • Johar Town • 18,000 Capacity",
          highlight: "State-of-the-art facility hosting automotive, IT, and consumer summits.",
          badge: "Cultural & Tech Hub"
        },
        {
          city: "Islamabad, Capital",
          name: "Pak-China Friendship Centre",
          specs: "Main Convention Hall • Diplomatic Enclave • 12,000 Capacity",
          highlight: "Dedicated to bilateral summits, clean energy, and trade delegations.",
          badge: "Bilateral Pavilion"
        },
        {
          city: "Islamabad, Capital",
          name: "Jinnah Convention Centre",
          specs: "Iconic Plenary Dome • Executive Suites • 10,000 Capacity",
          highlight: "Premier venue for national healthcare, scientific, and governance summits.",
          badge: "National Concourse"
        }
      ];

      // Testimonials Data
      const testimonials = [
        {
          quote: "EventSphere eliminated over 300 disjointed email threads and paper CAD blueprints for our Karachi exhibition. Exhibitors booked 80% of prime booths within the first 48 hours.",
          author: "Engr. Syed Farhan Akhtar",
          title: "Senior Director of Operations",
          org: "Pakistan Trade & Expo Authority",
          avatar: "FA"
        },
        {
          quote: "Reserving our corner booth in Hall A with verified 220V power specs took under two minutes. The direct B2B chat allowed us to pre-book 14 high-value distributor demos before the expo even opened.",
          author: "Dr. Tariq Mehmood",
          title: "Founder & Chief Roboticist",
          org: "PakRobotics Technologies",
          avatar: "TM"
        },
        {
          quote: "The interactive 'Locate on Map' pulsing beacon guided me straight to Booth A-105 through a crowded hall of 8,000 visitors. I bookmarked 5 keynotes and never missed a single session.",
          author: "Ayesha Siddiqui",
          title: "Lead Systems Architect & Attendee",
          org: "Tech Innovations Forum",
          avatar: "AS"
        }
      ];

      // FAQs Data
      const faqs = [
        {
          q: "How does EventSphere prevent double-booking on the 2D floor plan?",
          a: "The floor plan allocator utilizes atomic state synchronization. When an exhibitor or organizer selects an available booth, its status updates instantly across all connected screens within 200 milliseconds, ensuring that no space can be booked simultaneously."
        },
        {
          q: "What verification documents are required for exhibitor application approval?",
          a: "Exhibitors submit their Company NTN / SEC Registration Certificate, technical product datasheets, and safety compliance reports. Organizers inspect these documents in the Approval Queue before finalizing booth assignments."
        },
        {
          q: "Can attendees create a personalized schedule with reminders?",
          a: "Yes! Attendees can click 'Add to My Agenda' on any session. You can filter between the complete conference agenda and 'Show My Agenda Only', with automatic notification alerts before session start times."
        },
        {
          q: "Are electrical power, fiber internet, and delegate passes included in booth pricing?",
          a: "Every booth card displays its exact utility specifications: dedicated 220V outlets, high-speed fiber LAN, carpeted flooring, and 1 to 4 VIP conference passes depending on whether you choose Standard, Corner Premium, or an Island Pavilion."
        },
        {
          q: "Can organizers add new expos and multi-track workshops dynamically?",
          a: "Yes. From the Admin Control Hub, organizers can create new expos with custom venues and dates, add multi-track sessions with speaker assignments, and monitor real-time RFID foot-traffic telemetry across all halls."
        }
      ];

      const handleNewsletterSubmit = (e) => {
        e.preventDefault();
        if (!newsletterEmail.trim()) return;
        setSubscribed(true);
      };

      return (
        <div className="space-y-20">
          
          {/* ======================================================== */}
          {/* 1. HERO SECTION (ULTRA-READABLE & HIGH CONTRAST)         */}
          {/* ======================================================== */}
          <section className="relative overflow-hidden bg-[#0B0F19] text-white pt-12 sm:pt-16 pb-16 sm:pb-20 px-4 sm:px-6 lg:px-8 border-b border-[#1E293B] shadow-xl">
            
            {/* Subtle background ambient mesh (no text glare) */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#1E293B]/60 via-[#0B0F19] to-[#0B0F19] pointer-events-none"></div>

            <div className="max-w-7xl mx-auto relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
              
              {/* Left Column: Vision & Action */}
              <div className="lg:col-span-7 flex flex-col justify-between space-y-6 text-left">
                <div className="space-y-5">
                  
                  {/* Top Live Status Badge */}
                  <div className="inline-flex items-center space-x-2.5 px-4 py-1.5 rounded-full bg-[#1E293B] border border-[#334155] text-xs font-semibold shadow-sm">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#F59E0B] animate-ping"></span>
                    <span className="text-[#F59E0B] font-bold">Next-Gen Trade Show OS</span>
                    <span className="text-[#94A3B8] hidden sm:inline">•</span>
                    <span className="text-[#E2E8F0] hidden sm:inline font-medium">Karachi Expo Centre Live Nov 12-15</span>
                  </div>

                  {/* Main High-Contrast Headline */}
                  <h1 className="text-3xl sm:text-5xl lg:text-5xl font-extrabold tracking-tight font-heading leading-tight sm:leading-tight text-white">
                    Where Industry Leaders, Exhibitors & Visionaries <span className="text-[#F59E0B]">Unite.</span>
                  </h1>

                  {/* Ultra-Clear Subtitle (High contrast Slate-200 on Obsidian) */}
                  <p className="text-base sm:text-lg text-[#E2E8F0] font-normal leading-relaxed max-w-2xl">
                    Eliminate manual registration spreadsheets, disconnected emails, and static paper blueprints. EventSphere delivers interactive 2D floor plans, instantaneous booth reservations, synchronized conference agendas, and real-time B2B matchmaking across Pakistan's premier convention centers.
                  </p>

                  {/* Primary CTA Buttons */}
                  <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-3 pt-3">
                    <button
                      onClick={() => scrollToSection("expos-section")}
                      className="px-6 py-3.5 rounded-xl font-extrabold bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] shadow-lg shadow-[#F59E0B]/25 transition-all hover:scale-105 flex items-center justify-center space-x-2 text-sm"
                    >
                      <span>Explore Featured Expos</span>
                      <Icon name="arrowRight" className="w-4 h-4 text-[#0F172A]" />
                    </button>

                    <button
                      onClick={onExhibitorApply}
                      className="px-6 py-3.5 rounded-xl font-bold bg-[#1E293B] hover:bg-[#334155] text-white border border-[#475569] transition-all hover:scale-105 flex items-center justify-center space-x-2 text-sm shadow-sm"
                    >
                      <Icon name="building" className="w-4 h-4 text-[#F59E0B]" />
                      <span>Reserve Exhibitor Booth</span>
                    </button>

                    <button
                      onClick={() => scrollToSection("hall-specs-section")}
                      className="px-5 py-3.5 rounded-xl font-semibold bg-transparent hover:bg-[#1E293B] text-[#E2E8F0] hover:text-white border border-[#334155] transition-all text-sm flex items-center justify-center space-x-2"
                    >
                      <Icon name="grid" className="w-4 h-4 text-[#F59E0B]" />
                      <span>Hall 2D Specs</span>
                    </button>
                  </div>
                </div>

                {/* Metric Strip (Crisp White Numbers + Legible Slate-400 Labels) */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-[#1E293B]">
                  <div>
                    <div className="text-2xl sm:text-3xl font-extrabold text-white font-heading">150+</div>
                    <div className="text-xs text-[#94A3B8] font-medium mt-0.5">Expos Hosted</div>
                  </div>
                  <div>
                    <div className="text-2xl sm:text-3xl font-extrabold text-white font-heading">5,400+</div>
                    <div className="text-xs text-[#94A3B8] font-medium mt-0.5">Verified Exhibitors</div>
                  </div>
                  <div>
                    <div className="text-2xl sm:text-3xl font-extrabold text-white font-heading">120K+</div>
                    <div className="text-xs text-[#94A3B8] font-medium mt-0.5">Attendees Handled</div>
                  </div>
                  <div>
                    <div className="text-2xl sm:text-3xl font-extrabold text-[#F59E0B] font-heading">99.8%</div>
                    <div className="text-xs text-[#94A3B8] font-medium mt-0.5">System Uptime</div>
                  </div>
                </div>
              </div>

              {/* Right Column: Live Expo Command Snapshot Card (Equal Height & Pure Clarity) */}
              <div className="lg:col-span-5 flex flex-col">
                <div className="bg-[#111827] border border-[#1E293B] rounded-3xl p-6 sm:p-7 text-white shadow-2xl space-y-4 flex flex-col justify-between h-full relative overflow-hidden">

                  <div className="space-y-4">
                    {/* Header */}
                    <div className="flex items-center justify-between border-b border-[#1E293B] pb-3">
                      <div>
                        <div className="inline-flex items-center space-x-1.5 text-xs font-bold uppercase tracking-wider text-[#F59E0B]">
                          <span className="w-2 h-2 rounded-full bg-[#F59E0B] animate-pulse"></span>
                          <span>Active Expo • Karachi</span>
                        </div>
                        <h3 className="font-heading font-extrabold text-base text-white mt-1">
                          Pakistan Tech & AI Expo 2026
                        </h3>
                      </div>
                      <span className="px-2.5 py-1 rounded-md text-xs font-extrabold bg-[#F59E0B] text-[#0F172A]">
                        HALL 1 & 2 LIVE
                      </span>
                    </div>

                    {/* Floor Plan Allocation */}
                    <div className="space-y-2 bg-[#0B0F19] p-4 rounded-2xl border border-[#1E293B]">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-white font-bold flex items-center space-x-1.5">
                          <Icon name="grid" className="w-4 h-4 text-[#F59E0B]" />
                          <span>Floor Plan Allocation</span>
                        </span>
                        <span className="text-[#F59E0B] font-extrabold">38 / 48 Reserved (79%)</span>
                      </div>

                      <div className="w-full h-2.5 bg-[#1E293B] rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-[#F59E0B] to-[#FBBF24] rounded-full" style={{ width: '79%' }}></div>
                      </div>

                      <div className="flex items-center justify-between text-xs text-[#94A3B8] font-medium pt-0.5">
                        <span>• 18 Standard</span>
                        <span>• 12 Corner VIP</span>
                        <span>• 8 Island Pavilions</span>
                      </div>
                    </div>

                    {/* Happening Now */}
                    <div className="bg-[#0B0F19] p-4 rounded-2xl border border-[#1E293B] space-y-2.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[#F59E0B] font-extrabold flex items-center space-x-1 tracking-wider uppercase">
                          <Icon name="clock" className="w-3.5 h-3.5 text-[#F59E0B]" />
                          <span>HAPPENING NOW ON STAGE</span>
                        </span>
                        <span className="text-[#94A3B8] font-medium text-xs">Grand Hall Plenary</span>
                      </div>

                      <div className="flex items-center space-x-3 pt-1">
                        <div className="w-10 h-10 rounded-xl bg-[#F59E0B] text-[#0F172A] flex items-center justify-center font-extrabold text-xs shadow-sm">
                          TM
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-bold text-white line-clamp-1">Industrial Embodied AI & Cobots in Manufacturing</div>
                          <div className="text-xs text-[#94A3B8] font-medium">Dr. Tariq Mehmood • PakRobotics Technologies</div>
                        </div>
                      </div>
                    </div>

                    {/* RFID Active */}
                    <div className="flex items-center justify-between px-4 py-3 bg-[#0B0F19] rounded-2xl border border-[#1E293B] text-xs">
                      <span className="text-[#E2E8F0] font-semibold flex items-center space-x-2">
                        <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse"></span>
                        <span>RFID Badges Active On-Site:</span>
                      </span>
                      <span className="font-extrabold text-[#F59E0B] font-heading text-sm">8,420 Checked-In</span>
                    </div>
                  </div>

                  {/* Buttons */}
                  <div className="grid grid-cols-2 gap-3 pt-2">
                    <button
                      onClick={onExploreFloor}
                      className="w-full py-2.5 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] font-extrabold text-xs transition-all flex items-center justify-center space-x-1.5 shadow-md"
                    >
                      <Icon name="grid" className="w-3.5 h-3.5 text-[#0F172A]" />
                      <span>Inspect Hall Floor Map</span>
                    </button>
                    <button
                      onClick={onExploreSchedule}
                      className="w-full py-2.5 rounded-xl bg-[#1E293B] hover:bg-[#334155] text-white font-bold text-xs border border-[#334155] transition-all flex items-center justify-center space-x-1.5 shadow-sm"
                    >
                      <Icon name="calendar" className="w-3.5 h-3.5 text-[#F59E0B]" />
                      <span>Live Agenda</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* ======================================================== */}
          {/* 2. EXPOS SEARCH & CATALOG SECTION */}
          {/* ======================================================== */}
          <section id="expos-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#ebdcc9] pb-5">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#ea580c]">National & Global Showcase</span>
                <h2 className="text-2xl sm:text-3xl font-bold font-heading text-[#23150c] mt-1">Upcoming World Expos & Summits</h2>
                <p className="text-sm text-[#7d5e4a] mt-1">Discover upcoming trade shows, review hall floor plans, and register your delegation.</p>
              </div>

              {/* Search input */}
              <div className="relative w-full md:w-80">
                <input
                  type="text"
                  placeholder="Search by city, title, or topic..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-[#ddc29f] focus:outline-none focus:ring-2 focus:ring-[#ea580c]/25 focus:border-[#ea580c] text-sm bg-white"
                />
                <Icon name="search" className="w-4 h-4 text-[#9c7d67] absolute left-3.5 top-3" />
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-2">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    categoryFilter === cat
                      ? "bg-[#23150c] text-white shadow-sm"
                      : "bg-white text-[#634735] border border-[#ebdcc9] hover:bg-[#f7ede0]"
                  }`}
                >
                  {cat === "all" ? "All Categories" : cat}
                </button>
              ))}
            </div>

            {/* Expos Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredExpos.map(expo => (
                <div 
                  key={expo.id} 
                  className="bg-white rounded-2xl border border-[#ebdcc9] overflow-hidden interactive-card flex flex-col justify-between shadow-xs"
                >
                  <div>
                    {/* Header Banner */}
                    <div className={`h-24 bg-gradient-to-r ${expo.bannerColor} p-5 flex items-center justify-between text-white relative`}>
                      <span className="px-2.5 py-1 rounded-md text-[11px] font-bold bg-white/20 backdrop-blur-md uppercase tracking-wide">
                        {expo.category}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#fbbf24] text-[#23150c]">
                        {expo.status}
                      </span>
                    </div>

                    <div className="p-6 space-y-4">
                      <div>
                        <h3 className="text-xl font-bold font-heading text-[#23150c] group-hover:text-[#ea580c] transition-colors">
                          {expo.title}
                        </h3>
                        <p className="text-xs text-[#7d5e4a] mt-1.5 line-clamp-2 leading-relaxed">
                          {expo.tagline}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs text-[#634735] bg-[#fbf7f0] p-3.5 rounded-xl border border-[#f2e5d5]">
                        <div className="flex items-center space-x-2">
                          <Icon name="calendar" className="w-4 h-4 text-[#ea580c]" />
                          <span>{expo.startDate}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Icon name="mapPin" className="w-4 h-4 text-rose-500" />
                          <span className="truncate">{expo.location}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Icon name="grid" className="w-4 h-4 text-teal-600" />
                          <span>{expo.occupiedBooths} / {expo.totalBooths} Booths Reserved</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Icon name="users" className="w-4 h-4 text-amber-600" />
                          <span>{expo.attendeeCount.toLocaleString()} Attendees</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="px-6 pb-6 pt-2 flex items-center justify-between border-t border-[#f2e5d5] mt-2">
                    <span className="text-xs text-[#7d5e4a] font-medium">{expo.venueDetails}</span>
                    <button
                      onClick={() => onSelectExpo(expo.id)}
                      className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#ea580c] to-[#f59e0b] hover:from-[#c2410c] hover:to-[#d97706] text-white font-semibold text-xs transition-colors flex items-center space-x-1.5 shadow-sm"
                    >
                      <span>Enter Expo Portal</span>
                      <Icon name="arrowRight" className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* ======================================================== */}
          {/* 3. PHASED STEP-BY-STEP LIFECYCLE (LADDERED APPROACH) */}
          {/* ======================================================== */}
          <section className="bg-white border-y border-[#ebdcc9] py-16 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto space-y-12">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#ea580c]">End-to-End Execution</span>
                <h2 className="text-3xl font-bold font-heading text-[#23150c]">How EventSphere Powers Your Trade Show</h2>
                <p className="text-sm text-[#7d5e4a]">A structured, laddered workflow that connects hall architecture with commercial vendor success.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {/* Step 1 */}
                <div className="p-6 rounded-2xl bg-[#fbf7f0] border border-[#ebdcc9] space-y-3 relative interactive-card">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#ea580c] to-[#f59e0b] text-white font-bold text-sm flex items-center justify-center shadow-xs">
                    01
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#23150c]">Blueprint Hall Grid</h3>
                  <p className="text-xs text-[#7d5e4a] leading-relaxed">
                    Organizers configure 2D interactive floor plans with Standard (10x10), Corner, and Island Pavilion zones with dedicated 220V power specs.
                  </p>
                </div>

                {/* Step 2 */}
                <div className="p-6 rounded-2xl bg-[#fbf7f0] border border-[#ebdcc9] space-y-3 relative interactive-card">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#ea580c] to-[#f59e0b] text-white font-bold text-sm flex items-center justify-center shadow-xs">
                    02
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#23150c]">Exhibitor Reservation</h3>
                  <p className="text-xs text-[#7d5e4a] leading-relaxed">
                    Vendors inspect live floor availability, review utility amenities, upload legal compliance documents, and secure prime space in 1 click.
                  </p>
                </div>

                {/* Step 3 */}
                <div className="p-6 rounded-2xl bg-[#fbf7f0] border border-[#ebdcc9] space-y-3 relative interactive-card">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#ea580c] to-[#f59e0b] text-white font-bold text-sm flex items-center justify-center shadow-xs">
                    03
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#23150c]">Schedule Multi-Tracks</h3>
                  <p className="text-xs text-[#7d5e4a] leading-relaxed">
                    Program keynotes, technical workshops, and speaker rosters that synchronize automatically with attendee mobile agendas and calendar reminders.
                  </p>
                </div>

                {/* Step 4 */}
                <div className="p-6 rounded-2xl bg-[#fbf7f0] border border-[#ebdcc9] space-y-3 relative interactive-card">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#ea580c] to-[#f59e0b] text-white font-bold text-sm flex items-center justify-center shadow-xs">
                    04
                  </div>
                  <h3 className="font-heading font-bold text-base text-[#23150c]">Matchmaking & Beacons</h3>
                  <p className="text-xs text-[#7d5e4a] leading-relaxed">
                    Attendees locate vendor booths with visual pulsing beacons, view product catalogs on-site, and initiate direct B2B inquiries effortlessly.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* ======================================================== */}
          {/* 4. FEATURED KEYNOTE SPEAKERS & LUMINARIES */}
          {/* ======================================================== */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#ebdcc9] pb-5">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#ea580c]">Thought Leadership</span>
                <h2 className="text-2xl sm:text-3xl font-bold font-heading text-[#23150c] mt-1">Featured Keynote Speakers & Visionaries</h2>
                <p className="text-sm text-[#7d5e4a] mt-1">Leading scientists, corporate founders, and cyber intelligence experts sharing breakthrough insights.</p>
              </div>

              <button
                onClick={onExploreSchedule}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#23150c] hover:bg-[#382214] text-[#fef3c7] transition-colors flex items-center space-x-1.5 self-start md:self-auto"
              >
                <span>View Full Conference Agenda</span>
                <Icon name="arrowRight" className="w-3.5 h-3.5 text-[#fbbf24]" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {keynoteSpeakers.map((spk, idx) => (
                <div key={idx} className="bg-white rounded-2xl border border-[#ebdcc9] p-5 shadow-xs flex flex-col justify-between interactive-card space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#ea580c] via-[#f59e0b] to-[#d4af37] text-white flex items-center justify-center font-bold text-base shadow-xs">
                        {spk.avatar}
                      </div>
                      <div>
                        <h4 className="font-heading font-bold text-sm text-[#23150c]">{spk.name}</h4>
                        <p className="text-[11px] text-[#7d5e4a] font-medium">{spk.role}</p>
                        <p className="text-[10px] text-[#ea580c] font-semibold">{spk.company}</p>
                      </div>
                    </div>

                    <div className="bg-[#fbf7f0] p-3 rounded-xl border border-[#f2e5d5] space-y-1">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-[#9c7d67]">Keynote Topic</span>
                      <p className="text-xs text-[#2e1d13] font-medium line-clamp-2">{spk.topic}</p>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-[#f2e5d5] flex items-center justify-between text-[11px] text-[#7d5e4a]">
                    <span className="font-medium">{spk.sessionTime}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* ======================================================== */}
          {/* 5. NATIONAL EXPO VENUES SPOTLIGHT */}
          {/* ======================================================== */}
          <section className="bg-[#f7ede0]/65 border-y border-[#ebdcc9] py-16 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto space-y-10">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#ea580c]">Infrastructure Excellence</span>
                <h2 className="text-3xl font-bold font-heading text-[#23150c]">Pakistan's Premier Convention Infrastructure</h2>
                <p className="text-sm text-[#7d5e4a]">EventSphere seamlessly integrates with major exhibition halls across Karachi, Lahore, and Islamabad.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {venues.map((v, i) => (
                  <div key={i} className="bg-white p-5 rounded-2xl border border-[#ebdcc9] shadow-xs space-y-3 flex flex-col justify-between interactive-card">
                    <div className="space-y-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#fef3c7] text-[#92400e] border border-[#fde68a]">
                        {v.badge}
                      </span>
                      <h4 className="font-heading font-bold text-base text-[#23150c] mt-1">{v.name}</h4>
                      <div className="flex items-center space-x-1.5 text-xs text-[#ea580c] font-medium">
                        <Icon name="mapPin" className="w-3.5 h-3.5" />
                        <span>{v.city}</span>
                      </div>
                      <p className="text-xs text-[#7d5e4a] leading-relaxed pt-1">{v.highlight}</p>
                    </div>

                    <div className="pt-3 border-t border-[#f2e5d5] text-[11px] font-semibold text-[#2e1d13]">
                      {v.specs}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* ======================================================== */}
          {/* 6. THREE INTERFACES / PLATFORM PILLARS */}
          {/* ======================================================== */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="text-center max-w-2xl mx-auto space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#ea580c]">Unified Architecture</span>
              <h2 className="text-3xl font-bold font-heading text-[#23150c]">Three Interfaces. One Synchronized System.</h2>
              <p className="text-sm text-[#7d5e4a]">Every interaction on the floor plan or schedule immediately propagates across all devices in real-time.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Pillar 1 */}
              <div className="bg-white p-6 rounded-2xl border border-[#ebdcc9] shadow-xs space-y-3">
                <div className="w-12 h-12 rounded-xl bg-[#fff7ed] text-[#ea580c] flex items-center justify-center">
                  <Icon name="shield" className="w-6 h-6" />
                </div>
                <h3 className="font-heading font-bold text-base text-[#23150c]">For Organizers & Admins</h3>
                <p className="text-xs text-[#7d5e4a] leading-relaxed">
                  Interactive booth space allocator, exhibitor document verification pipeline, multi-hall agenda composer, and live foot-traffic telemetry.
                </p>
                <ul className="text-xs text-[#634735] space-y-1.5 pt-2">
                  <li className="flex items-center space-x-2"><Icon name="check" className="w-3.5 h-3.5 text-emerald-600" /><span>Instant approve/reject for applications</span></li>
                  <li className="flex items-center space-x-2"><Icon name="check" className="w-3.5 h-3.5 text-emerald-600" /><span>Visual 2D hall grid configuration</span></li>
                </ul>
              </div>

              {/* Pillar 2 */}
              <div className="bg-white p-6 rounded-2xl border border-[#ebdcc9] shadow-xs space-y-3">
                <div className="w-12 h-12 rounded-xl bg-[#fefce8] text-[#ca8a04] flex items-center justify-center">
                  <Icon name="building" className="w-6 h-6" />
                </div>
                <h3 className="font-heading font-bold text-base text-[#23150c]">For Exhibitors</h3>
                <p className="text-xs text-[#7d5e4a] leading-relaxed">
                  Reserve premier island and corner booths in 1-click, build rich digital product showcases, and engage directly with attendees and neighbors.
                </p>
                <ul className="text-xs text-[#634735] space-y-1.5 pt-2">
                  <li className="flex items-center space-x-2"><Icon name="check" className="w-3.5 h-3.5 text-emerald-600" /><span>Floor plan booth tier selection & specs</span></li>
                  <li className="flex items-center space-x-2"><Icon name="check" className="w-3.5 h-3.5 text-emerald-600" /><span>Direct B2B communication channels</span></li>
                </ul>
              </div>

              {/* Pillar 3 */}
              <div className="bg-white p-6 rounded-2xl border border-[#ebdcc9] shadow-xs space-y-3">
                <div className="w-12 h-12 rounded-xl bg-[#fef3c7] text-[#b45309] flex items-center justify-center">
                  <Icon name="users" className="w-6 h-6" />
                </div>
                <h3 className="font-heading font-bold text-base text-[#23150c]">For Attendees</h3>
                <p className="text-xs text-[#7d5e4a] leading-relaxed">
                  Search exhibitors with granular filters, pinpoint exact booth locations with visual beacons, and curate a personalized agenda with reminders.
                </p>
                <ul className="text-xs text-[#634735] space-y-1.5 pt-2">
                  <li className="flex items-center space-x-2"><Icon name="check" className="w-3.5 h-3.5 text-emerald-600" /><span>"Locate on Map" beacon navigation</span></li>
                  <li className="flex items-center space-x-2"><Icon name="check" className="w-3.5 h-3.5 text-emerald-600" /><span>1-click session bookmarking & alerts</span></li>
                </ul>
              </div>
            </div>
          </section>

          {/* ======================================================== */}
          {/* 7. AUTHENTIC TESTIMONIALS */}
          {/* ======================================================== */}
          <section className="bg-white border-y border-[#ebdcc9] py-16 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto space-y-10">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-[#ea580c]">Verified Voices</span>
                <h2 className="text-3xl font-bold font-heading text-[#23150c]">Trusted by Trade Authorities & Delegations</h2>
                <p className="text-sm text-[#7d5e4a]">Real feedback from expo directors, vendor engineers, and international visitors.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {testimonials.map((t, idx) => (
                  <div key={idx} className="p-6 rounded-2xl bg-[#fbf7f0] border border-[#ebdcc9] flex flex-col justify-between space-y-6 interactive-card shadow-xs">
                    <p className="text-xs text-[#4c3324] leading-relaxed italic">
                      "{t.quote}"
                    </p>

                    <div className="flex items-center space-x-3 pt-4 border-t border-[#ebdcc9]">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#ea580c] to-[#d4af37] text-white flex items-center justify-center font-bold text-xs shadow-xs">
                        {t.avatar}
                      </div>
                      <div>
                        <div className="font-heading font-bold text-xs text-[#23150c]">{t.author}</div>
                        <div className="text-[11px] text-[#7d5e4a]">{t.title}</div>
                        <div className="text-[10px] font-semibold text-[#ea580c]">{t.org}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* ======================================================== */}
          {/* 8. INTERACTIVE FAQ ACCORDION */}
          {/* ======================================================== */}
          <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="text-center space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#ea580c]">Clear Answers</span>
              <h2 className="text-2xl sm:text-3xl font-bold font-heading text-[#23150c]">Frequently Asked Questions</h2>
              <p className="text-sm text-[#7d5e4a]">Everything you need to know about navigating, exhibiting, and organizing with EventSphere.</p>
            </div>

            <div className="space-y-3">
              {faqs.map((faq, index) => {
                const isOpen = openFaq === index;
                return (
                  <div 
                    key={index} 
                    className="bg-white rounded-2xl border border-[#ebdcc9] overflow-hidden transition-all shadow-xs"
                  >
                    <button
                      onClick={() => setOpenFaq(isOpen ? -1 : index)}
                      className="w-full p-5 text-left flex items-center justify-between font-heading font-bold text-sm text-[#23150c] hover:text-[#ea580c] transition-colors"
                    >
                      <span>{faq.q}</span>
                      <span className={`w-6 h-6 rounded-lg bg-[#f7ede0] flex items-center justify-center text-xs font-bold text-[#ea580c] transition-transform ${isOpen ? "rotate-45" : ""}`}>
                        +
                      </span>
                    </button>
                    {isOpen && (
                      <div className="px-5 pb-5 text-xs text-[#634735] leading-relaxed border-t border-[#f2e5d5] pt-3">
                        {faq.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </section>

          {/* ======================================================== */}
          {/* 9. NEWSLETTER / DELEGATION SUBSCRIPTION STRIP */}
          {/* ======================================================== */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-[#181008] via-[#28180e] to-[#3a2214] rounded-3xl p-8 sm:p-12 text-white border border-[#442817] shadow-xl relative overflow-hidden">
              <div className="absolute right-0 top-0 w-96 h-96 bg-[#ea580c]/15 blur-3xl pointer-events-none"></div>

              <div className="max-w-2xl space-y-4 relative z-10">
                <span className="px-3 py-1 rounded-full text-[10px] font-bold bg-[#ea580c]/20 text-[#fde68a] border border-[#f59e0b]/30 uppercase tracking-wider">
                  Stay Informed
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold font-heading text-white">
                  Join 15,000+ Trade Delegates & Industry Leaders
                </h3>
                <p className="text-xs sm:text-sm text-[#ecd8c6] leading-relaxed">
                  Subscribe to receive weekly announcements on upcoming national expos, new booth space releases, and keynote speaker schedules directly in your inbox.
                </p>

                {subscribed ? (
                  <div className="p-4 rounded-xl bg-emerald-900/60 border border-emerald-500/40 text-emerald-200 text-xs font-semibold flex items-center space-x-2">
                    <Icon name="check" className="w-4 h-4 text-emerald-400" />
                    <span>Shukriya! You have successfully subscribed to EventSphere Trade Alerts.</span>
                  </div>
                ) : (
                  <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-3 pt-2">
                    <input
                      type="email"
                      required
                      placeholder="Enter your corporate email address..."
                      value={newsletterEmail}
                      onChange={(e) => setNewsletterEmail(e.target.value)}
                      className="flex-1 px-4 py-3 rounded-xl bg-[#0F172A] border border-[#334155] text-white text-xs placeholder-[#9c7d67] focus:outline-none focus:ring-2 focus:ring-[#ea580c]/40"
                    />
                    <button
                      type="submit"
                      className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#ea580c] to-[#f59e0b] hover:from-[#c2410c] hover:to-[#d97706] text-white font-semibold text-xs transition-all shadow-md shadow-orange-600/30 whitespace-nowrap"
                    >
                      Subscribe to Expo Alerts
                    </button>
                  </form>
                )}
              </div>
            </div>
          </section>

        </div>
      );
    }

    // ========================================================
    function AboutUsView({ onContact, onExploreExpos }) {
      const pillars = [
        {
          icon: "layers",
          title: "Real-Time Spatial Synchronization",
          desc: "50ms atomic state replication ensures that when a booth is reserved, the 2D hall layout updates instantaneously across all connected screens, eliminating double-booking."
        },
        {
          icon: "shield",
          title: "SECP & Regulatory Verification",
          desc: "Comprehensive document verification workflows ensure only genuine, accredited enterprise manufacturers and institutions exhibit on our floors."
        },
        {
          icon: "users",
          title: "Unified 3-Way Ecosystem",
          desc: "Synchronizes Organizers, Exhibitors, and Attendees on a unified live canvas with instant B2B messaging, digital catalogs, and NFC lead telemetry."
        },
        {
          icon: "zap",
          title: "High-Availability Cloud Architecture",
          desc: "Guaranteed 99.98% uptime SLA with offline-resilient local cache, encrypted with TLS 1.3 and AES-256 for mission-critical trade delegations."
        }
      ];

      const leadership = [
        {
          name: "Engr. Syed Farhan Akhtar",
          role: "Operations Director & Platform Architect",
          company: "EventSphere Management Technologies",
          avatar: "FA",
          bio: "15+ years orchestrating international defense, automotive, and industrial trade expos across Karachi and Lahore Expo Centres."
        },
        {
          name: "Dr. Tariq Mehmood",
          role: "Principal Technology Advisor",
          company: "PakRobotics Technologies Labs",
          avatar: "TM",
          bio: "Leading autonomous assembly robotics and computer vision systems deployed across industrial convention facilities."
        },
        {
          name: "Fatima Zahra",
          role: "Head of Zero-Trust Security",
          company: "CyberDifa 360",
          avatar: "FZ",
          bio: "Specializing in secure delegate badge telemetry, NFC cryptographic handshakes, and enterprise data privacy standards."
        },
        {
          name: "Engr. Ayesha Siddiqui",
          role: "Director of Clean Energy Summits",
          company: "Indus Green Power",
          avatar: "AS",
          bio: "Spearheading sustainable convention microgrids, lithium battery installations, and zero-carbon exhibition initiatives."
        }
      ];

      const venues = [
        {
          name: "Expo Centre Karachi",
          city: "Karachi, Sindh",
          specs: "6 Exhibition Halls • 40,000 sqm • 15,000 Capacity",
          badge: "Main Coastal Hub",
          clearance: "8.5m Clear Ceiling",
          floorLoad: "3,500 kg/sqm"
        },
        {
          name: "Lahore International Expo Centre",
          city: "Lahore, Punjab",
          specs: "Dual Plenary Halls • Johar Town • 18,000 Capacity",
          badge: "Cultural & Industrial Gateway",
          clearance: "9.0m Clear Ceiling",
          floorLoad: "4,000 kg/sqm"
        },
        {
          name: "Pak-China Friendship Centre",
          city: "Islamabad, Capital",
          specs: "Bilateral Main Hall • Diplomatic Enclave • 12,000 Capacity",
          badge: "National Summit Pavilion",
          clearance: "8.0m Clear Ceiling",
          floorLoad: "2,500 kg/sqm"
        },
        {
          name: "Jinnah Convention Centre",
          city: "Islamabad, Capital",
          specs: "Iconic Plenary Dome • Executive Suites • 10,000 Capacity",
          badge: "Presidential Concourse",
          clearance: "11.0m Dome Ceiling",
          floorLoad: "2,000 kg/sqm"
        }
      ];

      return (
        <div className="space-y-12 sm:space-y-16 pb-12">
          {/* Header Banner */}
          <section className="bg-[#0B0F19] text-white pt-12 sm:pt-16 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#1E293B] shadow-xl">
            <div className="max-w-7xl mx-auto space-y-5">
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#1E293B] border border-[#334155] text-xs font-semibold">
                <Icon name="sphere" className="w-4 h-4 text-[#F59E0B]" />
                <span className="text-[#F59E0B] font-bold">About EventSphere Technologies Inc.</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight leading-tight">
                The Digital Operating System for <span className="text-[#F59E0B]">World-Class Expos</span>
              </h1>
              <p className="text-base sm:text-lg text-[#E2E8F0] font-normal leading-relaxed max-w-3xl">
                Born out of the need to eliminate fragmented paper blueprints, double-booking conflicts, and manual spreadsheets, EventSphere unites Organizers, Exhibitors, and Attendees into a synchronized real-time trade show ecosystem across Pakistan's premier convention venues.
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-3">
                <button
                  onClick={onExploreExpos}
                  className="px-6 py-3.5 rounded-xl font-extrabold bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] shadow-md transition-all flex items-center space-x-2 text-sm"
                >
                  <span>Explore Active Expos</span>
                  <Icon name="arrowRight" className="w-4 h-4 text-[#0F172A]" />
                </button>
                <button
                  onClick={onContact}
                  className="px-6 py-3.5 rounded-xl font-bold bg-[#1E293B] hover:bg-[#334155] text-white border border-[#475569] transition-all flex items-center space-x-2 text-sm shadow-sm"
                >
                  <Icon name="helpCircle" className="w-4 h-4 text-[#F59E0B]" />
                  <span>Contact Operations HQ</span>
                </button>
              </div>
            </div>
          </section>

          {/* Core Architectural Pillars */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
            <div className="text-left space-y-1">
              <span className="text-xs font-extrabold uppercase tracking-wider text-[#D97706]">Engineered for Reliability</span>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-[#0F172A]">Core Platform Architecture</h2>
              <p className="text-sm text-[#334155]">Designed to withstand the high-concurrency demands of 20,000+ simultaneous on-site delegates.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {pillars.map((p, idx) => (
                <div key={idx} className="bg-white p-6 rounded-2xl border border-[#E2E8F0] shadow-sm hover:border-[#F59E0B] transition-all space-y-3 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="w-12 h-12 rounded-xl bg-[#FEF3C7] text-[#D97706] flex items-center justify-center font-bold">
                      <Icon name={p.icon} className="w-6 h-6" />
                    </div>
                    <h3 className="text-base font-extrabold font-heading text-[#0F172A]">{p.title}</h3>
                    <p className="text-xs text-[#334155] leading-relaxed font-normal">{p.desc}</p>
                  </div>
                  <div className="pt-3 border-t border-[#F1F5F9] text-[11px] font-bold text-[#D97706] flex items-center space-x-1">
                    <Icon name="check" className="w-3.5 h-3.5 text-[#D97706]" />
                    <span>Active Standard</span>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Venues Grid */}
          <section className="bg-[#F1F5F9]/70 border-y border-[#E2E8F0] py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-7xl mx-auto space-y-8">
              <div className="text-left space-y-1">
                <span className="text-xs font-extrabold uppercase tracking-wider text-[#D97706]">Nationwide Coverage</span>
                <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-[#0F172A]">Supported Convention Centers</h2>
                <p className="text-sm text-[#334155]">Full CAD blueprint digitizations and real-time 2D spatial allocation across Pakistan's major centers.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {venues.map((v, i) => (
                  <div key={i} className="bg-white p-6 rounded-2xl border border-[#E2E8F0] shadow-xs space-y-4 flex flex-col justify-between">
                    <div className="space-y-3">
                      <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold bg-[#FEF3C7] text-[#92400E] border border-[#FDE68A]">
                        {v.badge}
                      </span>
                      <h3 className="text-base font-extrabold font-heading text-[#0F172A]">{v.name}</h3>
                      <div className="text-xs text-[#64748B] flex items-center space-x-1.5 font-medium">
                        <Icon name="mapPin" className="w-4 h-4 text-[#D97706]" />
                        <span>{v.city}</span>
                      </div>
                      <p className="text-xs text-[#334155] leading-relaxed">{v.specs}</p>
                    </div>

                    <div className="pt-3 border-t border-[#F1F5F9] space-y-1 text-xs text-[#475569]">
                      <div className="flex justify-between">
                        <span>Ceiling Clearance:</span>
                        <strong className="text-[#0F172A]">{v.clearance}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Floor Loading:</span>
                        <strong className="text-[#0F172A]">{v.floorLoad}</strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Leadership Team */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
            <div className="text-left space-y-1">
              <span className="text-xs font-extrabold uppercase tracking-wider text-[#D97706]">Executive Leadership</span>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-heading text-[#0F172A]">Platform Steering Committee</h2>
              <p className="text-sm text-[#334155]">Senior architects, operations leads, and security researchers directing EventSphere development.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {leadership.map((l, idx) => (
                <div key={idx} className="bg-white p-6 rounded-2xl border border-[#E2E8F0] shadow-xs space-y-4 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#0F172A] to-[#F59E0B] text-white flex items-center justify-center font-extrabold text-lg shadow-sm">
                      {l.avatar}
                    </div>
                    <div>
                      <h3 className="text-base font-extrabold font-heading text-[#0F172A]">{l.name}</h3>
                      <div className="text-xs font-bold text-[#D97706]">{l.role}</div>
                      <div className="text-[11px] text-[#64748B]">{l.company}</div>
                    </div>
                    <p className="text-xs text-[#334155] leading-relaxed">{l.bio}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Bottom CTA Banner */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-gradient-to-r from-[#0F172A] via-[#1E293B] to-[#0F172A] text-white p-8 sm:p-12 rounded-3xl border border-[#334155] shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
              <div className="space-y-2 max-w-xl">
                <h3 className="text-2xl sm:text-3xl font-extrabold font-heading text-white">Ready to Modernize Your Next Trade Show?</h3>
                <p className="text-sm text-[#E2E8F0] leading-relaxed">
                  Join hundreds of verified exhibitors and event directors experiencing frictionless spatial allocation and B2B engagement.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={onExploreExpos}
                  className="px-6 py-3.5 rounded-xl font-extrabold bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] shadow-md transition-all text-xs sm:text-sm"
                >
                  Browse Expos Catalog
                </button>
                <button
                  onClick={onContact}
                  className="px-6 py-3.5 rounded-xl font-bold bg-[#1E293B] hover:bg-[#334155] text-white border border-[#475569] transition-all text-xs sm:text-sm"
                >
                  Contact Operations
                </button>
              </div>
            </div>
          </section>
        </div>
      );
    }

    // ========================================================
    // SHARED REUSABLE SUB-NAV TABS FOR 6 EXPO PAGES
    // ========================================================
    function ExpoSubNavTabs({ activeTab, onNavigate }) {
      const tabs = [
        { id: "expos", label: "🎪 All Expos Catalog", desc: "Discover & Filter" },
        { id: "expo-details", label: "📄 1. Expo Details", desc: "Venue & CAD Specs" },
        { id: "exhibitor-directory", label: "🏢 2. Exhibitor Directory", desc: "40+ Verified Vendors" },
        { id: "event-schedule", label: "📅 3. Event Schedule", desc: "Keynotes & Tracks" },
        { id: "floorplan", label: "📐 4. Interactive Floorplan", desc: "2D Hall & Beacon" },
        { id: "expo-feedback", label: "💬 5. Contact & Feedback", desc: "Reviews & Support" }
      ];

      return (
        <div className="bg-white p-2.5 rounded-2xl border border-[#CBD5E1] shadow-xs">
          <div className="flex items-center space-x-2 overflow-x-auto scrollbar-none pb-0.5 text-xs font-bold">
            <span className="text-[11px] font-extrabold uppercase text-[#64748B] px-2.5 hidden sm:inline whitespace-nowrap">
              Expo Hub:
            </span>
            {tabs.map(t => (
              <button
                key={t.id}
                onClick={() => onNavigate(t.id)}
                className={`px-3.5 py-2.5 rounded-xl whitespace-nowrap transition-all flex items-center space-x-1.5 flex-shrink-0 ${
                  activeTab === t.id
                    ? "bg-[#F59E0B] text-[#0F172A] shadow-xs font-extrabold"
                    : "text-[#334155] hover:bg-[#F1F5F9] hover:text-[#0F172A]"
                }`}
              >
                <span>{t.label}</span>
              </button>
            ))}
          </div>
        </div>
      );
    }

    // ========================================================
    // SHARED REUSABLE EXPO SWITCHER BAR
    // ========================================================
    function ExpoEventSwitcherBar({ activeExpo, expos = [], onSwitchExpo }) {
      const currentId = activeExpo?.id || (expos[0] && expos[0].id);
      return (
        <div className="bg-[#1E293B] p-2.5 rounded-2xl border border-[#334155] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
          <div className="flex items-center space-x-2 text-xs">
            <span className="w-2 h-2 rounded-full bg-[#F59E0B] animate-pulse"></span>
            <span className="text-[#FEF3C7] font-extrabold text-[11px] uppercase tracking-wider">Active Expo:</span>
            <span className="text-white font-bold truncate max-w-[200px] sm:max-w-xs">{activeExpo?.title}</span>
          </div>
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none w-full sm:w-auto">
            <span className="text-[10px] text-[#94A3B8] font-bold uppercase hidden lg:inline mr-1">Switch:</span>
            {expos.map(exp => (
              <button
                key={exp.id}
                onClick={() => onSwitchExpo(exp.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap flex-shrink-0 ${
                  currentId === exp.id
                    ? "bg-[#F59E0B] text-[#0F172A] font-extrabold shadow-sm"
                    : "bg-[#0F172A] text-[#E2E8F0] hover:text-white hover:bg-[#334155] border border-[#334155]"
                }`}
              >
                {exp.category}
              </button>
            ))}
          </div>
        </div>
      );
    }

    // ========================================================
    // VIEW SUB-COMPONENT: UPCOMING EXPOS (FULL CATALOG & SEARCH)
    // ========================================================
    function UpcomingExposView({ 
      expos = [], 
      activeExpo, 
      onSelectExpo, 
      onViewExpoDetails, 
      onNavigate, 
      onExhibitorApply 
    }) {
      const [searchTerm, setSearchTerm] = useState("");
      const [categoryFilter, setCategoryFilter] = useState("all");
      const [cityFilter, setCityFilter] = useState("all");

      const categories = ["all", "Technology & AI", "Renewable Energy", "Automotive & Mobility", "Healthcare & Life Sciences"];
      const cities = ["all", "Karachi", "Lahore", "Islamabad"];

      const filteredExpos = expos.filter(e => {
        const matchesCat = categoryFilter === "all" || e.category === categoryFilter;
        const matchesCity = cityFilter === "all" || (e.location && e.location.toLowerCase().includes(cityFilter.toLowerCase()));
        const matchesSearch = (e.title && e.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
                              (e.location && e.location.toLowerCase().includes(searchTerm.toLowerCase())) ||
                              (e.tagline && e.tagline.toLowerCase().includes(searchTerm.toLowerCase()));
        return matchesCat && matchesCity && matchesSearch;
      });

      return (
        <div className="space-y-8 pb-16">
          {/* Header Banner */}
          <section className="bg-[#0B0F19] text-white pt-12 sm:pt-16 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#1E293B] shadow-xl">
            <div className="max-w-7xl mx-auto space-y-4">
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#1E293B] border border-[#334155] text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-[#F59E0B] animate-pulse"></span>
                <span className="text-[#F59E0B] font-bold">National & Global Exhibitions</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight">
                All Expos, Trade Shows & <span className="text-[#F59E0B]">Summits</span>
              </h1>
              <p className="text-base sm:text-lg text-[#E2E8F0] font-normal leading-relaxed max-w-3xl">
                Browse certified national exhibitions, inspect real-time 2D hall blueprints, review power and utility specifications, and register your delegation or exhibitor booth.
              </p>
            </div>
          </section>

          {/* Sub-Nav Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoSubNavTabs activeTab="expos" onNavigate={onNavigate || (() => {})} />
          </div>

          {/* Metrics Spotlight */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E2E8F0] shadow-xs">
                <span className="text-[11px] font-bold text-[#64748B] block uppercase tracking-wider">Scheduled Pavilions</span>
                <strong className="text-xl sm:text-2xl font-extrabold text-[#0F172A] block mt-1">{expos.length} Premier Summits</strong>
                <span className="text-xs text-[#10B981] font-semibold">● SECP & FBR Verified</span>
              </div>
              <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E2E8F0] shadow-xs">
                <span className="text-[11px] font-bold text-[#64748B] block uppercase tracking-wider">Booth Capacity</span>
                <strong className="text-xl sm:text-2xl font-extrabold text-[#0F172A] block mt-1">176 Booths</strong>
                <span className="text-xs text-[#D97706] font-semibold">132 Reserved (75% Occupied)</span>
              </div>
              <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E2E8F0] shadow-xs">
                <span className="text-[11px] font-bold text-[#64748B] block uppercase tracking-wider">Expected Buyers</span>
                <strong className="text-xl sm:text-2xl font-extrabold text-[#0F172A] block mt-1">28,500+</strong>
                <span className="text-xs text-[#334155] font-semibold">B2B Trade Delegations</span>
              </div>
              <div className="bg-white p-4 sm:p-5 rounded-2xl border border-[#E2E8F0] shadow-xs">
                <span className="text-[11px] font-bold text-[#64748B] block uppercase tracking-wider">Convention Centres</span>
                <strong className="text-xl sm:text-2xl font-extrabold text-[#0F172A] block mt-1">3 Hubs</strong>
                <span className="text-xs text-[#334155] font-semibold">Karachi, Lahore, Islamabad</span>
              </div>
            </div>
          </div>

          {/* Search & Filters Controls */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
            <div className="bg-white p-4 sm:p-6 rounded-2xl border border-[#E2E8F0] shadow-sm space-y-4">
              <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
                {/* Search input */}
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Search expos by title, topic, or venue location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-[#CBD5E1] focus:border-[#F59E0B] text-sm text-[#0F172A] font-medium bg-[#F8FAFC] focus:outline-none"
                  />
                  <Icon name="search" className="w-4 h-4 text-[#64748B] absolute left-3.5 top-3.5" />
                </div>

                {/* City Filter Pills */}
                <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
                  <span className="text-xs font-bold text-[#475569] pr-1 hidden sm:inline">City:</span>
                  {cities.map(c => (
                    <button
                      key={c}
                      onClick={() => setCityFilter(c)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                        cityFilter === c
                          ? "bg-[#0F172A] text-white shadow-xs"
                          : "bg-[#F1F5F9] text-[#334155] hover:bg-[#E2E8F0]"
                      }`}
                    >
                      {c === "all" ? "All Cities" : c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Category Filter Pills */}
              <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#F1F5F9]">
                <span className="text-xs font-bold text-[#475569] pr-1">Category:</span>
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setCategoryFilter(cat)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      categoryFilter === cat
                        ? "bg-[#F59E0B] text-[#0F172A] shadow-xs"
                        : "bg-[#F1F5F9] text-[#334155] hover:bg-[#E2E8F0]"
                    }`}
                  >
                    {cat === "all" ? "All Categories" : cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Results Count Strip */}
            <div className="flex items-center justify-between text-xs font-bold text-[#475569] px-1">
              <span>Showing <strong>{filteredExpos.length}</strong> active & upcoming expos</span>
              <span>100% SECP & Verified Trade Pavilions</span>
            </div>

            {/* Expos Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
              {filteredExpos.map(expo => (
                <div 
                  key={expo.id}
                  className="bg-white rounded-2xl border border-[#CBD5E1] shadow-sm hover:shadow-md hover:border-[#F59E0B] transition-all flex flex-col justify-between overflow-hidden group"
                >
                  <div>
                    {/* Banner */}
                    <div className={`h-24 bg-gradient-to-r ${expo.bannerColor || "from-[#0F172A] to-[#F59E0B]"} p-4 flex items-center justify-between text-white relative shadow-inner`}>
                      <span className="px-2.5 py-1 rounded-md text-[10px] font-extrabold bg-black/60 text-white uppercase tracking-wider border border-white/20">
                        {expo.category}
                      </span>
                      <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold bg-[#0F172A] text-[#F59E0B] border border-[#F59E0B]">
                        {expo.status || "Registration Open"}
                      </span>
                    </div>

                    {/* Content */}
                    <div className="p-5 space-y-4">
                      <div>
                        <h3 className="text-lg font-extrabold font-heading text-[#0F172A] group-hover:text-[#D97706] transition-colors leading-snug">
                          {expo.title}
                        </h3>
                        <p className="text-xs text-[#334155] font-normal mt-1.5 line-clamp-2 leading-relaxed">
                          {expo.tagline}
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-2.5 text-xs text-[#0F172A] font-semibold bg-[#F1F5F9] p-3.5 rounded-xl border border-[#E2E8F0]">
                        <div className="flex items-center space-x-1.5">
                          <Icon name="calendar" className="w-3.5 h-3.5 text-[#F59E0B]" />
                          <span className="truncate">{expo.startDate}</span>
                        </div>
                        <div className="flex items-center space-x-1.5">
                          <Icon name="mapPin" className="w-3.5 h-3.5 text-[#D97706]" />
                          <span className="truncate">{expo.location}</span>
                        </div>
                        <div className="flex items-center space-x-1.5">
                          <Icon name="grid" className="w-3.5 h-3.5 text-[#F59E0B]" />
                          <span>{expo.occupiedBooths || 0} / {expo.totalBooths || 48} Booths</span>
                        </div>
                        <div className="flex items-center space-x-1.5">
                          <Icon name="users" className="w-3.5 h-3.5 text-[#D97706]" />
                          <span>{(expo.attendeeCount || 0).toLocaleString()} Attendees</span>
                        </div>
                      </div>

                      <div className="text-[11px] text-[#64748B]">
                        <span>Venue: </span>
                        <strong className="text-[#0F172A]">{expo.venueDetails}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="p-5 pt-0 space-y-2">
                    <button
                      onClick={() => {
                        if (onViewExpoDetails) onViewExpoDetails(expo);
                        else if (onNavigate) onNavigate("expo-details", expo.id);
                      }}
                      className="w-full py-2.5 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] font-extrabold text-xs transition-colors flex items-center justify-center space-x-1.5 shadow-sm"
                    >
                      <Icon name="document" className="w-4 h-4 text-[#0F172A]" />
                      <span>View Full Expo Details & Specs</span>
                    </button>

                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          if (onNavigate) onNavigate("floorplan", expo.id);
                        }}
                        className="flex-1 py-2 rounded-xl bg-[#0F172A] hover:bg-[#1E293B] text-white font-bold text-xs transition-colors flex items-center justify-center space-x-1"
                      >
                        <Icon name="grid" className="w-3.5 h-3.5 text-[#F59E0B]" />
                        <span>2D Floor Plan</span>
                      </button>
                      <button
                        onClick={() => onSelectExpo(expo)}
                        className="px-3 py-2 rounded-xl border border-[#CBD5E1] hover:bg-[#F1F5F9] text-[#334155] font-bold text-xs transition-colors"
                        title="Quick Overview Modal"
                      >
                        Inspect
                      </button>
                      <button
                        onClick={onExhibitorApply}
                        className="px-3 py-2 rounded-xl bg-[#10B981]/15 hover:bg-[#10B981]/25 text-[#059669] border border-[#10B981]/30 font-extrabold text-xs transition-colors"
                        title="Reserve Exhibitor Space"
                      >
                        Book
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Infrastructure Highlights */}
            <div className="pt-8 space-y-4">
              <h3 className="text-xl font-extrabold font-heading text-[#0F172A]">EventSphere Concourse Standards</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-[#FEF3C7] text-[#D97706] flex items-center justify-center font-bold">
                    <Icon name="zap" className="w-5 h-5" />
                  </div>
                  <h4 className="font-extrabold text-sm text-[#0F172A]">220V 3-Phase Utilities</h4>
                  <p className="text-[#475569] leading-relaxed">Dedicated under-floor utility trenches with redundant automatic Caterpillar generators.</p>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-[#FEF3C7] text-[#D97706] flex items-center justify-center font-bold">
                    <Icon name="grid" className="w-5 h-5" />
                  </div>
                  <h4 className="font-extrabold text-sm text-[#0F172A]">Interactive 2D Floor Plan</h4>
                  <p className="text-[#475569] leading-relaxed">CAD-verified booth layout with live beacon tracking and real-time exhibitor matchmaking.</p>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-[#FEF3C7] text-[#D97706] flex items-center justify-center font-bold">
                    <Icon name="users" className="w-5 h-5" />
                  </div>
                  <h4 className="font-extrabold text-sm text-[#0F172A]">Smart NFC Badges</h4>
                  <p className="text-[#475569] leading-relaxed">Instant lead scanning directly transfers contact cards to exhibitor CRM without paper cards.</p>
                </div>
                <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-[#FEF3C7] text-[#D97706] flex items-center justify-center font-bold">
                    <Icon name="shield" className="w-5 h-5" />
                  </div>
                  <h4 className="font-extrabold text-sm text-[#0F172A]">SECP Accreditation</h4>
                  <p className="text-[#475569] leading-relaxed">Every confirmed exhibitor undergoes verification ensuring high-trust B2B transactions.</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      );
    }

    // ========================================================
    // 1. EXPO DETAILS PAGE VIEW (PAGE 1 OF 5)
    // ========================================================
    function ExpoDetailsPageView({ 
      activeExpo, 
      expos = [], 
      onSelectExpo, 
      onSwitchExpo, 
      onNavigate, 
      onExhibitorApply, 
      onRegisterAttendee 
    }) {
      const current = activeExpo || expos[0] || {};
      const occupied = current.occupiedBooths || 38;
      const total = current.totalBooths || 48;
      const pct = Math.round((occupied / total) * 100);

      const highlights = [
        { label: "Dates & Schedule", value: `${current.startDate || 'Nov 12'} - ${current.endDate || 'Nov 15, 2026'}`, sub: "4 Days Plenary Concourse", icon: "calendar" },
        { label: "Convention Venue", value: current.location || "Expo Centre Karachi", sub: current.venueDetails || "Halls 1, 2 & Plenary", icon: "mapPin" },
        { label: "Spatial Capacity", value: `${occupied} / ${total} Reserved`, sub: `${pct}% Booth Allocation Filled`, icon: "grid" },
        { label: "Expected Footfall", value: `${(current.attendeeCount || 8420).toLocaleString()} Verified`, sub: "B2B Procurement Buyers", icon: "users" }
      ];

      const specifications = [
        { label: "Exhibition Ceiling Clearance", value: "8.5 Meters Clear Height" },
        { label: "Floor Load Capacity", value: "3,500 kg / sqm (Heavy Industrial Machinery)" },
        { label: "Electrical Utilities", value: "Dedicated 220V 3-Phase 32A Drops & Backup Gen" },
        { label: "Digital Telemetry", value: "Gigabit Millimeter-Wave 5G & RFID Sensors" },
        { label: "Freight Access", value: "Dual 6-Meter Roll-up Heavy Cargo Doors" },
        { label: "Delegate Lounges", value: "2 VIP Executive Suites + Media Press Arena" }
      ];

      return (
        <div className="space-y-8 pb-16">
          {/* Header Banner */}
          <section className="bg-[#0B0F19] text-white pt-12 sm:pt-16 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#1E293B] shadow-xl">
            <div className="max-w-7xl mx-auto space-y-5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-[#1E293B] border border-[#334155] text-xs font-bold text-[#F59E0B]">
                  {current.category || "Technology & AI"}
                </span>
                <span className="px-3 py-1 rounded-full bg-[#10B981]/20 border border-[#10B981]/30 text-xs font-bold text-[#10B981]">
                  {current.status || "Registration Open"}
                </span>
                <span className="text-xs text-[#94A3B8]">Expo ID: {current.id}</span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight leading-tight">
                {current.title}
              </h1>

              <p className="text-base sm:text-lg text-[#E2E8F0] font-normal leading-relaxed max-w-3xl">
                {current.tagline || current.description}
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={onExhibitorApply}
                  className="px-6 py-3.5 rounded-xl font-extrabold bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] shadow-md transition-all flex items-center space-x-2 text-sm"
                >
                  <Icon name="building" className="w-4 h-4 text-[#0F172A]" />
                  <span>Reserve Exhibitor Booth</span>
                </button>
                <button
                  onClick={onRegisterAttendee}
                  className="px-6 py-3.5 rounded-xl font-bold bg-[#1E293B] hover:bg-[#334155] text-white border border-[#475569] transition-all flex items-center space-x-2 text-sm shadow-sm"
                >
                  <Icon name="users" className="w-4 h-4 text-[#F59E0B]" />
                  <span>Register as Delegate</span>
                </button>
                <button
                  onClick={() => onNavigate("floorplan")}
                  className="px-5 py-3.5 rounded-xl font-semibold bg-transparent hover:bg-[#1E293B] text-[#E2E8F0] hover:text-white border border-[#334155] transition-all text-sm flex items-center space-x-2"
                >
                  <Icon name="grid" className="w-4 h-4 text-[#F59E0B]" />
                  <span>Inspect 2D Floorplan</span>
                </button>
              </div>
            </div>
          </section>

          {/* Event Switcher Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoEventSwitcherBar 
              activeExpo={current} 
              expos={expos} 
              onSwitchExpo={onSwitchExpo || (() => {})} 
            />
          </div>

          {/* Sticky In-Page Navigation Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoSubNavTabs activeTab="expo-details" onNavigate={onNavigate} />
          </div>

          {/* Quick Metrics Strip */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {highlights.map((h, i) => (
                <div key={i} className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-[#FEF3C7] text-[#D97706] flex items-center justify-center font-bold flex-shrink-0">
                    <Icon name={h.icon} className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-[#64748B] block uppercase tracking-wider">{h.label}</span>
                    <strong className="text-base font-extrabold text-[#0F172A] block leading-tight">{h.value}</strong>
                    <span className="text-xs text-[#334155] font-medium">{h.sub}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Detailed Content Grid */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Left Column: Scope & Pass Tiers */}
              <div className="lg:col-span-7 space-y-6">
                <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
                  <h2 className="text-xl font-extrabold font-heading text-[#0F172A]">Exhibition Scope & Industry Impact</h2>
                  <p className="text-sm text-[#334155] leading-relaxed">
                    {current.description || "The premier national convention bringing together corporate buyers, international delegations, software leaders, and researchers under one synchronized roof."}
                  </p>
                  <p className="text-sm text-[#334155] leading-relaxed">
                    Every booth is outfitted with high-density fiber connections, heavy equipment floor loading support, and integrated NFC badge scanners that automatically sync attendee contact information directly into your CRM dashboard.
                  </p>

                  <div className="pt-4 border-t border-[#F1F5F9] space-y-3">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#D97706]">Included with Exhibitor Pass</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#0F172A]">
                      <div className="flex items-center space-x-2">
                        <Icon name="check" className="w-4 h-4 text-[#10B981]" />
                        <span>Dedicated 220V 3-Phase Power Outlets</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="check" className="w-4 h-4 text-[#10B981]" />
                        <span>Carpeted Modular Booth Shell & Spotlights</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="check" className="w-4 h-4 text-[#10B981]" />
                        <span>4 Full VIP Keynote Conference Badges</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Icon name="check" className="w-4 h-4 text-[#10B981]" />
                        <span>Digital Product Showcase in Mobile Catalog</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Delegate Pass Registration Tiers */}
                <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
                  <h3 className="text-lg font-extrabold font-heading text-[#0F172A]">Delegate Registration Tiers</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="p-4 rounded-2xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3 flex flex-col justify-between">
                      <div className="space-y-1">
                        <span className="text-[10px] font-extrabold text-[#64748B] uppercase">Visitor Pass</span>
                        <div className="text-xl font-extrabold text-[#0F172A]">FREE</div>
                        <p className="text-[11px] text-[#475569]">Access to all public halls & open innovation stages.</p>
                      </div>
                      <button
                        onClick={onRegisterAttendee}
                        className="w-full py-2 rounded-xl bg-[#0F172A] text-white text-xs font-bold hover:bg-[#1E293B]"
                      >
                        Register Free
                      </button>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#FEF3C7] border border-[#FDE68A] space-y-3 flex flex-col justify-between relative shadow-xs">
                      <span className="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full bg-[#D97706] text-white text-[9px] font-extrabold uppercase">Popular</span>
                      <div className="space-y-1">
                        <span className="text-[10px] font-extrabold text-[#92400E] uppercase">VIP Executive</span>
                        <div className="text-xl font-extrabold text-[#0F172A]">PKR 15,000</div>
                        <p className="text-[11px] text-[#92400E]">4-day keynote concourse, VIP lounge & networking lunch.</p>
                      </div>
                      <button
                        onClick={onRegisterAttendee}
                        className="w-full py-2 rounded-xl bg-[#F59E0B] text-[#0F172A] text-xs font-extrabold hover:bg-[#D97706]"
                      >
                        Get VIP Pass
                      </button>
                    </div>

                    <div className="p-4 rounded-2xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-3 flex flex-col justify-between">
                      <div className="space-y-1">
                        <span className="text-[10px] font-extrabold text-[#64748B] uppercase">Corporate Package</span>
                        <div className="text-xl font-extrabold text-[#0F172A]">PKR 45,000</div>
                        <p className="text-[11px] text-[#475569]">5 Full Badges + Dedicated 2-Hour B2B Boardroom access.</p>
                      </div>
                      <button
                        onClick={onRegisterAttendee}
                        className="w-full py-2 rounded-xl bg-[#0F172A] text-white text-xs font-bold hover:bg-[#1E293B]"
                      >
                        Corporate Group
                      </button>
                    </div>
                  </div>
                </div>

                {/* Sub-Pages Quick Navigator Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div 
                    onClick={() => onNavigate("exhibitor-directory")}
                    className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs hover:border-[#F59E0B] cursor-pointer transition-all space-y-2 group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#D97706] uppercase tracking-wider">Page 2</span>
                      <Icon name="arrowRight" className="w-4 h-4 text-[#64748B] group-hover:translate-x-1 transition-transform" />
                    </div>
                    <h4 className="font-extrabold text-base text-[#0F172A] font-heading">Exhibitor Directory</h4>
                    <p className="text-xs text-[#475569]">Browse 40+ verified vendors, product tags, and representatives.</p>
                  </div>

                  <div 
                    onClick={() => onNavigate("event-schedule")}
                    className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs hover:border-[#F59E0B] cursor-pointer transition-all space-y-2 group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#D97706] uppercase tracking-wider">Page 3</span>
                      <Icon name="arrowRight" className="w-4 h-4 text-[#64748B] group-hover:translate-x-1 transition-transform" />
                    </div>
                    <h4 className="font-extrabold text-base text-[#0F172A] font-heading">Event Schedule</h4>
                    <p className="text-xs text-[#475569]">Explore 4-day plenary keynote agenda, tracks & speaker bios.</p>
                  </div>

                  <div 
                    onClick={() => onNavigate("floorplan")}
                    className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs hover:border-[#F59E0B] cursor-pointer transition-all space-y-2 group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#D97706] uppercase tracking-wider">Page 4</span>
                      <Icon name="arrowRight" className="w-4 h-4 text-[#64748B] group-hover:translate-x-1 transition-transform" />
                    </div>
                    <h4 className="font-extrabold text-base text-[#0F172A] font-heading">Interactive Floorplan</h4>
                    <p className="text-xs text-[#475569]">Inspect 2D hall layout, pricing tiers, and pulsing map beacon.</p>
                  </div>

                  <div 
                    onClick={() => onNavigate("expo-feedback")}
                    className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs hover:border-[#F59E0B] cursor-pointer transition-all space-y-2 group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#D97706] uppercase tracking-wider">Page 5</span>
                      <Icon name="arrowRight" className="w-4 h-4 text-[#64748B] group-hover:translate-x-1 transition-transform" />
                    </div>
                    <h4 className="font-extrabold text-base text-[#0F172A] font-heading">Contact & Feedback</h4>
                    <p className="text-xs text-[#475569]">Submit ratings, inquiries, and view on-floor emergency hotlines.</p>
                  </div>
                </div>
              </div>

              {/* Right Column: Architectural Specifications */}
              <div className="lg:col-span-5 space-y-6">
                <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-[#F1F5F9] pb-3">
                    <h3 className="font-heading font-extrabold text-base text-[#0F172A]">Technical Venue Specifications</h3>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-[#FEF3C7] text-[#92400E]">Verified CAD</span>
                  </div>

                  <div className="space-y-3">
                    {specifications.map((s, idx) => (
                      <div key={idx} className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-0.5">
                        <span className="text-[11px] font-bold text-[#64748B] block">{s.label}</span>
                        <strong className="text-xs font-extrabold text-[#0F172A] block">{s.value}</strong>
                      </div>
                    ))}
                  </div>

                  {/* Floor Plan Mini-Progress */}
                  <div className="p-4 rounded-2xl bg-[#0F172A] text-white space-y-2.5">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-bold">Hall Space Allocation</span>
                      <span className="text-[#F59E0B] font-extrabold">{pct}% Reserved</span>
                    </div>
                    <div className="w-full h-2 bg-[#334155] rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-[#F59E0B] to-[#FBBF24] rounded-full" style={{ width: `${pct}%` }}></div>
                    </div>
                    <div className="text-[11px] text-[#CBD5E1] flex justify-between">
                      <span>{occupied} Reserved</span>
                      <span>{total - occupied} Booths Available</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      );
    }

    // ========================================================
    // 2. EXHIBITOR DIRECTORY VIEW (PAGE 2 OF 5)
    // ========================================================
    function PublicExhibitorDirectoryView({ 
      activeExpo, 
      expos = [], 
      onSwitchExpo, 
      exhibitors = [], 
      onNavigate, 
      onLocateBooth, 
      onContactExhibitor 
    }) {
      const [searchTerm, setSearchTerm] = useState("");
      const [catFilter, setCatFilter] = useState("all");
      const [hallFilter, setHallFilter] = useState("all");

      const categories = ["all", "Robotics & Automation", "Renewable Energy", "Cybersecurity & Defense", "Computing & AI Hardware", "Healthcare & Life Sciences"];

      const filtered = (exhibitors || []).filter(e => {
        const matchesCat = catFilter === "all" || e.category === catFilter;
        const matchesHall = hallFilter === "all" || (e.boothId && e.boothId.startsWith(hallFilter));
        const matchesSearch = (e.name && e.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
                              (e.tagline && e.tagline.toLowerCase().includes(searchTerm.toLowerCase())) ||
                              (e.boothId && e.boothId.toLowerCase().includes(searchTerm.toLowerCase())) ||
                              (e.representative && e.representative.toLowerCase().includes(searchTerm.toLowerCase()));
        return matchesCat && matchesHall && matchesSearch;
      });

      return (
        <div className="space-y-8 pb-16">
          {/* Header Banner */}
          <section className="bg-[#0B0F19] text-white pt-12 sm:pt-16 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#1E293B] shadow-xl">
            <div className="max-w-7xl mx-auto space-y-4">
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#1E293B] border border-[#334155] text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-[#F59E0B] animate-pulse"></span>
                <span className="text-[#F59E0B] font-bold">Exhibitor Directory & Commercial Catalog</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight leading-tight">
                Verified Exhibitors & <span className="text-[#F59E0B]">Trade Vendors</span>
              </h1>
              <p className="text-base sm:text-lg text-[#E2E8F0] font-normal leading-relaxed max-w-3xl">
                Explore confirmed exhibitors showcasing at {activeExpo?.title || "Pakistan Tech & AI Expo 2026"}. Click "Locate on Map" to trigger the pulsing beacon on the 2D floor plan.
              </p>
            </div>
          </section>

          {/* Event Switcher Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoEventSwitcherBar 
              activeExpo={activeExpo} 
              expos={expos} 
              onSwitchExpo={onSwitchExpo || (() => {})} 
            />
          </div>

          {/* Sticky In-Page Navigation Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoSubNavTabs activeTab="exhibitor-directory" onNavigate={onNavigate} />
          </div>

          {/* Controls: Search, Category & Hall Filter */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
            <div className="bg-white p-4 sm:p-6 rounded-2xl border border-[#E2E8F0] shadow-sm space-y-4">
              <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Search by vendor name, representative, product keyword, or Booth ID (e.g. A-101)..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-[#CBD5E1] focus:border-[#F59E0B] text-sm text-[#0F172A] font-medium bg-[#F8FAFC] focus:outline-none"
                  />
                  <Icon name="search" className="w-4 h-4 text-[#64748B] absolute left-3.5 top-3.5" />
                </div>

                <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
                  <span className="text-xs font-bold text-[#475569] pr-1">Hall:</span>
                  {[
                    { id: "all", label: "All Halls" },
                    { id: "A", label: "Hall A (Industrial)" },
                    { id: "B", label: "Hall B (Tech Arena)" }
                  ].map(h => (
                    <button
                      key={h.id}
                      onClick={() => setHallFilter(h.id)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                        hallFilter === h.id
                          ? "bg-[#0F172A] text-white shadow-xs"
                          : "bg-[#F1F5F9] text-[#334155] hover:bg-[#E2E8F0]"
                      }`}
                    >
                      {h.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Category Pills */}
              <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-[#F1F5F9]">
                <span className="text-xs font-bold text-[#475569] pr-1">Category:</span>
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setCatFilter(cat)}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      catFilter === cat
                        ? "bg-[#F59E0B] text-[#0F172A] shadow-xs font-extrabold"
                        : "bg-[#F1F5F9] text-[#334155] hover:bg-[#E2E8F0]"
                    }`}
                  >
                    {cat === "all" ? "All Categories" : cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between text-xs font-bold text-[#475569] px-1">
              <span>Showing <strong>{filtered.length}</strong> accredited exhibitors</span>
              <span>SECP & FBR Verified Business Profiles</span>
            </div>

            {/* Exhibitors Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-stretch">
              {filtered.map(ex => (
                <div key={ex.id} className="bg-white rounded-2xl border border-[#CBD5E1] shadow-sm hover:shadow-md hover:border-[#F59E0B] transition-all p-6 flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#0F172A] to-[#F59E0B] text-white flex items-center justify-center font-extrabold text-sm shadow-sm flex-shrink-0">
                        {ex.logo || ex.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="flex flex-col items-end">
                        <span className="px-2.5 py-1 rounded-lg bg-[#FEF3C7] text-[#92400E] border border-[#FDE68A] text-xs font-extrabold">
                          {ex.boothId}
                        </span>
                        <span className="text-[10px] text-[#10B981] font-bold mt-1">● SECP Verified</span>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-base font-extrabold font-heading text-[#0F172A] leading-snug">{ex.name}</h3>
                      <p className="text-xs text-[#D97706] font-semibold mt-0.5">{ex.category}</p>
                      <p className="text-xs text-[#334155] mt-1.5 leading-relaxed line-clamp-2">{ex.tagline}</p>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-1 text-xs">
                      <div className="flex justify-between text-[#475569]">
                        <span>Lead Rep:</span>
                        <strong className="text-[#0F172A]">{ex.representative}</strong>
                      </div>
                      <div className="flex justify-between text-[#475569]">
                        <span>Official Website:</span>
                        <span className="text-[#D97706] font-medium truncate max-w-[160px]">{ex.website}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-[#F1F5F9] flex gap-2">
                    <button
                      onClick={() => onLocateBooth(ex.boothId)}
                      className="flex-1 py-2.5 rounded-xl bg-[#0F172A] hover:bg-[#1E293B] text-white font-bold text-xs transition-colors flex items-center justify-center space-x-1.5"
                    >
                      <Icon name="mapPin" className="w-3.5 h-3.5 text-[#F59E0B]" />
                      <span>Locate on Map</span>
                    </button>
                    <button
                      onClick={() => onContactExhibitor(ex)}
                      className="px-3.5 py-2.5 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] font-extrabold text-xs transition-colors flex items-center justify-center"
                      title="Contact Exhibitor"
                    >
                      <Icon name="message" className="w-4 h-4 text-[#0F172A]" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
    }

    // ========================================================
    // 3. EVENT SCHEDULE & TRACKS VIEW (PAGE 3 OF 5)
    // ========================================================
    function PublicEventScheduleView({ 
      activeExpo, 
      expos = [], 
      onSwitchExpo, 
      sessions = [], 
      onNavigate, 
      onToggleBookmark, 
      triggerToast 
    }) {
      const [activeDay, setActiveDay] = useState("all");
      const [trackFilter, setTrackFilter] = useState("all");
      const [searchQuery, setSearchQuery] = useState("");

      const days = ["all", "Day 1 (Nov 12)", "Day 2 (Nov 13)", "Day 3 (Nov 14)", "Day 4 (Nov 15)"];
      const tracks = ["all", "Keynote", "Cybersecurity", "Clean Energy", "Semiconductor", "Venture"];

      const filteredSessions = sessions.filter(s => {
        const matchesDay = activeDay === "all" || s.day === activeDay;
        const matchesTrack = trackFilter === "all" || s.track === trackFilter;
        const matchesSearch = (s.title && s.title.toLowerCase().includes(searchQuery.toLowerCase())) ||
                              (s.speakerName && s.speakerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
                              (s.stage && s.stage.toLowerCase().includes(searchQuery.toLowerCase()));
        return matchesDay && matchesTrack && matchesSearch;
      });

      return (
        <div className="space-y-8 pb-16">
          {/* Header Banner */}
          <section className="bg-[#0B0F19] text-white pt-12 sm:pt-16 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#1E293B] shadow-xl">
            <div className="max-w-7xl mx-auto space-y-4">
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#1E293B] border border-[#334155] text-xs font-semibold">
                <Icon name="calendar" className="w-4 h-4 text-[#F59E0B]" />
                <span className="text-[#F59E0B] font-bold">Conference Agenda & Multi-Track Schedule</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight leading-tight">
                Keynote Presentations & <span className="text-[#F59E0B]">Panels</span>
              </h1>
              <p className="text-base sm:text-lg text-[#E2E8F0] font-normal leading-relaxed max-w-3xl">
                4 full days of visionary keynotes, technical deep-dives, and industrial panels at {activeExpo?.title || "Karachi Expo Centre"}. Bookmark sessions to sync with your personal agenda.
              </p>
            </div>
          </section>

          {/* Event Switcher Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoEventSwitcherBar 
              activeExpo={activeExpo} 
              expos={expos} 
              onSwitchExpo={onSwitchExpo || (() => {})} 
            />
          </div>

          {/* Sticky In-Page Navigation Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoSubNavTabs activeTab="event-schedule" onNavigate={onNavigate} />
          </div>

          {/* Controls: Day Selector & Track Filter */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
            <div className="bg-white p-4 sm:p-6 rounded-2xl border border-[#E2E8F0] shadow-sm space-y-4">
              
              {/* Day Selector Pills */}
              <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
                {days.map(d => (
                  <button
                    key={d}
                    onClick={() => setActiveDay(d)}
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex-shrink-0 ${
                      activeDay === d
                        ? "bg-[#0F172A] text-white shadow-sm"
                        : "bg-[#F1F5F9] text-[#334155] hover:bg-[#E2E8F0]"
                    }`}
                  >
                    {d === "all" ? "All 4 Days" : d}
                  </button>
                ))}
              </div>

              {/* Track Filters & Search */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-3 border-t border-[#F1F5F9]">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-xs font-bold text-[#475569] pr-1">Track:</span>
                  {tracks.map(t => (
                    <button
                      key={t}
                      onClick={() => setTrackFilter(t)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        trackFilter === t
                          ? "bg-[#F59E0B] text-[#0F172A] shadow-xs font-extrabold"
                          : "bg-[#F1F5F9] text-[#334155] hover:bg-[#E2E8F0]"
                      }`}
                    >
                      {t === "all" ? "All Tracks" : t}
                    </button>
                  ))}
                </div>

                <div className="relative w-full sm:w-72">
                  <input
                    type="text"
                    placeholder="Search session or speaker..."
                    value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl border border-[#CBD5E1] text-xs bg-[#F8FAFC] focus:outline-none focus:border-[#F59E0B]"
                  />
                  <Icon name="search" className="w-3.5 h-3.5 text-[#64748B] absolute left-3 top-2.5" />
                </div>
              </div>

            </div>

            {/* Sessions List */}
            <div className="space-y-4">
              {filteredSessions.map(session => (
                <div key={session.id} className="bg-white p-6 rounded-2xl border border-[#CBD5E1] shadow-sm hover:border-[#F59E0B] transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                  
                  {/* Left: Time & Stage */}
                  <div className="space-y-1.5 min-w-[200px]">
                    <span className="px-2.5 py-1 rounded-md text-[11px] font-extrabold bg-[#0F172A] text-white">
                      {session.day || "Day 1"}
                    </span>
                    <div className="text-sm font-extrabold text-[#D97706] pt-1 flex items-center space-x-1.5">
                      <Icon name="clock" className="w-4 h-4" />
                      <span>{session.time}</span>
                    </div>
                    <div className="text-xs text-[#64748B] flex items-center space-x-1">
                      <Icon name="mapPin" className="w-3.5 h-3.5 text-[#94A3B8]" />
                      <span>{session.stage}</span>
                    </div>
                  </div>

                  {/* Middle: Session Title & Speaker */}
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center space-x-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-[#FEF3C7] text-[#92400E]">
                        {session.track}
                      </span>
                      <span className="text-xs text-[#64748B]">{session.registeredCount} / {session.capacity} Attendees Reserved</span>
                    </div>
                    <h3 className="text-base sm:text-lg font-extrabold font-heading text-[#0F172A] leading-snug">
                      {session.title}
                    </h3>
                    <p className="text-xs text-[#334155] leading-relaxed">
                      {session.description}
                    </p>

                    <div className="flex items-center space-x-3 pt-1">
                      <div className="w-8 h-8 rounded-lg bg-[#0F172A] text-white font-extrabold text-xs flex items-center justify-center">
                        {session.speakerAvatar || "SP"}
                      </div>
                      <div className="text-xs">
                        <strong className="text-[#0F172A]">{session.speakerName}</strong>
                        <span className="text-[#64748B] block">{session.speakerRole}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Bookmark Action */}
                  <div className="self-end md:self-center">
                    <button
                      onClick={() => onToggleBookmark(session.id)}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 ${
                        session.isBookmarked
                          ? "bg-[#F59E0B] text-[#0F172A] font-extrabold shadow-sm"
                          : "bg-[#F1F5F9] text-[#0F172A] hover:bg-[#E2E8F0]"
                      }`}
                    >
                      <Icon name={session.isBookmarked ? "bookmarkFilled" : "bookmark"} className="w-4 h-4 text-[#0F172A]" />
                      <span>{session.isBookmarked ? "Bookmarked" : "Add to Agenda"}</span>
                    </button>
                  </div>

                </div>
              ))}
            </div>

          </div>
        </div>
      );
    }

    // ========================================================
    // 4. INTERACTIVE 2D FLOOR PLAN VIEW (PAGE 4 OF 5)
    // ========================================================
    function PublicFloorPlanView({ 
      activeExpo, 
      expos = [], 
      onSwitchExpo, 
      booths = [], 
      highlightedBoothId, 
      onNavigate, 
      onSelectBooth, 
      onReserveBooth 
    }) {
      const reservedCount = (booths || []).filter(b => b.status === "reserved" || b.status === "occupied").length;
      const availableCount = (booths || []).length - reservedCount;
      const occupancyRate = (booths || []).length > 0 ? Math.round((reservedCount / booths.length) * 100) : 75;

      return (
        <div className="space-y-8 pb-16">
          {/* Header Banner */}
          <section className="bg-[#0B0F19] text-white pt-12 sm:pt-16 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#1E293B] shadow-xl">
            <div className="max-w-7xl mx-auto space-y-4">
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#1E293B] border border-[#334155] text-xs font-semibold">
                <Icon name="grid" className="w-4 h-4 text-[#F59E0B]" />
                <span className="text-[#F59E0B] font-bold">2D Architectural Blueprint & Hall Allocator</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight leading-tight">
                Interactive Exhibition <span className="text-[#F59E0B]">Floor Plan</span>
              </h1>
              <p className="text-base sm:text-lg text-[#E2E8F0] font-normal leading-relaxed max-w-3xl">
                Real-time 2D spatial allocation across Hall A (Main Pavilion) and Hall B (Tech Arena). Click any booth to inspect electrical specs, pricing, and reservation options.
              </p>
            </div>
          </section>

          {/* Event Switcher Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoEventSwitcherBar 
              activeExpo={activeExpo} 
              expos={expos} 
              onSwitchExpo={onSwitchExpo || (() => {})} 
            />
          </div>

          {/* Sticky In-Page Navigation Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoSubNavTabs activeTab="floorplan" onNavigate={onNavigate} />
          </div>

          {/* Legend & Stats Banner */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="bg-white p-5 rounded-2xl border border-[#CBD5E1] shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-4 text-xs font-bold text-[#0F172A]">
                <div className="flex items-center space-x-1.5">
                  <span className="w-3.5 h-3.5 rounded bg-[#10B981] border border-[#059669]"></span>
                  <span>Available Booth</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-3.5 h-3.5 rounded bg-[#3B82F6] border border-[#1D4ED8]"></span>
                  <span>Reserved</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-3.5 h-3.5 rounded bg-[#F59E0B] border border-[#D97706]"></span>
                  <span>Premium Corner</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-3.5 h-3.5 rounded bg-[#0F172A] border border-[#334155]"></span>
                  <span>Occupied / Confirmed</span>
                </div>
              </div>

              <div className="flex items-center space-x-3 text-xs">
                <span className="text-[#64748B]">Capacity:</span>
                <span className="font-extrabold text-[#0F172A]">{reservedCount} / {booths.length} Reserved ({occupancyRate}%)</span>
                <span className="px-2 py-0.5 rounded-full bg-[#10B981]/20 text-[#059669] font-bold">{availableCount} Open</span>
              </div>
            </div>
          </div>

          {/* Floor Plan Component */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
            <FloorPlanGrid 
              booths={booths}
              onSelectBooth={onSelectBooth}
              highlightedBoothId={highlightedBoothId}
            />
          </div>
        </div>
      );
    }

    // ========================================================
    // 5. CONTACT & FEEDBACK VIEW (PAGE 5 OF 5)
    // ========================================================
    function PublicFeedbackPageView({ 
      activeExpo, 
      expos = [], 
      onSwitchExpo, 
      onNavigate, 
      triggerToast 
    }) {
      const [rating, setRating] = useState(5);
      const [category, setCategory] = useState("General Platform Experience");
      const [comments, setComments] = useState("");
      const [submitted, setSubmitted] = useState(false);

      const handleSubmit = (e) => {
        e.preventDefault();
        if (!comments.trim()) {
          if (triggerToast) triggerToast("Please enter your feedback comments.", "error");
          return;
        }
        setSubmitted(true);
        if (triggerToast) triggerToast("Thank you for your rating & feedback! Your review helps modernize the expo experience.", "success");
      };

      const testimonials = [
        {
          name: "Engr. Tariq Mehmood",
          org: "Precision Robotics Systems",
          role: "Exhibitor & Sponsor",
          rating: 5,
          text: "The 2D interactive floorplan and NFC lead synchronization cut our badge exchange times by half. Seamless utility drops in Hall A."
        },
        {
          name: "Dr. Ayesha Siddiqua",
          org: "Frontier AI Council",
          role: "Keynote Speaker",
          rating: 5,
          text: "Keynote session agenda management and live delegate bookmarks kept our plenary session hall completely packed. World-class setup."
        },
        {
          name: "Hamza Bin Tariq",
          org: "Sindh Tech Procurement Delegation",
          role: "Registered Buyer",
          rating: 5,
          text: "Finding booth locations with the pulsing beacon made navigating the vast Karachi Expo Centre concourse effortless."
        }
      ];

      return (
        <div className="space-y-8 pb-16">
          {/* Header Banner */}
          <section className="bg-[#0B0F19] text-white pt-12 sm:pt-16 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#1E293B] shadow-xl">
            <div className="max-w-7xl mx-auto space-y-4">
              <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-[#1E293B] border border-[#334155] text-xs font-semibold">
                <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse"></span>
                <span className="text-[#10B981] font-bold">Feedback & Inquiries Desk</span>
              </div>
              <h1 className="text-3xl sm:text-5xl font-extrabold font-heading text-white tracking-tight leading-tight">
                Expo Feedback & <span className="text-[#F59E0B]">Support Inquiries</span>
              </h1>
              <p className="text-base sm:text-lg text-[#E2E8F0] font-normal leading-relaxed max-w-3xl">
                Rate your exhibition experience, report technical or logistics issues, or submit questions directly to the on-floor event command team for {activeExpo?.title || "Karachi Expo Centre"}.
              </p>
            </div>
          </section>

          {/* Event Switcher Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoEventSwitcherBar 
              activeExpo={activeExpo} 
              expos={expos} 
              onSwitchExpo={onSwitchExpo || (() => {})} 
            />
          </div>

          {/* Sticky In-Page Navigation Bar */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ExpoSubNavTabs activeTab="expo-feedback" onNavigate={onNavigate} />
          </div>

          {/* Feedback Form & Inquiries Grid */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* Form */}
              <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-3xl border border-[#CBD5E1] shadow-sm space-y-6">
                <div>
                  <h2 className="text-xl sm:text-2xl font-extrabold font-heading text-[#0F172A]">Submit Expo Feedback & Rating</h2>
                  <p className="text-xs sm:text-sm text-[#334155] mt-1">Directly reviewed by Event Operations Directors & venue management.</p>
                </div>

                {submitted ? (
                  <div className="p-6 rounded-2xl bg-[#FEF3C7] border border-[#FDE68A] text-[#92400E] space-y-3">
                    <div className="flex items-center space-x-2">
                      <Icon name="check" className="w-6 h-6 text-[#D97706]" />
                      <h3 className="font-heading font-extrabold text-lg">Thank You For Your Feedback!</h3>
                    </div>
                    <p className="text-xs leading-relaxed">
                      Your rating of <strong>{rating} Stars</strong> for category <strong>{category}</strong> has been logged into the event analytics dashboard.
                    </p>
                    <button
                      type="button"
                      onClick={() => { setSubmitted(false); setComments(""); setRating(5); }}
                      className="px-4 py-2 rounded-xl bg-[#0F172A] text-white text-xs font-bold"
                    >
                      Submit Another Review
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                    <div>
                      <label className="text-[#0F172A] font-bold block mb-1">Platform & Expo Rating</label>
                      <div className="flex items-center space-x-2 p-2 bg-[#F8FAFC] rounded-xl border border-[#E2E8F0]">
                        {[1, 2, 3, 4, 5].map(star => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setRating(star)}
                            className={`p-1.5 rounded-lg transition-transform hover:scale-110 ${rating >= star ? "text-[#F59E0B]" : "text-[#CBD5E1]"}`}
                          >
                            <svg className="w-7 h-7 fill-current" viewBox="0 0 20 20">
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                          </button>
                        ))}
                        <span className="text-xs font-bold text-[#0F172A] pl-2">{rating} / 5 Stars</span>
                      </div>
                    </div>

                    <div>
                      <label className="text-[#0F172A] font-bold block mb-1">Feedback Category</label>
                      <select
                        value={category}
                        onChange={e => setCategory(e.target.value)}
                        className="w-full p-3 rounded-xl border border-[#CBD5E1] text-xs font-medium bg-[#F8FAFC] text-[#0F172A] focus:outline-none focus:border-[#F59E0B]"
                      >
                        <option>General Platform Experience</option>
                        <option>Hall Air Conditioning & Power Reliability</option>
                        <option>Mobile 2D Floor Plan & Beacon Locator</option>
                        <option>Registration & Digital NFC Badges</option>
                        <option>Catering, Restrooms & Lounges</option>
                        <option>Technical Issue / Bug Report</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[#0F172A] font-bold block mb-1">Comments & Detailed Observations *</label>
                      <textarea
                        rows="4"
                        required
                        placeholder="Please share your observations or suggestions to help us improve..."
                        value={comments}
                        onChange={e => setComments(e.target.value)}
                        className="w-full p-3 rounded-xl border border-[#CBD5E1] text-xs bg-[#F8FAFC] text-[#0F172A] focus:outline-none focus:border-[#F59E0B]"
                      ></textarea>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] font-extrabold text-xs transition-all shadow-md flex items-center justify-center space-x-1.5"
                    >
                      <span>Submit Review & Feedback</span>
                      <Icon name="arrowRight" className="w-4 h-4 text-[#0F172A]" />
                    </button>
                  </form>
                )}
              </div>

              {/* Operations Emergency Contacts & Verified Reviews */}
              <div className="lg:col-span-5 space-y-4">
                <div className="bg-white p-6 rounded-3xl border border-[#CBD5E1] shadow-xs space-y-4">
                  <h3 className="font-extrabold text-base text-[#0F172A] font-heading">On-Floor Helpdesks & Hotlines</h3>

                  <div className="space-y-3 text-xs">
                    <div className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-0.5">
                      <strong className="text-[#0F172A] block">Hall A Operations Desk</strong>
                      <span className="text-[#475569] block">Located adjacent to Entrance Portal 1</span>
                      <span className="text-[#D97706] font-bold">Ext: 104 • Radio Channel 3</span>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-0.5">
                      <strong className="text-[#0F172A] block">Medical & First Aid Station</strong>
                      <span className="text-[#475569] block">South Wing Concourse Level 1</span>
                      <span className="text-[#10B981] font-bold">Hotline: +92 300 9991122</span>
                    </div>

                    <div className="p-3 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-0.5">
                      <strong className="text-[#0F172A] block">220V Electrician / IT Support</strong>
                      <span className="text-[#475569] block">Technical Utility Corridor Hall B</span>
                      <span className="text-[#0F172A] font-bold">WhatsApp: +92 321 4445566</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-3xl border border-[#CBD5E1] shadow-xs space-y-4">
                  <h3 className="font-extrabold text-base text-[#0F172A] font-heading">Verified Community Feedback</h3>
                  <div className="space-y-3">
                    {testimonials.map((t, idx) => (
                      <div key={idx} className="p-3.5 rounded-xl bg-[#F8FAFC] border border-[#E2E8F0] space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <strong className="text-[#0F172A]">{t.name}</strong>
                          <span className="text-[#F59E0B]">★★★★★</span>
                        </div>
                        <p className="text-[11px] text-[#475569] leading-relaxed">"{t.text}"</p>
                        <div className="text-[10px] text-[#64748B] flex justify-between">
                          <span>{t.org}</span>
                          <span className="font-bold text-[#D97706]">{t.role}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      );
    }

    // ========================================================
    function ExpoDetailModal({ expo, onClose, onReserveBooth, onRegisterAttendee }) {
      if (!expo) return null;

      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-2xl bg-white rounded-3xl border border-[#CBD5E1] shadow-2xl overflow-hidden max-h-[92vh] flex flex-col justify-between">
            
            {/* Header Banner */}
            <div className={`p-6 bg-gradient-to-r ${expo.bannerColor || "from-[#0F172A] to-[#F59E0B]"} text-white relative`}>
              <div className="flex items-center justify-between pb-2">
                <span className="px-2.5 py-0.5 rounded text-[10px] font-extrabold bg-black/60 text-white uppercase tracking-wider border border-white/20">
                  {expo.category}
                </span>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-xl bg-black/40 hover:bg-black/70 text-white transition-colors"
                >
                  <Icon name="x" className="w-5 h-5" />
                </button>
              </div>

              <h2 className="text-xl sm:text-2xl font-extrabold font-heading text-white">{expo.title}</h2>
              <p className="text-xs text-[#E2E8F0] mt-1">{expo.tagline}</p>
            </div>

            {/* Scrollable Body */}
            <div className="p-6 space-y-5 overflow-y-auto">
              {/* Timing & Venue */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-[#F1F5F9] p-4 rounded-2xl border border-[#E2E8F0]">
                <div>
                  <span className="text-[10px] text-[#64748B] uppercase font-bold block">Dates & Schedule:</span>
                  <span className="font-bold text-[#0F172A] text-sm">{expo.startDate} - {expo.endDate}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#64748B] uppercase font-bold block">Venue & Hall:</span>
                  <span className="font-bold text-[#0F172A] text-sm truncate block">{expo.location}</span>
                </div>
              </div>

              {/* Description */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#D97706] mb-1">Exhibition Overview</h3>
                <p className="text-xs sm:text-sm text-[#334155] leading-relaxed">
                  {expo.description || "The premier national convention bringing together verified exhibitors, researchers, and trade delegations for high-impact commercial engagement and product demonstrations."}
                </p>
              </div>

              {/* Hall Floor Stats */}
              <div className="bg-white p-4 rounded-2xl border border-[#E2E8F0] space-y-2.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-[#0F172A] flex items-center space-x-1.5">
                    <Icon name="grid" className="w-4 h-4 text-[#F59E0B]" />
                    <span>2D Floor Plan Occupation</span>
                  </span>
                  <span className="text-[#D97706] font-extrabold">{expo.occupiedBooths || 38} / {expo.totalBooths || 48} Reserved</span>
                </div>
                <div className="w-full h-2.5 bg-[#F1F5F9] rounded-full overflow-hidden border border-[#E2E8F0]">
                  <div className="h-full bg-gradient-to-r from-[#F59E0B] to-[#D97706] rounded-full" style={{ width: `${Math.round(((expo.occupiedBooths || 38) / (expo.totalBooths || 48)) * 100)}%` }}></div>
                </div>
              </div>

              {/* Included Amenities */}
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#D97706] mb-2">Included Booth Amenities</h3>
                <div className="grid grid-cols-2 gap-2 text-xs text-[#334155]">
                  <div className="flex items-center space-x-1.5">
                    <Icon name="check" className="w-4 h-4 text-[#10B981]" />
                    <span>Dedicated 220V 3-Phase Power</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Icon name="check" className="w-4 h-4 text-[#10B981]" />
                    <span>Gigabit Fiber LAN & WiFi</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Icon name="check" className="w-4 h-4 text-[#10B981]" />
                    <span>4 VIP Conference Passes</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <Icon name="check" className="w-4 h-4 text-[#10B981]" />
                    <span>NFC Lead Scanner App Access</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="p-5 border-t border-[#E2E8F0] bg-[#F8FAFC] flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-[#CBD5E1] text-xs font-bold text-[#475569] hover:bg-[#F1F5F9]"
              >
                Close Dialog
              </button>
              <div className="flex items-center space-x-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => { onClose(); if (onRegisterAttendee) onRegisterAttendee(); }}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-[#0F172A] hover:bg-[#1E293B] text-white text-xs font-bold transition-all shadow-sm"
                >
                  Register as Delegate
                </button>
                <button
                  type="button"
                  onClick={() => { onClose(); if (onReserveBooth) onReserveBooth(); }}
                  className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] text-xs font-extrabold transition-all shadow-md"
                >
                  Reserve Booth
                </button>
              </div>
            </div>

          </div>
        </div>
      );
    }

    function AdminDashboardView({ 
      activeExpo, 
      data, 
      activeTab, 
      setActiveTab, 
      booths, 
      applications, 
      sessions, 
      analytics, 
      onSelectBooth, 
      onApproveReject,
      onOpenCreateExpo,
      onOpenAddSession
    }) {
      return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
          
          {/* Dashboard Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-100 text-indigo-800 uppercase tracking-wide">
                  Organizer Control Hub
                </span>
                <span className="text-xs text-slate-500">•</span>
                <span className="text-xs font-semibold text-slate-700">{activeExpo?.title}</span>
              </div>
              <h1 className="text-2xl font-extrabold font-heading text-slate-900 mt-1">Expo Administration & Operations</h1>
              <p className="text-xs text-slate-500">Monitor booth occupancy, allocate space on the 2D floor plan, and review exhibitor credentials.</p>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={onOpenAddSession}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors flex items-center space-x-1.5"
              >
                <Icon name="plus" className="w-3.5 h-3.5 text-slate-600" />
                <span>Add Session</span>
              </button>
              <button
                onClick={onOpenCreateExpo}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm transition-colors flex items-center space-x-1.5"
              >
                <Icon name="plus" className="w-3.5 h-3.5 text-white" />
                <span>Create New Expo</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">Registered Attendees</span>
                <Icon name="users" className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-2xl font-bold font-heading text-slate-900 mt-2">{analytics.totalRegistrations.toLocaleString()}</div>
              <div className="text-[11px] text-emerald-600 font-medium mt-1 flex items-center space-x-1">
                <span>↑ 12% vs last edition</span>
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">Booth Occupancy</span>
                <Icon name="grid" className="w-4 h-4 text-teal-600" />
              </div>
              <div className="text-2xl font-bold font-heading text-slate-900 mt-2">{analytics.boothOccupancyRate}%</div>
              <div className="text-[11px] text-slate-500 font-medium mt-1">
                {booths.filter(b => b.status === "occupied" || b.status === "reserved" || b.status === "vip").length} of {booths.length} assigned
              </div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">Pending Approvals</span>
                <Icon name="fileText" className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-2xl font-bold font-heading text-slate-900 mt-2">
                {applications.filter(a => a.status === "pending").length}
              </div>
              <div className="text-[11px] text-amber-600 font-medium mt-1">Requires review</div>
            </div>

            <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-500">Booth Foot-Traffic Scans</span>
                <Icon name="barChart" className="w-4 h-4 text-purple-600" />
              </div>
              <div className="text-2xl font-bold font-heading text-slate-900 mt-2">{analytics.boothTrafficScans.toLocaleString()}</div>
              <div className="text-[11px] text-indigo-600 font-medium mt-1">Real-time RFID telemetry</div>
            </div>
          </div>

          {/* Subtabs Navigation */}
          <div className="border-b border-slate-200 flex space-x-8 text-sm font-medium">
            <button
              onClick={() => setActiveTab("overview")}
              className={`pb-3 border-b-2 transition-colors ${activeTab === "overview" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              Overview & Analytics
            </button>
            <button
              onClick={() => setActiveTab("floorplan")}
              className={`pb-3 border-b-2 transition-colors ${activeTab === "floorplan" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              Interactive Floor Plan Allocator
            </button>
            <button
              onClick={() => setActiveTab("applications")}
              className={`pb-3 border-b-2 transition-colors relative ${activeTab === "applications" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              <span>Exhibitor Applications</span>
              <span className="ml-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                {applications.filter(a => a.status === "pending").length}
              </span>
            </button>
            <button
              onClick={() => setActiveTab("schedule")}
              className={`pb-3 border-b-2 transition-colors ${activeTab === "schedule" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              Schedule & Sessions
            </button>
          </div>

          {/* TAB 1: OVERVIEW & ANALYTICS */}
          {activeTab === "overview" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Traffic rankings */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs lg:col-span-2 space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-heading font-bold text-base text-slate-900">Highest Foot-Traffic Booths (Hall A & B)</h3>
                    <p className="text-xs text-slate-500">Live RFID badge interaction counts</p>
                  </div>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Live Telemetry
                  </span>
                </div>

                <div className="space-y-4 pt-2">
                  {analytics.topBoothsByTraffic.map((item, idx) => (
                    <div key={idx} className="space-y-1.5">
                      <div className="flex justify-between text-xs font-medium">
                        <span className="text-slate-800">{item.name}</span>
                        <span className="text-slate-600 font-semibold">{item.visits.toLocaleString()} scans</span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-indigo-500 to-blue-600 rounded-full transition-all duration-1000"
                          style={{ width: `${(item.visits / 4500) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Popular Sessions */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
                <h3 className="font-heading font-bold text-base text-slate-900">Popular Keynotes & Labs</h3>
                <p className="text-xs text-slate-500">Capacity utilization by attendee registrations</p>
                <div className="space-y-3 pt-2">
                  {analytics.popularSessions.map((sess, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1">
                      <div className="text-xs font-semibold text-slate-900 truncate">{sess.title}</div>
                      <div className="flex justify-between text-[11px] text-slate-500">
                        <span>{sess.registrations} registered</span>
                        <span className="font-medium text-slate-700">{Math.round((sess.registrations / sess.capacity) * 100)}% capacity</span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-emerald-500 rounded-full" 
                          style={{ width: `${(sess.registrations / sess.capacity) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: FLOOR PLAN ALLOCATOR */}
          {activeTab === "floorplan" && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="font-heading font-bold text-lg text-slate-900">Interactive Hall Grid Space Allocator</h3>
                  <p className="text-xs text-slate-500">Click any booth space to inspect dimensions, alter pricing, or reassign exhibitors.</p>
                </div>

                {/* Legend */}
                <div className="flex items-center space-x-4 text-xs">
                  <div className="flex items-center space-x-1.5">
                    <span className="w-3.5 h-3.5 rounded bg-emerald-100 border border-emerald-400"></span>
                    <span className="text-slate-600">Available</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-3.5 h-3.5 rounded bg-amber-100 border border-amber-400"></span>
                    <span className="text-slate-600">Reserved</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-3.5 h-3.5 rounded bg-slate-200 border border-slate-400"></span>
                    <span className="text-slate-600">Occupied</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-3.5 h-3.5 rounded bg-purple-100 border border-purple-400"></span>
                    <span className="text-slate-600">VIP Pavilion</span>
                  </div>
                </div>
              </div>

              {/* 2D Floor Plan Hall Layout */}
              <FloorPlanGrid 
                booths={booths} 
                onSelectBooth={onSelectBooth}
                highlightedBoothId={null}
              />
            </div>
          )}

          {/* TAB 3: EXHIBITOR APPLICATIONS */}
          {activeTab === "applications" && (
            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
              <div className="p-6 border-b border-slate-200 flex justify-between items-center">
                <div>
                  <h3 className="font-heading font-bold text-lg text-slate-900">Exhibitor Application Review Queue</h3>
                  <p className="text-xs text-slate-500">Review submitted corporate credentials, verify product documents, and allocate booths.</p>
                </div>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-slate-100 text-slate-700">
                  {applications.length} Total Submissions
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-600 uppercase tracking-wider text-[11px] border-b border-slate-200">
                    <tr>
                      <th className="px-6 py-3.5">Company & Category</th>
                      <th className="px-6 py-3.5">Contact Delegate</th>
                      <th className="px-6 py-3.5">Requested Tier</th>
                      <th className="px-6 py-3.5">Submitted Documents</th>
                      <th className="px-6 py-3.5">Status</th>
                      <th className="px-6 py-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {applications.map(app => (
                      <tr key={app.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="px-6 py-4">
                          <div className="font-semibold text-slate-900 text-sm">{app.companyName}</div>
                          <div className="text-slate-500 text-[11px]">{app.category}</div>
                          <div className="text-slate-400 text-[10px] mt-0.5 max-w-xs truncate">{app.productsSummary}</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="font-medium text-slate-800">{app.contactName}</div>
                          <div className="text-slate-500 text-[11px]">{app.email}</div>
                          <div className="text-slate-400 text-[10px]">{app.phone}</div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-medium text-slate-700">{app.boothRequested}</span>
                          <div className="text-slate-400 text-[10px]">Applied: {app.dateApplied}</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="space-y-1">
                            {app.documents.map((doc, i) => (
                              <div key={i} className="flex items-center space-x-1 text-indigo-600 hover:text-indigo-800 cursor-pointer text-[11px]">
                                <Icon name="fileText" className="w-3.5 h-3.5" />
                                <span className="underline">{doc}</span>
                              </div>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${
                            app.status === "approved"
                              ? "bg-emerald-100 text-emerald-800"
                              : app.status === "rejected"
                              ? "bg-rose-100 text-rose-800"
                              : "bg-amber-100 text-amber-800"
                          }`}>
                            {app.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right space-x-2">
                          {app.status === "pending" ? (
                            <>
                              <button
                                onClick={() => onApproveReject(app.id, "approved")}
                                className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs"
                              >
                                Approve
                              </button>
                              <button
                                onClick={() => onApproveReject(app.id, "rejected")}
                                className="px-3 py-1.5 rounded-lg bg-white border border-rose-300 text-rose-600 hover:bg-rose-50 font-semibold text-xs"
                              >
                                Reject
                              </button>
                            </>
                          ) : (
                            <span className="text-slate-400 text-xs italic">Reviewed</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: SCHEDULE & SESSION BUILDER */}
          {activeTab === "schedule" && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex justify-between items-center">
                <div>
                  <h3 className="font-heading font-bold text-lg text-slate-900">Multi-Track Conference Schedule</h3>
                  <p className="text-xs text-slate-500">Configure keynotes, technical workshops, and speaker assignments.</p>
                </div>
                <button
                  onClick={onOpenAddSession}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-sm"
                >
                  <Icon name="plus" className="w-3.5 h-3.5 text-white" />
                  <span>Create Session Slot</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sessions.map(s => (
                  <div key={s.id} className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs space-y-3">
                    <div className="flex items-start justify-between">
                      <span className="px-2.5 py-1 rounded text-[11px] font-bold bg-indigo-50 text-indigo-700 uppercase tracking-wide">
                        {s.track}
                      </span>
                      <span className="text-xs text-slate-500 font-medium">{s.day}</span>
                    </div>

                    <div>
                      <h4 className="font-heading font-bold text-base text-slate-900">{s.title}</h4>
                      <p className="text-xs text-slate-500 mt-1 leading-relaxed">{s.description}</p>
                    </div>

                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-2">
                        <div className="w-7 h-7 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-[10px]">
                          {s.speakerAvatar}
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900">{s.speakerName}</div>
                          <div className="text-[10px] text-slate-500 truncate max-w-[180px]">{s.speakerRole}</div>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-medium text-slate-700 flex items-center space-x-1 justify-end">
                          <Icon name="clock" className="w-3.5 h-3.5 text-indigo-600" />
                          <span>{s.time}</span>
                        </div>
                        <div className="text-[10px] text-slate-400">{s.stage}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      );
    }

    // ========================================================
    // VIEW SUB-COMPONENT: EXHIBITOR PORTAL
    // ========================================================
    function ExhibitorPortalView({ 
      activeExpo, 
      booths, 
      exhibitors, 
      messages, 
      activeTab, 
      setActiveTab, 
      onSelectBooth, 
      onReserveBooth,
      triggerToast 
    }) {
      const myCompany = exhibitors[0]; // PakRobotics Technologies as demo profile
      const [chatInput, setChatInput] = useState("");
      const [chatHistory, setChatHistory] = useState(messages[0]?.history || []);

      const handleSendMessage = () => {
        if (!chatInput.trim()) return;
        const newMsg = { from: "me", text: chatInput, time: "Just now" };
        setChatHistory(prev => [...prev, newMsg]);
        setChatInput("");
        triggerToast("Message sent to exhibitor colleague!", "info");
      };

      return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
          
          {/* Exhibitor Welcome Header */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-8 rounded-3xl border border-slate-800 shadow-md">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 rounded-2xl bg-indigo-600 flex items-center justify-center font-bold text-2xl shadow-lg shadow-indigo-600/30">
                  NR
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h1 className="text-2xl font-bold font-heading">{myCompany.name}</h1>
                    <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Verified Vendor
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">{myCompany.tagline}</p>
                  <div className="flex items-center space-x-4 text-xs text-slate-400 mt-2">
                    <span>Assigned: <strong className="text-white">Booth {myCompany.boothId} (Hall A)</strong></span>
                    <span>•</span>
                    <span>Lead Representative: <strong className="text-white">{myCompany.representative}</strong></span>
                  </div>
                </div>
              </div>

              <div className="flex sm:flex-col gap-2 w-full sm:w-auto">
                <button
                  onClick={() => setActiveTab("booth-selection")}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                    activeTab === "booth-selection"
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-800 text-slate-200 hover:bg-slate-700"
                  }`}
                >
                  Interactive Booth Selector
                </button>
                <button
                  onClick={() => setActiveTab("profile")}
                  className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                    activeTab === "profile"
                      ? "bg-indigo-600 text-white"
                      : "bg-slate-800 text-slate-200 hover:bg-slate-700"
                  }`}
                >
                  Edit Company Profile
                </button>
              </div>
            </div>
          </div>

          {/* Subtab Navigation */}
          <div className="border-b border-slate-200 flex space-x-8 text-sm font-medium">
            <button
              onClick={() => setActiveTab("booth-selection")}
              className={`pb-3 border-b-2 transition-colors ${activeTab === "booth-selection" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              Floor Plan & Booth Reservation
            </button>
            <button
              onClick={() => setActiveTab("profile")}
              className={`pb-3 border-b-2 transition-colors ${activeTab === "profile" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              Company Catalog & Showcase
            </button>
            <button
              onClick={() => setActiveTab("messages")}
              className={`pb-3 border-b-2 transition-colors relative ${activeTab === "messages" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              <span>B2B Chat & Inquiries</span>
              <span className="ml-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800">
                1 Unread
              </span>
            </button>
          </div>

          {/* TAB 1: BOOTH RESERVATION */}
          {activeTab === "booth-selection" && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="font-heading font-bold text-lg text-slate-900">Select & Reserve Your Expo Booth Space</h3>
                  <p className="text-xs text-slate-500">Pick any available green booth. Standard (10x10), Corner (15x15), or Island Pavilion (20x20).</p>
                </div>
                <div className="flex items-center space-x-3 text-xs">
                  <span className="flex items-center space-x-1.5"><span className="w-3.5 h-3.5 rounded bg-emerald-100 border border-emerald-400"></span><span>Available</span></span>
                  <span className="flex items-center space-x-1.5"><span className="w-3.5 h-3.5 rounded bg-amber-100 border border-amber-400"></span><span>Reserved</span></span>
                  <span className="flex items-center space-x-1.5"><span className="w-3.5 h-3.5 rounded bg-slate-200 border border-slate-400"></span><span>Occupied</span></span>
                </div>
              </div>

              <FloorPlanGrid 
                booths={booths}
                onSelectBooth={onSelectBooth}
                highlightedBoothId={myCompany.boothId}
              />
            </div>
          )}

          {/* TAB 2: COMPANY PROFILE & CATALOG */}
          {activeTab === "profile" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
                <h3 className="font-heading font-bold text-base text-slate-900">Exhibitor Directory Profile</h3>
                <div className="space-y-3 text-xs">
                  <div>
                    <label className="text-slate-500 font-medium">Company Name</label>
                    <input 
                      type="text" 
                      defaultValue={myCompany.name} 
                      className="w-full mt-1 p-2.5 rounded-lg border border-slate-300 text-slate-900 font-medium"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500 font-medium">Industry Category</label>
                    <input 
                      type="text" 
                      defaultValue={myCompany.category} 
                      className="w-full mt-1 p-2.5 rounded-lg border border-slate-300 text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500 font-medium">Tagline</label>
                    <input 
                      type="text" 
                      defaultValue={myCompany.tagline} 
                      className="w-full mt-1 p-2.5 rounded-lg border border-slate-300 text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500 font-medium">Official Contact Email</label>
                    <input 
                      type="email" 
                      defaultValue={myCompany.email} 
                      className="w-full mt-1 p-2.5 rounded-lg border border-slate-300 text-slate-900"
                    />
                  </div>
                  <button 
                    onClick={() => triggerToast("Exhibitor profile changes saved successfully!", "success")}
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors mt-2"
                  >
                    Save Profile Updates
                  </button>
                </div>
              </div>

              {/* Products Showcase */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs md:col-span-2 space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-heading font-bold text-base text-slate-900">Featured Products on Display</h3>
                    <p className="text-xs text-slate-500">Items displayed in your digital booth catalog to attendees.</p>
                  </div>
                  <button 
                    onClick={() => triggerToast("Product catalog modal ready for new entry.", "info")}
                    className="px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition-colors"
                  >
                    + Add New Product
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  {myCompany.products.map((prod, idx) => (
                    <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-2">
                      <div className="flex items-center space-x-2">
                        <Icon name="sparkles" className="w-4 h-4 text-indigo-600" />
                        <h4 className="font-bold text-xs text-slate-900">{prod.name}</h4>
                      </div>
                      <p className="text-[11px] text-slate-600 leading-relaxed">{prod.spec}</p>
                      <div className="pt-2 flex justify-between items-center text-[10px] text-indigo-600">
                        <span className="font-semibold underline cursor-pointer">View Datasheet</span>
                        <span className="text-slate-400">Active Display</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: B2B MESSAGES & CHAT */}
          {activeTab === "messages" && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden h-[540px]">
              {/* Left Inbox List */}
              <div className="border-r border-slate-200 flex flex-col h-full bg-slate-50/50">
                <div className="p-4 border-b border-slate-200">
                  <h3 className="font-heading font-bold text-sm text-slate-900">Direct Inquiries</h3>
                  <p className="text-[11px] text-slate-500">Messages from organizers and neighbors</p>
                </div>
                <div className="divide-y divide-slate-100 overflow-y-auto flex-1">
                  {messages.map(msg => (
                    <div key={msg.id} className="p-4 hover:bg-white cursor-pointer transition-colors bg-white">
                      <div className="flex justify-between items-start">
                        <h4 className="font-semibold text-xs text-slate-900">{msg.sender}</h4>
                        <span className="text-[10px] text-slate-400">{msg.timestamp}</span>
                      </div>
                      <p className="text-[11px] text-indigo-600 font-medium">{msg.senderRole}</p>
                      <p className="text-xs text-slate-500 mt-1 truncate">{msg.preview}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chat Conversation Box */}
              <div className="md:col-span-2 flex flex-col h-full bg-white">
                <div className="p-4 border-b border-slate-200 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-xs text-slate-900">{messages[0]?.sender}</h4>
                    <p className="text-[11px] text-slate-500">{messages[0]?.senderRole}</p>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-semibold">
                    Neighboring Booth
                  </span>
                </div>

                <div className="flex-1 p-4 overflow-y-auto space-y-3">
                  {chatHistory.map((item, i) => (
                    <div key={i} className={`flex ${item.from === "me" ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-md p-3 rounded-2xl text-xs ${
                        item.from === "me" 
                          ? "bg-indigo-600 text-white rounded-br-none" 
                          : "bg-slate-100 text-slate-800 rounded-bl-none"
                      }`}>
                        <p>{item.text}</p>
                        <div className={`text-[9px] mt-1 ${item.from === "me" ? "text-indigo-200 text-right" : "text-slate-400"}`}>
                          {item.time}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-3 border-t border-slate-200 flex items-center space-x-2 bg-slate-50">
                  <input
                    type="text"
                    placeholder="Type your reply to neighboring booth..."
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                    className="flex-1 bg-white border border-slate-300 rounded-xl px-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                  <button
                    onClick={handleSendMessage}
                    className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white transition-colors"
                  >
                    <Icon name="send" className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

        </div>
      );
    }

    // ========================================================
    // VIEW SUB-COMPONENT: ATTENDEE INTERFACE
    // ========================================================
    function AttendeeView({ 
      activeExpo, 
      exhibitors, 
      booths, 
      sessions, 
      activeTab, 
      setActiveTab, 
      highlightedBoothId,
      onLocateBooth, 
      onToggleBookmark, 
      onContactExhibitor,
      onSelectBooth
    }) {
      const [categoryFilter, setCategoryFilter] = useState("all");
      const [searchTerm, setSearchTerm] = useState("");
      const [onlyBookmarked, setOnlyBookmarked] = useState(false);

      const categories = ["all", "Robotics & Automation", "Renewable Energy", "Cybersecurity & Defense", "Computing & AI Hardware", "Healthcare & Life Sciences"];

      const filteredExhibitors = exhibitors.filter(e => {
        const matchesCat = categoryFilter === "all" || e.category === categoryFilter;
        const matchesSearch = e.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                              e.tagline.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              e.boothId.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesCat && matchesSearch;
      });

      const filteredSessions = sessions.filter(s => {
        if (onlyBookmarked && !s.isBookmarked) return false;
        return true;
      });

      const bookmarkedCount = sessions.filter(s => s.isBookmarked).length;

      return (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-8">
          
          {/* Header Banner */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div>
              <div className="flex items-center space-x-2 text-xs text-indigo-600 font-semibold uppercase tracking-wider">
                <Icon name="sparkles" className="w-3.5 h-3.5" />
                <span>Attendee Portal • {activeExpo?.title}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold font-heading text-slate-900 mt-1">Exhibitor Matchmaking & Hall Map</h1>
              <p className="text-xs text-slate-500 mt-1">Search 40+ leading vendors, locate their physical booth on the floor, and reserve workshop seats.</p>
            </div>

            <div className="flex items-center space-x-3">
              <div className="px-4 py-2.5 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center space-x-2.5">
                <Icon name="bookmarkFilled" className="w-4 h-4 text-indigo-600" />
                <div>
                  <div className="text-xs font-bold text-indigo-900">{bookmarkedCount} Sessions Saved</div>
                  <div className="text-[10px] text-indigo-600 font-medium">Personal Agenda</div>
                </div>
              </div>
            </div>
          </div>

          {/* Subtab Navigation */}
          <div className="border-b border-slate-200 flex space-x-8 text-sm font-medium">
            <button
              onClick={() => setActiveTab("directory")}
              className={`pb-3 border-b-2 transition-colors ${activeTab === "directory" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              Exhibitor Directory
            </button>
            <button
              onClick={() => setActiveTab("floorplan")}
              className={`pb-3 border-b-2 transition-colors relative ${activeTab === "floorplan" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              <span>Interactive Floor Navigator</span>
              {highlightedBoothId && (
                <span className="ml-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-600 text-white animate-pulse">
                  Booth {highlightedBoothId}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab("agenda")}
              className={`pb-3 border-b-2 transition-colors ${activeTab === "agenda" ? "border-indigo-600 text-indigo-600 font-semibold" : "border-transparent text-slate-500 hover:text-slate-800"}`}
            >
              Conference Agenda ({sessions.length})
            </button>
          </div>

          {/* TAB 1: EXHIBITOR DIRECTORY */}
          {activeTab === "directory" && (
            <div className="space-y-6">
              {/* Search & Filter Bar */}
              <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="relative w-full md:w-96">
                  <input
                    type="text"
                    placeholder="Search company, product, or booth ID (e.g. A-101)..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 bg-white text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                  <Icon name="search" className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                </div>

                <div className="flex flex-wrap gap-2 w-full md:w-auto">
                  {categories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setCategoryFilter(cat)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        categoryFilter === cat
                          ? "bg-slate-900 text-white"
                          : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-100"
                      }`}
                    >
                      {cat === "all" ? "All Categories" : cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Exhibitors Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredExhibitors.map(ex => (
                  <div 
                    key={ex.id}
                    className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between interactive-card"
                  >
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 rounded-xl ${ex.badgeColor} text-white flex items-center justify-center font-bold text-sm shadow-sm`}>
                            {ex.name.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <h3 className="font-heading font-bold text-sm text-slate-900">{ex.name}</h3>
                            <span className="text-[11px] text-slate-500 font-medium">{ex.category}</span>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                          {ex.boothId}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {ex.tagline}
                      </p>

                      <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-100 space-y-1">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Products on Display</div>
                        <div className="text-xs text-slate-800 font-medium truncate">
                          {ex.products.map(p => p.name).join(" • ")}
                        </div>
                      </div>
                    </div>

                    <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between gap-2">
                      <button
                        onClick={() => onLocateBooth(ex.boothId)}
                        className="flex-1 py-2 px-3 rounded-xl bg-slate-900 hover:bg-indigo-600 text-white font-semibold text-xs transition-colors flex items-center justify-center space-x-1.5"
                      >
                        <Icon name="mapPin" className="w-3.5 h-3.5" />
                        <span>Locate on Map</span>
                      </button>

                      <button
                        onClick={() => onContactExhibitor(ex)}
                        className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-colors flex items-center justify-center"
                        title="Send Inquiry / Book Appointment"
                      >
                        <Icon name="message" className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: INTERACTIVE FLOOR MAP */}
          {activeTab === "floorplan" && (
            <div className="space-y-6">
              <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="font-heading font-bold text-lg text-slate-900">Live Expo Hall Floor Navigator</h3>
                  <p className="text-xs text-slate-500">
                    {highlightedBoothId 
                      ? `Currently beaconing Booth ${highlightedBoothId} with a pulsing border!` 
                      : "Click any booth to view exhibitor catalog, specifications, or contact representatives."}
                  </p>
                </div>

                <div className="flex items-center space-x-3 text-xs">
                  <span className="flex items-center space-x-1.5"><span className="w-3.5 h-3.5 rounded bg-emerald-100 border border-emerald-400"></span><span>Open Booth</span></span>
                  <span className="flex items-center space-x-1.5"><span className="w-3.5 h-3.5 rounded bg-purple-100 border border-purple-400"></span><span>VIP Pavilion</span></span>
                  <span className="flex items-center space-x-1.5"><span className="w-3.5 h-3.5 rounded bg-indigo-500"></span><span className="font-semibold text-indigo-700">Selected Beacon</span></span>
                </div>
              </div>

              <FloorPlanGrid 
                booths={booths}
                onSelectBooth={onSelectBooth}
                highlightedBoothId={highlightedBoothId}
              />
            </div>
          )}

          {/* TAB 3: AGENDA & SESSIONS */}
          {activeTab === "agenda" && (
            <div className="space-y-6">
              {/* Filter controls */}
              <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
                <div>
                  <h3 className="font-heading font-bold text-sm text-slate-900">All Keynotes, Workshops & Panels</h3>
                  <p className="text-xs text-slate-500">Bookmarking a session sends automated calendar reminders.</p>
                </div>
                <button
                  onClick={() => setOnlyBookmarked(!onlyBookmarked)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-colors ${
                    onlyBookmarked 
                      ? "bg-indigo-600 text-white" 
                      : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                  }`}
                >
                  <Icon name="bookmarkFilled" className="w-3.5 h-3.5" />
                  <span>Show My Agenda Only ({bookmarkedCount})</span>
                </button>
              </div>

              {/* Sessions List */}
              <div className="space-y-4">
                {filteredSessions.map(s => (
                  <div 
                    key={s.id}
                    className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6 interactive-card"
                  >
                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded text-[11px] font-bold bg-indigo-50 text-indigo-700 uppercase tracking-wide">
                          {s.track}
                        </span>
                        <span className="text-xs font-semibold text-slate-500">{s.day}</span>
                        <span className="text-slate-300">•</span>
                        <span className="text-xs text-indigo-600 font-medium flex items-center space-x-1">
                          <Icon name="clock" className="w-3.5 h-3.5" />
                          <span>{s.time}</span>
                        </span>
                        <span className="text-slate-300">•</span>
                        <span className="text-xs text-slate-500">{s.stage}</span>
                      </div>

                      <h4 className="font-heading font-bold text-base text-slate-900">{s.title}</h4>
                      <p className="text-xs text-slate-500 leading-relaxed max-w-2xl">{s.description}</p>

                      <div className="flex items-center space-x-2 pt-1 text-xs">
                        <div className="w-6 h-6 rounded-full bg-slate-800 text-white flex items-center justify-center font-bold text-[9px]">
                          {s.speakerAvatar}
                        </div>
                        <span className="font-semibold text-slate-800">{s.speakerName}</span>
                        <span className="text-slate-400">({s.speakerRole})</span>
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-center justify-between sm:items-end gap-3 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                      <div className="text-xs text-slate-500">
                        <strong className="text-slate-800">{s.registeredCount}</strong> / {s.capacity} seats filled
                      </div>

                      <button
                        onClick={() => onToggleBookmark(s.id)}
                        className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-xs ${
                          s.isBookmarked
                            ? "bg-emerald-600 hover:bg-emerald-700 text-white"
                            : "bg-indigo-600 hover:bg-indigo-700 text-white"
                        }`}
                      >
                        <Icon name={s.isBookmarked ? "check" : "bookmark"} className="w-4 h-4" />
                        <span>{s.isBookmarked ? "Bookmarked (Saved)" : "Add to My Agenda"}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      );
    }

    // ========================================================
    // REUSABLE SUB-COMPONENT: INTERACTIVE 2D FLOOR PLAN GRID
    // ========================================================
    function FloorPlanGrid({ booths, onSelectBooth, highlightedBoothId }) {
      const [currentHall, setCurrentHall] = useState("Hall A");

      const hallBooths = booths.filter(b => b.hall === currentHall);

      const statusStyles = {
        available: "bg-emerald-50 border-emerald-300 text-emerald-900 hover:bg-emerald-100",
        reserved: "bg-amber-50 border-amber-300 text-amber-900 hover:bg-amber-100",
        occupied: "bg-slate-100 border-slate-300 text-slate-800 hover:bg-slate-200",
        vip: "bg-purple-50 border-purple-400 text-purple-900 hover:bg-purple-100 shadow-sm"
      };

      return (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 space-y-6">
          {/* Hall Tab Selector */}
          <div className="flex items-center justify-between border-b border-slate-200 pb-4">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setCurrentHall("Hall A")}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  currentHall === "Hall A"
                    ? "bg-slate-900 text-white shadow-sm"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                Hall A (Main Pavilion)
              </button>
              <button
                onClick={() => setCurrentHall("Hall B")}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  currentHall === "Hall B"
                    ? "bg-slate-900 text-white shadow-sm"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                Hall B (Tech & Innovations)
              </button>
            </div>

            <div className="text-xs text-slate-500 font-medium">
              Showing <strong>{hallBooths.length}</strong> allocated booth zones
            </div>
          </div>

          {/* Floor Canvas Area */}
          <div className="floor-plan-grid rounded-2xl border border-slate-200/80 p-8 min-h-[460px] relative bg-slate-50/40 flex flex-col justify-between">
            {/* Entrance & Stage Markers */}
            <div className="flex justify-between items-center pb-6">
              <div className="px-4 py-1.5 rounded-lg bg-slate-200/90 text-slate-700 text-[11px] font-bold tracking-wider uppercase border border-slate-300">
                ← Main Public Entrance
              </div>
              <div className="px-6 py-1.5 rounded-lg bg-indigo-100 text-indigo-900 text-[11px] font-bold tracking-wider uppercase border border-indigo-200">
                Keynote Stage & Screen Area →
              </div>
            </div>

            {/* Grid of Booths */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 my-4">
              {hallBooths.map(booth => {
                const isTarget = highlightedBoothId === booth.id;
                return (
                  <div
                    key={booth.id}
                    onClick={() => onSelectBooth(booth)}
                    className={`booth-tile p-5 rounded-2xl border-2 flex flex-col justify-between h-36 ${statusStyles[booth.status]} ${
                      isTarget ? "booth-highlighted" : ""
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <span className="font-heading font-extrabold text-sm tracking-tight">{booth.id}</span>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-white/80 border border-slate-200">
                        {booth.tier.split(" ")[0]}
                      </span>
                    </div>

                    <div className="space-y-0.5 my-1">
                      <div className="font-bold text-xs truncate">
                        {booth.exhibitorName || "Space Available"}
                      </div>
                      <div className="text-[10px] text-slate-500 truncate">
                        {booth.dimensions}
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t border-slate-200/60 text-[11px]">
                      <span className="font-semibold">${booth.price.toLocaleString()}</span>
                      <span className="capitalize font-medium text-[10px]">{booth.status}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Emergency & Restroom Markers */}
            <div className="flex justify-between items-center pt-6 text-[11px] text-slate-400 font-medium">
              <span>Restrooms & Catering Lounge Area</span>
              <span>Emergency Fire Exit A-2</span>
            </div>
          </div>
        </div>
      );
    }

    // ========================================================
    // MODAL SUB-COMPONENTS
    // ========================================================

    // 1. Booth Detail Modal
    function BoothDetailModal({ booth, role, onClose, onReserve, onLocate }) {
      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-start">
              <div>
                <span className="px-2.5 py-1 rounded text-[11px] font-bold bg-indigo-50 text-indigo-700 uppercase tracking-wide">
                  {booth.hall} • Zone {booth.id}
                </span>
                <h3 className="text-2xl font-bold font-heading text-slate-900 mt-1">{booth.name}</h3>
                <p className="text-xs text-slate-500">{booth.dimensions} — {booth.tier}</p>
              </div>
              <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-medium">Status:</span>
                <span className="font-bold capitalize text-slate-900">{booth.status}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-medium">Assigned Exhibitor:</span>
                <span className="font-bold text-slate-900">{booth.exhibitorName || "None (Open For Reservation)"}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60">
                <span className="text-slate-500 font-medium">Power Supply:</span>
                <span className="font-medium text-slate-800">{booth.power}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 font-medium">Rental Rate:</span>
                <span className="font-bold text-indigo-600 text-sm">${booth.price.toLocaleString()} USD</span>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Included Amenities</h4>
              <div className="flex flex-wrap gap-1.5">
                {booth.amenities.map((a, i) => (
                  <span key={i} className="px-2.5 py-1 rounded-md text-[11px] bg-slate-100 text-slate-700 font-medium">
                    ✓ {a}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-end space-x-3">
              <button 
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Close
              </button>

              {role === "exhibitor" && booth.status === "available" && (
                <button
                  onClick={() => onReserve(booth.id)}
                  className="px-5 py-2.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
                >
                  Reserve Booth (${booth.price})
                </button>
              )}

              {role === "attendee" && (
                <button
                  onClick={() => { onLocate(booth.id); onClose(); }}
                  className="px-5 py-2.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm flex items-center space-x-1"
                >
                  <Icon name="mapPin" className="w-3.5 h-3.5" />
                  <span>Highlight on Floor Plan</span>
                </button>
              )}
            </div>
          </div>
        </div>
      );
    }

    // 2. Authentication Modal (Full Sign In, Registration & 2-Step Password Reset)
    function AuthModal({ mode, setMode, onClose, onSuccess }) {
      // Login State
      const [email, setEmail] = useState("usman.khan@techpak.example.pk");
      const [password, setPassword] = useState("••••••••••••");
      const [rememberMe, setRememberMe] = useState(true);

      // Register State (Pakistani Trade Profiles)
      const [regName, setRegName] = useState("Engr. Hassan Raza");
      const [regEmail, setRegEmail] = useState("hassan.raza@paktech.pk");
      const [regPhone, setRegPhone] = useState("+92 (300) 412-8899");
      const [regOrg, setRegOrg] = useState("Habib Industrial Automation");
      const [regRole, setRegRole] = useState("attendee");
      const [regPassword, setRegPassword] = useState("P@kistan2026!");
      const [regConfirmPassword, setRegConfirmPassword] = useState("P@kistan2026!");
      const [regTerms, setRegTerms] = useState(true);

      // Forgot Password State (Multi-step verification flow)
      const [forgotStep, setForgotStep] = useState(1); // 1: request, 2: verify & change
      const [forgotEmail, setForgotEmail] = useState("usman.khan@techpak.example.pk");
      const [resetCode, setResetCode] = useState("584920");
      const [inputCode, setInputCode] = useState("584920");
      const [newPassword, setNewPassword] = useState("");
      const [confirmNewPassword, setConfirmNewPassword] = useState("");
      const [forgotMessage, setForgotMessage] = useState(null);
      const [forgotError, setForgotError] = useState(null);

      // Quick 1-Click Pakistani Demo Persona Switcher
      const selectDemoPersona = (personaRole) => {
        if (personaRole === "admin") {
          setEmail("ops@eventsphere.example.pk");
          setPassword("Admin@2026");
        } else if (personaRole === "exhibitor") {
          setEmail("info@pakrobotics.example.pk");
          setPassword("Exhibitor@2026");
        } else {
          setEmail("usman.khan@techpak.example.pk");
          setPassword("Attendee@2026");
        }
      };

      // Handler for Login Submit
      const handleLoginSubmit = (e) => {
        e.preventDefault();
        let role = "attendee";
        let name = "Muhammad Usman";
        let organization = "TechPak Systems";
        let avatar = "MU";
        let phone = "+92 (300) 123-4567";

        const lowerEmail = email.toLowerCase();
        if (lowerEmail.includes("ops") || lowerEmail.includes("admin")) {
          role = "admin";
          name = "Farhan Akhtar";
          organization = "EventSphere Operations";
          avatar = "FA";
          phone = "+92 (21) 3456-7890";
        } else if (lowerEmail.includes("robotics") || lowerEmail.includes("exhibitor") || lowerEmail.includes("shams")) {
          role = "exhibitor";
          name = "Dr. Tariq Mehmood";
          organization = "PakRobotics Technologies";
          avatar = "TM";
          phone = "+92 (21) 3456-7890";
        } else {
          role = "attendee";
          name = "Muhammad Usman";
          organization = "TechPak Systems";
          avatar = "MU";
          phone = "+92 (300) 123-4567";
        }

        onSuccess({ name, email, role, organization, phone, avatar }, "login");
      };

      // Handler for Registration Submit
      const handleRegisterSubmit = (e) => {
        e.preventDefault();
        if (regPassword !== regConfirmPassword) {
          alert("Passwords do not match! Please verify your password entry.");
          return;
        }
        if (!regTerms) {
          alert("Please accept the EventSphere trade terms and contactless badge regulations.");
          return;
        }

        const initials = regName.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase() || "PK";
        onSuccess({
          name: regName,
          email: regEmail,
          phone: regPhone,
          organization: regOrg,
          role: regRole,
          avatar: initials
        }, "register");
      };

      // Handler for Forgot Password Step 1
      const handleSendResetCode = (e) => {
        e.preventDefault();
        if (!forgotEmail.trim()) return;
        setForgotMessage(`6-digit OTP code dispatched to ${forgotEmail}! (Demo verification code: 584920)`);
        setForgotError(null);
        setForgotStep(2);
      };

      // Handler for Forgot Password Step 2
      const handleResetPasswordSubmit = (e) => {
        e.preventDefault();
        if (inputCode.trim() !== "584920" && inputCode.trim() !== resetCode) {
          setForgotError("Invalid verification OTP. Please enter the demo code: 584920");
          return;
        }
        if (!newPassword || newPassword.length < 6) {
          setForgotError("Password must be at least 6 characters long.");
          return;
        }
        if (newPassword !== confirmNewPassword) {
          setForgotError("New passwords do not match!");
          return;
        }

        // Successfully updated
        setForgotError(null);
        setForgotMessage(`Password reset successfully for ${forgotEmail}! Please sign in now with your new password.`);
        setEmail(forgotEmail);
        setPassword(newPassword);
        setTimeout(() => {
          setMode("login");
          setForgotStep(1);
        }, 1500);
      };

      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200 my-8">
            
            {/* Header */}
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-100 text-amber-800 border border-amber-300">
                  {mode === "login" ? "Secure Sign In" : mode === "register" ? "Verified Trade Registration" : "Account Recovery"}
                </span>
                <h3 className="text-2xl font-extrabold font-heading text-slate-900 mt-1">
                  {mode === "login" ? "Sign In to EventSphere" : mode === "register" ? "Create Pakistani Trade Account" : "Reset Account Password"}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  {mode === "login" && "Enter your enterprise credentials or click a 1-click Pakistani demo persona below."}
                  {mode === "register" && "Register your delegate, exhibitor, or organizer credentials for instant expo portal access."}
                  {mode === "forgot" && (forgotStep === 1 ? "Enter your registered email address to receive a 6-digit recovery OTP." : "Enter the verification code and configure your new secure password.")}
                </p>
              </div>
              <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            {/* ============================================================ */}
            {/* MODE 1: LOGIN (SIGN IN)                                      */}
            {/* ============================================================ */}
            {mode === "login" && (
              <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
                {/* 1-Click Pakistani Demo Personas */}
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 flex justify-between">
                    <span>1-Click Pakistani Demo Personas</span>
                    <span className="text-amber-600 font-bold">Fast Evaluation</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => selectDemoPersona("admin")}
                      className={`p-2 rounded-xl text-left border transition-all ${email === "ops@eventsphere.example.pk" ? "bg-slate-900 text-amber-400 border-slate-900" : "bg-white border-slate-200 text-slate-700 hover:border-slate-400"}`}
                    >
                      <div className="font-extrabold text-[11px] truncate">Farhan Akhtar</div>
                      <div className="text-[9px] opacity-80">🛡️ Organizer</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => selectDemoPersona("exhibitor")}
                      className={`p-2 rounded-xl text-left border transition-all ${email === "info@pakrobotics.example.pk" ? "bg-slate-900 text-amber-400 border-slate-900" : "bg-white border-slate-200 text-slate-700 hover:border-slate-400"}`}
                    >
                      <div className="font-extrabold text-[11px] truncate">Dr. Tariq M.</div>
                      <div className="text-[9px] opacity-80">🏢 PakRobotics</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => selectDemoPersona("attendee")}
                      className={`p-2 rounded-xl text-left border transition-all ${email === "usman.khan@techpak.example.pk" ? "bg-slate-900 text-amber-400 border-slate-900" : "bg-white border-slate-200 text-slate-700 hover:border-slate-400"}`}
                    >
                      <div className="font-extrabold text-[11px] truncate">M. Usman</div>
                      <div className="text-[9px] opacity-80">🎟️ Delegate</div>
                    </button>
                  </div>
                </div>

                {forgotMessage && (
                  <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs">
                    {forgotMessage}
                  </div>
                )}

                <div>
                  <label className="text-slate-700 font-bold">Email Address</label>
                  <input 
                    type="email" 
                    required 
                    value={email} 
                    onChange={e => setEmail(e.target.value)}
                    className="w-full mt-1 p-3 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center">
                    <label className="text-slate-700 font-bold">Password</label>
                    <span 
                      onClick={() => { setMode("forgot"); setForgotStep(1); setForgotMessage(null); setForgotError(null); }} 
                      className="text-amber-600 hover:text-amber-700 font-bold cursor-pointer"
                    >
                      Forgot Password?
                    </span>
                  </div>
                  <input 
                    type="password" 
                    required 
                    value={password} 
                    onChange={e => setPassword(e.target.value)}
                    className="w-full mt-1 p-3 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                  />
                </div>

                <div className="flex items-center justify-between text-xs">
                  <label className="flex items-center space-x-2 text-slate-600 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={rememberMe} 
                      onChange={e => setRememberMe(e.target.checked)} 
                      className="rounded text-amber-600 focus:ring-amber-500" 
                    />
                    <span>Remember my session on this device</span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white font-extrabold text-sm transition-all shadow-md hover:shadow-lg flex items-center justify-center space-x-2"
                >
                  <span>Sign In to Portal</span>
                  <Icon name="arrowRight" className="w-4 h-4 text-amber-400" />
                </button>
              </form>
            )}

            {/* ============================================================ */}
            {/* MODE 2: REGISTER (CREATE ACCOUNT)                            */}
            {/* ============================================================ */}
            {mode === "register" && (
              <form onSubmit={handleRegisterSubmit} className="space-y-3.5 text-xs">
                <div>
                  <label className="text-slate-700 font-bold">Select Your Role</label>
                  <div className="grid grid-cols-3 gap-2 mt-1">
                    {[
                      { id: "attendee", label: "🎟️ Attendee", desc: "Trade Visitor" },
                      { id: "exhibitor", label: "🏢 Exhibitor", desc: "Booth Vendor" },
                      { id: "admin", label: "🛡️ Organizer", desc: "Operations" }
                    ].map(r => (
                      <button
                        type="button"
                        key={r.id}
                        onClick={() => setRegRole(r.id)}
                        className={`p-2 text-center rounded-xl font-bold border transition-all ${
                          regRole === r.id ? "bg-amber-500 text-slate-900 border-amber-500 shadow-xs font-extrabold" : "bg-slate-50 text-slate-700 border-slate-200 hover:bg-white"
                        }`}
                      >
                        <div>{r.label}</div>
                        <div className="text-[10px] font-normal opacity-80">{r.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-700 font-bold">Full Name</label>
                    <input 
                      type="text" 
                      required 
                      placeholder="e.g. Engr. Hassan Raza"
                      value={regName} 
                      onChange={e => setRegName(e.target.value)}
                      className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-slate-700 font-bold">Mobile / WhatsApp</label>
                    <input 
                      type="text" 
                      required 
                      placeholder="+92 (300) 123-4567"
                      value={regPhone} 
                      onChange={e => setRegPhone(e.target.value)}
                      className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-700 font-bold">Work / Enterprise Email</label>
                    <input 
                      type="email" 
                      required 
                      placeholder="hassan.raza@paktech.pk"
                      value={regEmail} 
                      onChange={e => setRegEmail(e.target.value)}
                      className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-slate-700 font-bold">Company / Organization</label>
                    <input 
                      type="text" 
                      required 
                      placeholder="e.g. Habib Industrial Automation"
                      value={regOrg} 
                      onChange={e => setRegOrg(e.target.value)}
                      className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-700 font-bold">Password</label>
                    <input 
                      type="password" 
                      required 
                      value={regPassword} 
                      onChange={e => setRegPassword(e.target.value)}
                      className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    />
                  </div>
                  <div>
                    <label className="text-slate-700 font-bold">Confirm Password</label>
                    <input 
                      type="password" 
                      required 
                      value={regConfirmPassword} 
                      onChange={e => setRegConfirmPassword(e.target.value)}
                      className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                    />
                  </div>
                </div>

                <div className="pt-1">
                  <label className="flex items-start space-x-2 text-slate-600 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={regTerms} 
                      onChange={e => setRegTerms(e.target.checked)} 
                      className="mt-0.5 rounded text-amber-600 focus:ring-amber-500" 
                    />
                    <span className="text-[11px] leading-relaxed">
                      I agree to the EventSphere Expo Terms, contactless RFID badge entry policies, and SECP compliance standards.
                    </span>
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white font-extrabold text-sm transition-all shadow-md hover:shadow-lg flex items-center justify-center space-x-2"
                >
                  <span>Complete Registration & Sign In</span>
                  <Icon name="checkCircle" className="w-4 h-4 text-emerald-400" />
                </button>
              </form>
            )}

            {/* ============================================================ */}
            {/* MODE 3: FORGOT PASSWORD (2-STEP VERIFICATION & RESET)        */}
            {/* ============================================================ */}
            {mode === "forgot" && (
              <div className="space-y-4 text-xs">
                {forgotMessage && (
                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-medium space-y-1">
                    <div className="flex items-center space-x-1.5 font-bold text-emerald-800">
                      <Icon name="checkCircle" className="w-4 h-4 text-emerald-600" />
                      <span>Security Code Dispatched</span>
                    </div>
                    <div>{forgotMessage}</div>
                  </div>
                )}

                {forgotError && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-300 text-rose-800 text-xs font-semibold">
                    {forgotError}
                  </div>
                )}

                {forgotStep === 1 ? (
                  <form onSubmit={handleSendResetCode} className="space-y-4">
                    <div>
                      <label className="text-slate-700 font-bold">Registered Trade Email</label>
                      <input 
                        type="email" 
                        required 
                        value={forgotEmail} 
                        onChange={e => setForgotEmail(e.target.value)}
                        placeholder="e.g. usman.khan@techpak.example.pk"
                        className="w-full mt-1 p-3 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                      />
                      <p className="text-[11px] text-slate-500 mt-1">We will send a 6-digit confirmation code to verify your identity.</p>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl bg-[#0F172A] hover:bg-slate-800 text-white font-extrabold text-sm transition-all shadow-md flex items-center justify-center space-x-2"
                    >
                      <span>Send 6-Digit Verification Code</span>
                      <Icon name="arrowRight" className="w-4 h-4 text-amber-400" />
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleResetPasswordSubmit} className="space-y-3.5">
                    <div>
                      <label className="text-slate-700 font-bold">6-Digit Verification Code (OTP)</label>
                      <input 
                        type="text" 
                        required 
                        maxLength={6}
                        value={inputCode} 
                        onChange={e => setInputCode(e.target.value)}
                        placeholder="584920"
                        className="w-full mt-1 p-3 rounded-xl border border-slate-300 text-center text-lg font-mono tracking-widest font-extrabold focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                      />
                      <div className="text-[10px] text-amber-700 font-bold mt-1 text-center">💡 Demo Verification Code is pre-filled: 584920</div>
                    </div>

                    <div>
                      <label className="text-slate-700 font-bold">New Password</label>
                      <input 
                        type="password" 
                        required 
                        placeholder="Minimum 6 characters"
                        value={newPassword} 
                        onChange={e => setNewPassword(e.target.value)}
                        className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                      />
                    </div>

                    <div>
                      <label className="text-slate-700 font-bold">Confirm New Password</label>
                      <input 
                        type="password" 
                        required 
                        placeholder="Re-type new password"
                        value={confirmNewPassword} 
                        onChange={e => setConfirmNewPassword(e.target.value)}
                        className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-900 font-extrabold text-sm transition-all shadow-md flex items-center justify-center space-x-2"
                    >
                      <span>Update Password & Proceed</span>
                      <Icon name="checkCircle" className="w-4 h-4 text-slate-900" />
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* Footer Navigation */}
            <div className="pt-4 border-t border-slate-100 text-center text-xs text-slate-500">
              {mode === "login" && (
                <span>Don't have an enterprise account? <strong onClick={() => setMode("register")} className="text-amber-600 hover:text-amber-700 cursor-pointer font-bold">Register now</strong></span>
              )}
              {mode === "register" && (
                <span>Already registered with EventSphere? <strong onClick={() => setMode("login")} className="text-amber-600 hover:text-amber-700 cursor-pointer font-bold">Sign in</strong></span>
              )}
              {mode === "forgot" && (
                <span>Remember your password? <strong onClick={() => setMode("login")} className="text-amber-600 hover:text-amber-700 cursor-pointer font-bold">Back to Sign In</strong></span>
              )}
            </div>
          </div>
        </div>
      );
    }

    // 3. Create Expo Modal
    function CreateExpoModal({ onClose, onSubmit }) {
      const [title, setTitle] = useState("");
      const [category, setCategory] = useState("Technology & AI");
      const [location, setLocation] = useState("");
      const [startDate, setStartDate] = useState("");
      const [description, setDescription] = useState("");

      const handleFormSubmit = (e) => {
        e.preventDefault();
        onSubmit({
          id: `expo-${Date.now()}`,
          title: title || "New Global Expo 2027",
          tagline: description.slice(0, 80) || "Premier international trade show gathering industry pioneers.",
          category,
          location: location || "Metropolitan Expo Center",
          venueDetails: "Main Grand Halls 1-3",
          startDate: startDate || "March 2027",
          endDate: "4 Days",
          status: "Registration Open",
          totalBooths: 40,
          occupiedBooths: 0,
          attendeeCount: 1,
          bannerColor: "from-blue-800 to-indigo-950",
          description
        });
      };

      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-2xl font-bold font-heading text-slate-900">Launch New Expo Event</h3>
                <p className="text-xs text-slate-500 mt-1">Configure event metadata, hall capacity, and start registration.</p>
              </div>
              <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-700 font-semibold">Expo Event Title</label>
                <input 
                  type="text" 
                  required 
                  placeholder="e.g. World AI & Quantum Summit 2027" 
                  value={title} 
                  onChange={e => setTitle(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-semibold">Industry Category</label>
                  <select 
                    value={category} 
                    onChange={e => setCategory(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option>Technology & AI</option>
                    <option>Renewable Energy</option>
                    <option>Automotive & Mobility</option>
                    <option>Healthcare & Life Sciences</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-700 font-semibold">Target Dates</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Apr 10 - Apr 13, 2027" 
                    value={startDate} 
                    onChange={e => setStartDate(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-semibold">Venue & City</label>
                <input 
                  type="text" 
                  required 
                  placeholder="e.g. Marina Bay Sands, Singapore" 
                  value={location} 
                  onChange={e => setLocation(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div>
                <label className="text-slate-700 font-semibold">Event Description & Themes</label>
                <textarea 
                  rows="3" 
                  placeholder="Outline key themes, exhibition highlights, and target industries..."
                  value={description} 
                  onChange={e => setDescription(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                ></textarea>
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="px-4 py-2.5 rounded-xl text-slate-600 font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold">
                  Create & Open Registration
                </button>
              </div>
            </form>
          </div>
        </div>
      );
    }

    // 4. Add Session Modal
    function AddSessionModal({ onClose, onSubmit }) {
      const [title, setTitle] = useState("");
      const [speaker, setSpeaker] = useState("");
      const [role, setRole] = useState("");
      const [time, setTime] = useState("10:00 AM - 11:15 AM");
      const [day, setDay] = useState("Day 1 (Nov 12)");
      const [track, setTrack] = useState("Keynote");

      const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit({
          id: `sess-${Date.now()}`,
          title: title || "New Technical Seminar",
          day,
          time,
          stage: "Hall A Technical Stage",
          track,
          speakerName: speaker || "Distinguished Guest Speaker",
          speakerRole: role || "Chief Technology Officer",
          speakerAvatar: (speaker ? speaker.slice(0, 2) : "SP").toUpperCase(),
          category: track,
          capacity: 500,
          registeredCount: 0,
          isBookmarked: false,
          description: "Comprehensive deep dive into implementation mechanics and commercial deployments."
        });
      };

      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-2xl font-bold font-heading text-slate-900">Add Session to Schedule</h3>
                <p className="text-xs text-slate-500 mt-1">Assign speakers, halls, and time slots.</p>
              </div>
              <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-700 font-semibold">Session Title</label>
                <input 
                  type="text" 
                  required 
                  placeholder="e.g. Scaling Transformer Inference on Edge Silicon" 
                  value={title} 
                  onChange={e => setTitle(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-semibold">Keynote Speaker</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="e.g. Dr. Tariq Mehmood" 
                    value={speaker} 
                    onChange={e => setSpeaker(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
                <div>
                  <label className="text-slate-700 font-semibold">Speaker Title/Company</label>
                  <input 
                    type="text" 
                    placeholder="e.g. Chief Scientist, PakRobotics" 
                    value={role} 
                    onChange={e => setRole(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-700 font-semibold">Day & Date</label>
                  <select 
                    value={day} 
                    onChange={e => setDay(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option>Day 1 (Nov 12)</option>
                    <option>Day 2 (Nov 13)</option>
                    <option>Day 3 (Nov 14)</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-700 font-semibold">Session Track</label>
                  <select 
                    value={track} 
                    onChange={e => setTrack(e.target.value)}
                    className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option>Keynote</option>
                    <option>AI & Deep Learning</option>
                    <option>Clean Tech</option>
                    <option>Cybersecurity</option>
                    <option>Quantum</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-semibold">Time Slot</label>
                <input 
                  type="text" 
                  value={time} 
                  onChange={e => setTime(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button type="button" onClick={onClose} className="px-4 py-2.5 rounded-xl text-slate-600 font-semibold">
                  Cancel
                </button>
                <button type="submit" className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold">
                  Save Session Slot
                </button>
              </div>
            </form>
          </div>
        </div>
      );
    }

    // 5. Contact Exhibitor Modal
    function ContactExhibitorModal({ exhibitor, onClose, onSubmit }) {
      const [message, setMessage] = useState("");

      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold font-heading text-slate-900">Contact {exhibitor.name}</h3>
                <p className="text-xs text-slate-500">Representative: {exhibitor.representative} ({exhibitor.location})</p>
              </div>
              <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-700 font-semibold">Inquiry Topic</label>
                <select className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none">
                  <option>Schedule In-Person Booth Demo</option>
                  <option>Request Enterprise Pricing / Datasheet</option>
                  <option>B2B Partnership / Integration</option>
                  <option>General Question</option>
                </select>
              </div>

              <div>
                <label className="text-slate-700 font-semibold">Your Message</label>
                <textarea 
                  rows="4" 
                  placeholder="Hi, our team would love to test your robotics rover on Day 2 around 2 PM..."
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                ></textarea>
              </div>

              <button
                onClick={() => onSubmit(message)}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-colors shadow-sm"
              >
                Transmit Inquiry to Exhibitor
              </button>
            </div>
          </div>
        </div>
      );
    }

    // 6. Feedback & Support Modal
    function FeedbackModal({ onClose, onSubmit }) {
      const [category, setCategory] = useState("General Suggestion");
      const [rating, setRating] = useState(5);
      const [feedback, setFeedback] = useState("");

      return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl border border-slate-200">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-bold font-heading text-slate-900">Feedback & Support Ticket</h3>
                <p className="text-xs text-slate-500">Help our operations team improve the EventSphere platform.</p>
              </div>
              <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                <Icon name="x" className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="text-slate-700 font-semibold">Category</label>
                <select 
                  value={category} 
                  onChange={e => setCategory(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none"
                >
                  <option>General Suggestion</option>
                  <option>Floor Plan / Booth Logistics</option>
                  <option>Schedule & Speaker Timing</option>
                  <option>Bug / Technical Issue</option>
                </select>
              </div>

              <div>
                <label className="text-slate-700 font-semibold">Platform Rating</label>
                <div className="flex space-x-2 mt-1">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRating(star)}
                      className={`p-1.5 rounded-lg ${rating >= star ? "text-amber-500" : "text-slate-300"}`}
                    >
                      <Icon name="star" className="w-6 h-6" />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-slate-700 font-semibold">Comments / Suggestions</label>
                <textarea 
                  rows="3" 
                  placeholder="Share your thoughts or describe any issue encountered..."
                  value={feedback}
                  onChange={e => setFeedback(e.target.value)}
                  className="w-full mt-1 p-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                ></textarea>
              </div>

              <button
                onClick={() => onSubmit({ category, rating, feedback })}
                className="w-full py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors shadow-sm"
              >
                Submit Feedback
              </button>
            </div>
          </div>
        </div>
      );
    }

    // --- Mount React Root ---
    const rootElement = document.getElementById('root');
    const root = ReactDOM.createRoot(rootElement);
    root.render(<App />);
  